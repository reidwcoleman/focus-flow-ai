// contracts.ts
// Shared API contracts (schemas and types) used by both the server and the app.
// Import in the app as: `import { type GetSampleResponse } from "@shared/contracts"`
// Import in the server as: `import { postSampleRequestSchema } from "@shared/contracts"`

import { z } from "zod";

// GET /api/sample
export const getSampleResponseSchema = z.object({
  message: z.string(),
});
export type GetSampleResponse = z.infer<typeof getSampleResponseSchema>;

// POST /api/sample
export const postSampleRequestSchema = z.object({
  value: z.string(),
});
export type PostSampleRequest = z.infer<typeof postSampleRequestSchema>;
export const postSampleResponseSchema = z.object({
  message: z.string(),
});
export type PostSampleResponse = z.infer<typeof postSampleResponseSchema>;

// POST /api/upload/image
export const uploadImageRequestSchema = z.object({
  image: z.instanceof(File),
});
export type UploadImageRequest = z.infer<typeof uploadImageRequestSchema>;
export const uploadImageResponseSchema = z.object({
  success: z.boolean(),
  message: z.string(),
  url: z.string(),
  filename: z.string(),
});
export type UploadImageResponse = z.infer<typeof uploadImageResponseSchema>;

// ============================================
// SUBJECTS
// ============================================

// GET /api/subjects
export const getSubjectsResponseSchema = z.object({
  subjects: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      color: z.string(),
      icon: z.string().nullable(),
      createdAt: z.string(),
      updatedAt: z.string(),
    })
  ),
});
export type GetSubjectsResponse = z.infer<typeof getSubjectsResponseSchema>;

// POST /api/subjects
export const createSubjectRequestSchema = z.object({
  name: z.string().min(1),
  color: z.string().regex(/^#[0-9A-F]{6}$/i),
  icon: z.string().optional(),
});
export type CreateSubjectRequest = z.infer<typeof createSubjectRequestSchema>;
export const createSubjectResponseSchema = z.object({
  id: z.string(),
  name: z.string(),
  color: z.string(),
  icon: z.string().nullable(),
  createdAt: z.string(),
  updatedAt: z.string(),
});
export type CreateSubjectResponse = z.infer<typeof createSubjectResponseSchema>;

// DELETE /api/subjects/:id
export const deleteSubjectResponseSchema = z.object({
  success: z.boolean(),
});
export type DeleteSubjectResponse = z.infer<typeof deleteSubjectResponseSchema>;

// ============================================
// ASSIGNMENTS
// ============================================

// GET /api/assignments
export const getAssignmentsResponseSchema = z.object({
  assignments: z.array(
    z.object({
      id: z.string(),
      title: z.string(),
      description: z.string().nullable(),
      dueDate: z.string(),
      priority: z.enum(["low", "medium", "high", "urgent"]),
      status: z.enum(["todo", "in_progress", "completed"]),
      subjectId: z.string().nullable(),
      subject: z
        .object({
          id: z.string(),
          name: z.string(),
          color: z.string(),
          icon: z.string().nullable(),
        })
        .nullable(),
      createdAt: z.string(),
      updatedAt: z.string(),
      completedAt: z.string().nullable(),
    })
  ),
});
export type GetAssignmentsResponse = z.infer<typeof getAssignmentsResponseSchema>;

// POST /api/assignments
export const createAssignmentRequestSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  dueDate: z.string(), // ISO date string
  priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
  subjectId: z.string().optional(),
});
export type CreateAssignmentRequest = z.infer<typeof createAssignmentRequestSchema>;
export const createAssignmentResponseSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().nullable(),
  dueDate: z.string(),
  priority: z.string(),
  status: z.string(),
  subjectId: z.string().nullable(),
  createdAt: z.string(),
  updatedAt: z.string(),
});
export type CreateAssignmentResponse = z.infer<typeof createAssignmentResponseSchema>;

// PATCH /api/assignments/:id
export const updateAssignmentRequestSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  dueDate: z.string().optional(),
  priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
  status: z.enum(["todo", "in_progress", "completed"]).optional(),
  subjectId: z.string().optional(),
});
export type UpdateAssignmentRequest = z.infer<typeof updateAssignmentRequestSchema>;
export const updateAssignmentResponseSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().nullable(),
  dueDate: z.string(),
  priority: z.string(),
  status: z.string(),
  subjectId: z.string().nullable(),
  createdAt: z.string(),
  updatedAt: z.string(),
  completedAt: z.string().nullable(),
});
export type UpdateAssignmentResponse = z.infer<typeof updateAssignmentResponseSchema>;

// DELETE /api/assignments/:id
export const deleteAssignmentResponseSchema = z.object({
  success: z.boolean(),
});
export type DeleteAssignmentResponse = z.infer<typeof deleteAssignmentResponseSchema>;

// POST /api/assignments/extract-from-screenshot
export const extractFromScreenshotRequestSchema = z.object({
  imageUrl: z.string(), // base64 or URL
});
export type ExtractFromScreenshotRequest = z.infer<
  typeof extractFromScreenshotRequestSchema
>;
export const extractFromScreenshotResponseSchema = z.object({
  assignments: z.array(
    z.object({
      title: z.string(),
      description: z.string().optional(),
      dueDate: z.string().optional(),
      subject: z.string().optional(),
    })
  ),
});
export type ExtractFromScreenshotResponse = z.infer<
  typeof extractFromScreenshotResponseSchema
>;

// ============================================
// STUDY BLOCKS
// ============================================

// GET /api/study-blocks
export const getStudyBlocksResponseSchema = z.object({
  studyBlocks: z.array(
    z.object({
      id: z.string(),
      assignmentId: z.string().nullable(),
      assignment: z.object({
        id: z.string(),
        title: z.string(),
        subject: z
          .object({
            name: z.string(),
            color: z.string(),
          })
          .nullable(),
      }).nullable(),
      startTime: z.string(),
      endTime: z.string(),
      duration: z.number(),
      completed: z.boolean(),
      createdAt: z.string(),
    })
  ),
});
export type GetStudyBlocksResponse = z.infer<typeof getStudyBlocksResponseSchema>;

// POST /api/study-blocks/generate
export const generateStudyBlocksRequestSchema = z.object({
  assignmentId: z.string().optional(), // if not provided, generates for all assignments
});
export type GenerateStudyBlocksRequest = z.infer<
  typeof generateStudyBlocksRequestSchema
>;
export const generateStudyBlocksResponseSchema = z.object({
  studyBlocks: z.array(
    z.object({
      id: z.string(),
      assignmentId: z.string().nullable(),
      startTime: z.string(),
      endTime: z.string(),
      duration: z.number(),
    })
  ),
});
export type GenerateStudyBlocksResponse = z.infer<
  typeof generateStudyBlocksResponseSchema
>;

// ============================================
// CANVAS INTEGRATION
// ============================================

// POST /api/canvas/connect
export const connectCanvasRequestSchema = z.object({
  canvasUrl: z.string().url(),
  accessToken: z.string().min(1),
});
export type ConnectCanvasRequest = z.infer<typeof connectCanvasRequestSchema>;
export const connectCanvasResponseSchema = z.object({
  success: z.boolean(),
  message: z.string(),
});
export type ConnectCanvasResponse = z.infer<typeof connectCanvasResponseSchema>;

// GET /api/canvas/status
export const getCanvasStatusResponseSchema = z.object({
  connected: z.boolean(),
  canvasUrl: z.string().optional(),
  lastSyncAt: z.string().nullable(),
  syncEnabled: z.boolean(),
});
export type GetCanvasStatusResponse = z.infer<typeof getCanvasStatusResponseSchema>;

// POST /api/canvas/sync
export const syncCanvasResponseSchema = z.object({
  success: z.boolean(),
  assignmentsImported: z.number(),
  coursesImported: z.number(),
  gradesImported: z.number(),
  scheduleBlocksCreated: z.number(),
});
export type SyncCanvasResponse = z.infer<typeof syncCanvasResponseSchema>;

// DELETE /api/canvas/disconnect
export const disconnectCanvasResponseSchema = z.object({
  success: z.boolean(),
});
export type DisconnectCanvasResponse = z.infer<typeof disconnectCanvasResponseSchema>;

// ============================================
// COURSES
// ============================================

// GET /api/courses
export const getCoursesResponseSchema = z.object({
  courses: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      courseCode: z.string().nullable(),
      instructor: z.string().nullable(),
      credits: z.number().nullable(),
      color: z.string().nullable(),
      meetingDays: z.string().nullable(),
      meetingStartTime: z.string().nullable(),
      meetingEndTime: z.string().nullable(),
      location: z.string().nullable(),
      estimatedStudyHoursPerWeek: z.number().nullable(),
      currentGrade: z.string().nullable(),
      currentScore: z.number().nullable(),
      enrollmentStatus: z.string().nullable(),
      term: z.string().nullable(),
      createdAt: z.string(),
    })
  ),
});
export type GetCoursesResponse = z.infer<typeof getCoursesResponseSchema>;

// POST /api/courses
export const createCourseRequestSchema = z.object({
  name: z.string().min(1),
  courseCode: z.string().optional(),
  instructor: z.string().optional(),
  credits: z.number().optional(),
  color: z.string().optional(),
  meetingDays: z.array(z.string()).optional(),
  meetingStartTime: z.string().optional(),
  meetingEndTime: z.string().optional(),
  location: z.string().optional(),
  estimatedStudyHoursPerWeek: z.number().optional(),
});
export type CreateCourseRequest = z.infer<typeof createCourseRequestSchema>;

// ============================================
// WEEKLY SCHEDULE
// ============================================

// POST /api/schedule/generate-from-description
export const generateScheduleFromDescriptionRequestSchema = z.object({
  description: z.string().min(1),
  weekStartDate: z.string().optional(),
});
export type GenerateScheduleFromDescriptionRequest = z.infer<
  typeof generateScheduleFromDescriptionRequestSchema
>;
export const generateScheduleFromDescriptionResponseSchema = z.object({
  scheduleId: z.string(),
  studyBlocks: z.array(
    z.object({
      id: z.string(),
      title: z.string(),
      startTime: z.string(),
      endTime: z.string(),
      duration: z.number(),
      type: z.string(),
    })
  ),
});
export type GenerateScheduleFromDescriptionResponse = z.infer<
  typeof generateScheduleFromDescriptionResponseSchema
>;

// GET /api/schedule/current
export const getCurrentScheduleResponseSchema = z.object({
  schedule: z
    .object({
      id: z.string(),
      weekStartDate: z.string(),
      weekEndDate: z.string(),
      description: z.string().nullable(),
      aiGenerated: z.boolean(),
      studyBlocks: z.array(
        z.object({
          id: z.string(),
          title: z.string().nullable(),
          startTime: z.string(),
          endTime: z.string(),
          duration: z.number(),
          type: z.string(),
          completed: z.boolean(),
          assignmentId: z.string().nullable(),
          assignment: z
            .object({
              id: z.string(),
              title: z.string(),
            })
            .nullable(),
        })
      ),
    })
    .nullable(),
});
export type GetCurrentScheduleResponse = z.infer<typeof getCurrentScheduleResponseSchema>;

// ============================================
// GRADES
// ============================================

// GET /api/grades
export const getGradesResponseSchema = z.object({
  grades: z.array(
    z.object({
      id: z.string(),
      courseId: z.string(),
      courseName: z.string(),
      courseCode: z.string().nullable(),
      assignmentName: z.string(),
      score: z.number().nullable(),
      maxScore: z.number().nullable(),
      percentage: z.number().nullable(),
      letterGrade: z.string().nullable(),
      submittedAt: z.string().nullable(),
      gradedAt: z.string().nullable(),
      createdAt: z.string(),
    })
  ),
});
export type GetGradesResponse = z.infer<typeof getGradesResponseSchema>;

// GET /api/grades/course/:courseId
export const getCourseGradesResponseSchema = z.object({
  course: z.object({
    id: z.string(),
    name: z.string(),
    courseCode: z.string().nullable(),
    currentGrade: z.string().nullable(),
    currentScore: z.number().nullable(),
  }),
  grades: z.array(
    z.object({
      id: z.string(),
      assignmentName: z.string(),
      score: z.number().nullable(),
      maxScore: z.number().nullable(),
      percentage: z.number().nullable(),
      letterGrade: z.string().nullable(),
      submittedAt: z.string().nullable(),
      gradedAt: z.string().nullable(),
    })
  ),
});
export type GetCourseGradesResponse = z.infer<typeof getCourseGradesResponseSchema>;

// ============================================
// ACTIVITIES
// ============================================

// Activity schema
export const activitySchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().nullable(),
  date: z.string(), // ISO date string
  startTime: z.string().nullable(),
  endTime: z.string().nullable(),
  color: z.string(),
  allDay: z.boolean(),
  completed: z.boolean(),
  createdAt: z.string(),
  updatedAt: z.string(),
});
export type Activity = z.infer<typeof activitySchema>;

// GET /api/activities
export const getActivitiesResponseSchema = z.object({
  activities: z.array(activitySchema),
});
export type GetActivitiesResponse = z.infer<typeof getActivitiesResponseSchema>;

// POST /api/activities
export const createActivityRequestSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  date: z.string(),
  startTime: z.string().optional(),
  endTime: z.string().optional(),
  color: z.string().default("#3A7BFF"),
  allDay: z.boolean().default(false),
});
export type CreateActivityRequest = z.infer<typeof createActivityRequestSchema>;

export const createActivityResponseSchema = z.object({
  activity: activitySchema,
});
export type CreateActivityResponse = z.infer<typeof createActivityResponseSchema>;

// POST /api/activities/generate-from-description
export const generateActivitiesFromDescriptionRequestSchema = z.object({
  description: z.string().min(1),
});
export type GenerateActivitiesFromDescriptionRequest = z.infer<typeof generateActivitiesFromDescriptionRequestSchema>;

export const generateActivitiesFromDescriptionResponseSchema = z.object({
  activities: z.array(activitySchema),
  count: z.number(),
});
export type GenerateActivitiesFromDescriptionResponse = z.infer<typeof generateActivitiesFromDescriptionResponseSchema>;

// Streak schema
export const streakSchema = z.object({
  id: z.string(),
  userId: z.string(),
  currentStreak: z.number(),
  longestStreak: z.number(),
  lastLoginDate: z.string().nullable(),
  totalDays: z.number(),
  createdAt: z.string(),
  updatedAt: z.string(),
});
export type Streak = z.infer<typeof streakSchema>;

// GET /api/streak
export const getStreakResponseSchema = z.object({
  streak: streakSchema,
});
export type GetStreakResponse = z.infer<typeof getStreakResponseSchema>;

// POST /api/streak/check
export const checkStreakResponseSchema = z.object({
  streak: streakSchema,
  isNewStreak: z.boolean().optional(),
  isStreakBroken: z.boolean().optional(),
  alreadyLoggedToday: z.boolean().optional(),
  message: z.string(),
});
export type CheckStreakResponse = z.infer<typeof checkStreakResponseSchema>;

// ============================================
// STUDY SESSIONS
// ============================================

// Study session schema
export const studySessionSchema = z.object({
  id: z.string(),
  userId: z.string(),
  startTime: z.string(),
  endTime: z.string().nullable(),
  plannedDuration: z.number(),
  actualDuration: z.number().nullable(),
  blockedApps: z.string().nullable(), // JSON array of app identifiers
  breaksUsed: z.number(),
  breakTimeUsed: z.number(),
  status: z.string(), // active, completed, cancelled
  createdAt: z.string(),
  updatedAt: z.string(),
});
export type StudySession = z.infer<typeof studySessionSchema>;

// GET /api/study-sessions
export const getStudySessionsResponseSchema = z.object({
  sessions: z.array(studySessionSchema),
});
export type GetStudySessionsResponse = z.infer<typeof getStudySessionsResponseSchema>;

// GET /api/study-sessions/active
export const getActiveStudySessionResponseSchema = z.object({
  session: studySessionSchema.nullable(),
});
export type GetActiveStudySessionResponse = z.infer<typeof getActiveStudySessionResponseSchema>;

// POST /api/study-sessions
export const createStudySessionRequestSchema = z.object({
  plannedDuration: z.number().min(1).max(480),
  blockedApps: z.array(z.string()).optional(),
});
export type CreateStudySessionRequest = z.infer<typeof createStudySessionRequestSchema>;

export const createStudySessionResponseSchema = z.object({
  session: studySessionSchema,
});
export type CreateStudySessionResponse = z.infer<typeof createStudySessionResponseSchema>;

// PATCH /api/study-sessions/:id
export const updateStudySessionRequestSchema = z.object({
  breaksUsed: z.number().optional(),
  breakTimeUsed: z.number().optional(),
});
export type UpdateStudySessionRequest = z.infer<typeof updateStudySessionRequestSchema>;

export const updateStudySessionResponseSchema = z.object({
  session: studySessionSchema,
});
export type UpdateStudySessionResponse = z.infer<typeof updateStudySessionResponseSchema>;

// POST /api/study-sessions/:id/end
export const endStudySessionResponseSchema = z.object({
  session: studySessionSchema,
});
export type EndStudySessionResponse = z.infer<typeof endStudySessionResponseSchema>;

// POST /api/study-sessions/:id/cancel
export const cancelStudySessionResponseSchema = z.object({
  session: studySessionSchema,
});
export type CancelStudySessionResponse = z.infer<typeof cancelStudySessionResponseSchema>;

// GET /api/study-sessions/stats
export const getStudySessionStatsResponseSchema = z.object({
  stats: z.object({
    totalSessions: z.number(),
    totalMinutes: z.number(),
    totalHours: z.number(),
    totalBreaks: z.number(),
    averageSessionLength: z.number(),
    weeklyMinutes: z.number(),
    weeklyHours: z.number(),
  }),
});
export type GetStudySessionStatsResponse = z.infer<typeof getStudySessionStatsResponseSchema>;

// ============================================
// ANALYTICS
// ============================================

// Course analytics schema
export const courseAnalyticsSchema = z.object({
  courseId: z.string(),
  courseName: z.string(),
  courseCode: z.string().nullable(),
  currentGrade: z.string().nullable(),
  currentScore: z.number().nullable(),
  averageGrade: z.number().nullable(),
  gradeCount: z.number(),
  trend: z.enum(["improving", "stable", "slipping"]).nullable(),
  credits: z.number().nullable(),
});
export type CourseAnalytics = z.infer<typeof courseAnalyticsSchema>;

// Subject balance schema
export const subjectBalanceSchema = z.object({
  courseName: z.string(),
  courseCode: z.string().nullable(),
  gradeWeight: z.number(),
  currentGrade: z.string().nullable(),
  trend: z.enum(["improving", "stable", "slipping"]).nullable(),
});
export type SubjectBalance = z.infer<typeof subjectBalanceSchema>;

// Achievement schema
export const achievementSchema = z.object({
  title: z.string(),
  icon: z.string(),
});
export type Achievement = z.infer<typeof achievementSchema>;

// GET /api/analytics
export const getAnalyticsResponseSchema = z.object({
  analytics: z.object({
    weeklyReport: z.object({
      thisWeekHours: z.number(),
      lastWeekHours: z.number(),
      change: z.number(),
      changePercent: z.number(),
      message: z.string(),
      mostProductiveDay: z.string(),
      mostProductiveTime: z.string(),
    }),
    productivity: z.object({
      insight: z.string(),
      morningMinutes: z.number(),
      afternoonMinutes: z.number(),
      eveningMinutes: z.number(),
      totalMinutes: z.number(),
    }),
    courses: z.array(courseAnalyticsSchema),
    subjectBalance: z.array(subjectBalanceSchema),
    achievements: z.array(achievementSchema),
    totalStats: z.object({
      totalStudyHours: z.number(),
      totalSessions: z.number(),
      averageSessionLength: z.number(),
    }),
  }),
});
export type GetAnalyticsResponse = z.infer<typeof getAnalyticsResponseSchema>;

// GET /api/analytics/course/:courseId/trends
export const getCourseTrendsResponseSchema = z.object({
  courseName: z.string(),
  courseCode: z.string().nullable(),
  currentGrade: z.string().nullable(),
  currentScore: z.number().nullable(),
  trend: z.enum(["improving", "stable", "slipping"]).nullable(),
  trendMessage: z.string(),
  recentTrend: z.enum(["up", "down", "stable"]).nullable(),
  statistics: z.object({
    averageGrade: z.number().nullable(),
    highestGrade: z.number().nullable(),
    lowestGrade: z.number().nullable(),
    totalGrades: z.number(),
  }),
  grades: z.array(
    z.object({
      id: z.string(),
      assignmentName: z.string(),
      percentage: z.number().nullable(),
      letterGrade: z.string().nullable(),
      gradedAt: z.string().nullable(),
    })
  ),
});
export type GetCourseTrendsResponse = z.infer<typeof getCourseTrendsResponseSchema>;


