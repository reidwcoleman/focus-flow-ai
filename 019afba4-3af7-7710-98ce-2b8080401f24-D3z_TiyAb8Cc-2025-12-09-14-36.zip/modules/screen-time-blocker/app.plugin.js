const {
  withEntitlementsPlist,
  withInfoPlist,
} = require('@expo/config-plugins');

/**
 * Expo Config Plugin to add Family Controls capability
 * This adds the required entitlements for Screen Time API
 */
const withScreenTimeBlocker = (config) => {
  // Add Family Controls entitlement
  config = withEntitlementsPlist(config, (config) => {
    config.modResults['com.apple.developer.family-controls'] = true;
    return config;
  });

  // Add usage description for Family Controls
  config = withInfoPlist(config, (config) => {
    config.modResults.NSFamilyControlsUsageDescription =
      config.modResults.NSFamilyControlsUsageDescription ||
      'This app uses Screen Time controls to help you stay focused by blocking distracting apps during study sessions.';
    return config;
  });

  return config;
};

module.exports = withScreenTimeBlocker;
