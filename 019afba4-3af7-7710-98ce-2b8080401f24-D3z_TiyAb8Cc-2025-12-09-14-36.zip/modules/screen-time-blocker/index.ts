import { NativeModules, Platform } from 'react-native';

const LINKING_ERROR =
  `The package 'screen-time-blocker' doesn't seem to be linked. Make sure: \n\n` +
  Platform.select({ ios: "- You rebuilt the app after installing the package\n", default: '' }) +
  '- You are running on a physical device (Screen Time API does not work in simulator)\n' +
  '- You are running iOS 16 or later\n';

// Check if the native module is available
const isNativeModuleAvailable = !!NativeModules.ScreenTimeBlocker;

const ScreenTimeBlocker = isNativeModuleAvailable
  ? NativeModules.ScreenTimeBlocker
  : new Proxy(
      {},
      {
        get() {
          throw new Error(LINKING_ERROR);
        },
      }
    );

export interface FamilyActivitySelection {
  applicationTokens?: string[];
  categoryTokens?: string[];
}

/**
 * Screen Time Blocker Module
 * Uses Apple's Screen Time API (Family Controls) to block apps
 * iOS 16+ only
 */
class ScreenTimeBlockerModule {
  /**
   * Check if Screen Time API is available on this device
   * Returns false on simulator or Android
   */
  isAvailable(): boolean {
    if (Platform.OS !== 'ios') {
      return false;
    }
    // Check if native module is available before accessing it
    return isNativeModuleAvailable;
  }

  /**
   * Request authorization to use Screen Time API
   * This will show a system dialog that the user must approve
   * Also requires user to enable Screen Time in Settings
   */
  async requestAuthorization(): Promise<{ granted: boolean; error?: string }> {
    if (!this.isAvailable()) {
      return { granted: false, error: 'Screen Time API not available on this device' };
    }

    try {
      const result = await ScreenTimeBlocker.requestAuthorization();
      return result;
    } catch (error: any) {
      console.error('[ScreenTimeBlocker] Authorization error:', error);
      return { granted: false, error: error.message || 'Failed to request authorization' };
    }
  }

  /**
   * Check if we have authorization
   */
  async checkAuthorization(): Promise<boolean> {
    if (!this.isAvailable()) {
      return false;
    }

    try {
      const result = await ScreenTimeBlocker.checkAuthorization();
      return result.authorized || false;
    } catch (error: any) {
      console.error('[ScreenTimeBlocker] Check authorization error:', error);
      return false;
    }
  }

  /**
   * Present the Family Activity Picker to let user select apps to block
   * Returns selected app tokens
   */
  async presentAppPicker(): Promise<FamilyActivitySelection | null> {
    if (!this.isAvailable()) {
      throw new Error('Screen Time API not available');
    }

    try {
      const result = await ScreenTimeBlocker.presentAppPicker();
      return result.selection || null;
    } catch (error: any) {
      console.error('[ScreenTimeBlocker] App picker error:', error);
      return null;
    }
  }

  /**
   * Block the selected apps
   * @param selection - The selection from presentAppPicker
   */
  async blockApps(selection: FamilyActivitySelection): Promise<{ success: boolean; error?: string }> {
    if (!this.isAvailable()) {
      return { success: false, error: 'Screen Time API not available' };
    }

    try {
      await ScreenTimeBlocker.blockApps(selection);
      return { success: true };
    } catch (error: any) {
      console.error('[ScreenTimeBlocker] Block apps error:', error);
      return { success: false, error: error.message || 'Failed to block apps' };
    }
  }

  /**
   * Unblock all apps
   */
  async unblockAllApps(): Promise<{ success: boolean; error?: string }> {
    if (!this.isAvailable()) {
      return { success: false, error: 'Screen Time API not available' };
    }

    try {
      await ScreenTimeBlocker.unblockAllApps();
      return { success: true };
    } catch (error: any) {
      console.error('[ScreenTimeBlocker] Unblock apps error:', error);
      return { success: false, error: error.message || 'Failed to unblock apps' };
    }
  }

  /**
   * Schedule blocking for a specific time period
   * @param startDate - When to start blocking
   * @param endDate - When to stop blocking
   * @param selection - Apps to block
   */
  async scheduleBlocking(
    startDate: Date,
    endDate: Date,
    selection: FamilyActivitySelection
  ): Promise<{ success: boolean; error?: string }> {
    if (!this.isAvailable()) {
      return { success: false, error: 'Screen Time API not available' };
    }

    try {
      await ScreenTimeBlocker.scheduleBlocking({
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        selection,
      });
      return { success: true };
    } catch (error: any) {
      console.error('[ScreenTimeBlocker] Schedule blocking error:', error);
      return { success: false, error: error.message || 'Failed to schedule blocking' };
    }
  }
}

export default new ScreenTimeBlockerModule();
