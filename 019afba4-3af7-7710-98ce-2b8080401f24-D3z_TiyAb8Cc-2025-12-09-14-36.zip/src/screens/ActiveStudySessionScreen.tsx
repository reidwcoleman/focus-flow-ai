import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  Pressable,
  Alert,
  AppState,
  Platform,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { Coffee, Pause, Play, StopCircle, Clock } from "lucide-react-native";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import type { NativeStackNavigationProp } from "@react-navigation/native-stack";
import type { RootStackParamList } from "@/navigation/types";
import ScreenTimeBlocker from "../../modules/screen-time-blocker";
import { api } from "@/lib/api";
import type { CreateStudySessionResponse, UpdateStudySessionResponse, EndStudySessionResponse } from "shared/contracts";

type NavigationProp = NativeStackNavigationProp<RootStackParamList, "ActiveStudySession">;
type RouteParams = RouteProp<RootStackParamList, "ActiveStudySession">;

/**
 * ActiveStudySessionScreen
 * Shows active study timer with app blocking and break management
 */
export default function ActiveStudySessionScreen() {
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<RouteParams>();
  const { duration: plannedDuration, blockedApps } = route.params;

  const [sessionId, setSessionId] = useState<string | null>(null);
  const [timeRemaining, setTimeRemaining] = useState(plannedDuration * 60); // Convert to seconds
  const [breaksUsed, setBreaksUsed] = useState(0);
  const [onBreak, setOnBreak] = useState(false);
  const [breakTimeRemaining, setBreakTimeRemaining] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Start session on mount
  useEffect(() => {
    startSession();
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  // Timer countdown
  useEffect(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    timerRef.current = setInterval(() => {
      if (onBreak) {
        setBreakTimeRemaining((prev) => {
          if (prev <= 1) {
            endBreak();
            return 0;
          }
          return prev - 1;
        });
      } else {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            completeSession();
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [onBreak]);

  // Handle app state changes (user tries to leave app)
  useEffect(() => {
    const subscription = AppState.addEventListener("change", (nextAppState) => {
      if (nextAppState === "background" && !onBreak) {
        // User tried to leave app during study session
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      }
    });

    return () => {
      subscription.remove();
    };
  }, [onBreak]);

  const startSession = async () => {
    try {
      // Create session in database
      const response = await api.post<{ plannedDuration: number; blockedApps: string[] }, CreateStudySessionResponse>(
        "/study-sessions",
        {
          plannedDuration,
          blockedApps: blockedApps?.applicationTokens || [],
        }
      );

      setSessionId(response.session.id);

      // Block apps on iOS
      if (Platform.OS === "ios" && blockedApps) {
        const result = await ScreenTimeBlocker.blockApps(blockedApps);
        if (!result.success) {
          console.error("[ActiveStudySession] Failed to block apps:", result.error);
        }
      }

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error: any) {
      console.error("[ActiveStudySession] Failed to start session:", error);
      Alert.alert("Error", "Failed to start study session. Please try again.");
      navigation.goBack();
    }
  };

  const takeBreak = async () => {
    if (breaksUsed >= 3) {
      Alert.alert("No Breaks Left", "You've used all 3 breaks for this session. Stay focused! 💪");
      return;
    }

    Alert.alert(
      "Take a Break?",
      "You'll get 5 minutes. Apps will be unblocked temporarily.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Start Break",
          onPress: async () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            setOnBreak(true);
            setBreakTimeRemaining(5 * 60); // 5 minutes
            setBreaksUsed(breaksUsed + 1);

            // Temporarily unblock apps
            if (Platform.OS === "ios") {
              await ScreenTimeBlocker.unblockAllApps();
            }

            // Update session in database
            if (sessionId) {
              try {
                await api.patch<{ breaksUsed: number; breakTimeUsed: number }, UpdateStudySessionResponse>(
                  `/study-sessions/${sessionId}`,
                  {
                    breaksUsed: breaksUsed + 1,
                    breakTimeUsed: (breaksUsed + 1) * 5,
                  }
                );
              } catch (error) {
                console.error("[ActiveStudySession] Failed to update session:", error);
              }
            }
          },
        },
      ]
    );
  };

  const endBreak = async () => {
    setOnBreak(false);
    setBreakTimeRemaining(0);

    // Re-block apps
    if (Platform.OS === "ios" && blockedApps) {
      await ScreenTimeBlocker.blockApps(blockedApps);
    }

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert("Break Over! 📚", "Time to get back to work. You got this!");
  };

  const completeSession = async () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    // Unblock apps
    if (Platform.OS === "ios") {
      await ScreenTimeBlocker.unblockAllApps();
    }

    // End session in database
    if (sessionId) {
      try {
        await api.post<{}, EndStudySessionResponse>(`/study-sessions/${sessionId}/end`, {});
      } catch (error) {
        console.error("[ActiveStudySession] Failed to end session:", error);
      }
    }

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    Alert.alert(
      "🎉 Session Complete!",
      `Great job! You focused for ${plannedDuration} minutes and used ${breaksUsed}/3 breaks.`,
      [
        {
          text: "Done",
          onPress: () => {
            navigation.reset({
              index: 0,
              routes: [{ name: "Tabs" }],
            });
          },
        },
      ]
    );
  };

  const cancelSession = () => {
    Alert.alert(
      "End Session Early?",
      "Are you sure you want to end your study session? Your progress will still be saved.",
      [
        { text: "Keep Going", style: "cancel" },
        {
          text: "End Session",
          style: "destructive",
          onPress: async () => {
            if (timerRef.current) {
              clearInterval(timerRef.current);
            }

            // Unblock apps
            if (Platform.OS === "ios") {
              await ScreenTimeBlocker.unblockAllApps();
            }

            // Cancel session in database
            if (sessionId) {
              try {
                await api.post(`/study-sessions/${sessionId}/cancel`, {});
              } catch (error) {
                console.error("[ActiveStudySession] Failed to cancel session:", error);
              }
            }

            navigation.reset({
              index: 0,
              routes: [{ name: "Tabs" }],
            });
          },
        },
      ]
    );
  };

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <View style={{ flex: 1, backgroundColor: onBreak ? "#FEF3C7" : "#DBEAFE" }}>
      <SafeAreaView edges={["top"]} style={{ flex: 1 }}>
        {/* Header */}
        <View style={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 12 }}>
          <Text style={{ fontSize: 14, fontWeight: "600", color: onBreak ? "#92400E" : "#1E40AF", textAlign: "center" }}>
            {onBreak ? "ON BREAK" : "STUDY SESSION"}
          </Text>
        </View>

        {/* Main Timer */}
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 20 }}>
          <LinearGradient
            colors={onBreak ? ["#F59E0B", "#D97706"] : ["#3A7BFF", "#2563EB"]}
            style={{
              width: 280,
              height: 280,
              borderRadius: 140,
              alignItems: "center",
              justifyContent: "center",
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.2,
              shadowRadius: 16,
            }}
          >
            <View
              style={{
                width: 260,
                height: 260,
                borderRadius: 130,
                backgroundColor: "white",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text style={{ fontSize: 64, fontWeight: "800", color: onBreak ? "#F59E0B" : "#3A7BFF" }}>
                {formatTime(onBreak ? breakTimeRemaining : timeRemaining)}
              </Text>
              <Text style={{ fontSize: 16, color: "#6B7280", marginTop: 8 }}>
                {onBreak ? "Break Time" : "Remaining"}
              </Text>
            </View>
          </LinearGradient>

          {/* Progress Info */}
          <View style={{ marginTop: 40, gap: 16, width: "100%" }}>
            <View
              style={{
                backgroundColor: "white",
                borderRadius: 16,
                padding: 20,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <Coffee size={24} color={breaksUsed >= 3 ? "#D1D5DB" : "#3A7BFF"} />
                <View>
                  <Text style={{ fontSize: 14, color: "#6B7280" }}>Breaks Used</Text>
                  <Text style={{ fontSize: 20, fontWeight: "700", color: "#0B0D12", marginTop: 2 }}>
                    {breaksUsed}/3
                  </Text>
                </View>
              </View>
              {!onBreak && breaksUsed < 3 && (
                <Pressable
                  onPress={takeBreak}
                  style={{
                    backgroundColor: "#3A7BFF",
                    borderRadius: 12,
                    paddingHorizontal: 20,
                    paddingVertical: 10,
                  }}
                >
                  <Text style={{ fontSize: 14, fontWeight: "600", color: "white" }}>Take Break</Text>
                </Pressable>
              )}
            </View>

            <View
              style={{
                backgroundColor: "white",
                borderRadius: 16,
                padding: 20,
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
              }}
            >
              <Clock size={24} color="#3A7BFF" />
              <View>
                <Text style={{ fontSize: 14, color: "#6B7280" }}>Session Length</Text>
                <Text style={{ fontSize: 20, fontWeight: "700", color: "#0B0D12", marginTop: 2 }}>
                  {plannedDuration} minutes
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Cancel Button */}
        {!onBreak && (
          <View style={{ padding: 20, paddingBottom: 32 }}>
            <Pressable
              onPress={cancelSession}
              style={{
                backgroundColor: "white",
                borderRadius: 16,
                paddingVertical: 18,
                borderWidth: 2,
                borderColor: "#EF4444",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                gap: 10,
              }}
            >
              <StopCircle size={20} color="#EF4444" />
              <Text style={{ fontSize: 17, fontWeight: "600", color: "#EF4444" }}>End Session Early</Text>
            </Pressable>
          </View>
        )}

        {/* Break in Progress Notice */}
        {onBreak && (
          <View style={{ padding: 20, paddingBottom: 32 }}>
            <View
              style={{
                backgroundColor: "white",
                borderRadius: 16,
                padding: 20,
                alignItems: "center",
              }}
            >
              <Coffee size={32} color="#F59E0B" />
              <Text style={{ fontSize: 18, fontWeight: "700", color: "#0B0D12", marginTop: 12 }}>
                Enjoy Your Break!
              </Text>
              <Text style={{ fontSize: 14, color: "#6B7280", textAlign: "center", marginTop: 8 }}>
                Apps are temporarily unblocked. The timer will resume automatically when your break ends.
              </Text>
            </View>
          </View>
        )}
      </SafeAreaView>
    </View>
  );
}
