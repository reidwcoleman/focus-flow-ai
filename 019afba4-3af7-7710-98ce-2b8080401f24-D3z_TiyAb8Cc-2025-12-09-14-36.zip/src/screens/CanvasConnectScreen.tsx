import React, { useState, useEffect } from "react";
import { View, Text, TextInput, Pressable, ScrollView, Alert, Linking } from "react-native";
import { BookOpen, Check, RefreshCw, ChevronRight, ExternalLink, HelpCircle } from "lucide-react-native";
import * as Haptics from "expo-haptics";
import { useNavigation, useRoute } from "@react-navigation/native";

import type { RootStackScreenProps } from "@/navigation/types";
import { api } from "@/lib/api";
import type { GetCanvasStatusResponse, ConnectCanvasRequest, ConnectCanvasResponse, SyncCanvasResponse } from "@/shared/contracts";

type Props = RootStackScreenProps<"CanvasConnect"> | RootStackScreenProps<"CanvasOnboarding">;

const CanvasConnectScreen = ({ navigation, route }: Props) => {
  const [canvasUrl, setCanvasUrl] = useState("");
  const [accessToken, setAccessToken] = useState("");
  const [status, setStatus] = useState<GetCanvasStatusResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [step, setStep] = useState<"url" | "token" | "ready">("url");
  const [showInstructions, setShowInstructions] = useState(false);

  // Check if this is onboarding flow
  const isOnboarding = route.name === "CanvasOnboarding";

  const handleSkip = () => {
    if (isOnboarding) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      Alert.alert(
        "Skip Canvas Setup?",
        "You can always connect Canvas later from Settings. Are you sure you want to skip?",
        [
          { text: "Cancel", style: "cancel" },
          {
            text: "Skip",
            style: "destructive",
            onPress: () => {
              // Mark Canvas as "skipped" by creating a dummy connection status
              // This allows user to access the app
              if (navigation.canGoBack()) {
                navigation.goBack();
              } else {
                // Force navigation to main app by reloading
                (navigation as any).reset({
                  index: 0,
                  routes: [{ name: "Tabs" }],
                });
              }
            }
          }
        ]
      );
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  const fetchStatus = async () => {
    try {
      const response = await api.get<GetCanvasStatusResponse>("/canvas/status");
      setStatus(response);
    } catch (error: any) {
      if (error?.status !== 401) {
        console.log("Error fetching Canvas status:", error);
      }
    }
  };

  const normalizeCanvasUrl = (url: string) => {
    let normalized = url.trim().toLowerCase();
    if (!normalized.startsWith("http://") && !normalized.startsWith("https://")) {
      normalized = "https://" + normalized;
    }
    return normalized.replace(/\/$/, "");
  };

  const handleUrlContinue = () => {
    if (!canvasUrl) return;
    const normalized = normalizeCanvasUrl(canvasUrl);
    setCanvasUrl(normalized);
    setStep("token");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleConnect = async () => {
    if (!canvasUrl || !accessToken) return;

    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      const normalized = normalizeCanvasUrl(canvasUrl);
      console.log("Attempting to connect to Canvas:", normalized);
      const response = await api.post<ConnectCanvasRequest, ConnectCanvasResponse>("/canvas/connect", {
        canvasUrl: normalized,
        accessToken: accessToken.trim()
      });
      console.log("Canvas connection response:", response);

      // Check if the connection was actually successful
      if (!response.success) {
        // Connection failed - show error message
        Alert.alert(
          "Connection Failed",
          response.message || "Failed to connect to Canvas. Please check your URL and access token.",
          [{ text: "OK" }],
          { cancelable: true }
        );
        return;
      }

      // Connection successful - fetch status to confirm and trigger auto-sync
      await fetchStatus();

      Alert.alert(
        "Success",
        "Canvas connected! Syncing your data now...",
        [{ text: "OK", onPress: () => handleSync() }]
      );

      setCanvasUrl("");
      setAccessToken("");
      setStep("url");
    } catch (error: any) {
      console.log("Canvas connection error:", error);
      const errorMessage = error?.message || "Failed to connect to Canvas. Please check your URL and access token.";

      // Show detailed error in alert
      Alert.alert(
        "Connection Failed",
        errorMessage,
        [{ text: "OK" }],
        { cancelable: true }
      );
    } finally {
      setLoading(false);
    }
  };

  const openCanvasInstructions = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    // Try to open the user's Canvas settings page directly
    if (canvasUrl) {
      const normalized = normalizeCanvasUrl(canvasUrl);
      Linking.openURL(`${normalized}/profile/settings`);
    }
  };

  const handleSync = async () => {
    setSyncing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      const response = await api.post<{}, SyncCanvasResponse>("/canvas/sync", {});
      console.log("[Canvas] Sync complete:", response);
      Alert.alert(
        "Sync Complete!",
        `Imported:\n• ${response.coursesImported} courses\n• ${response.assignmentsImported} assignments\n• ${response.gradesImported} grades\n• ${response.scheduleBlocksCreated} schedule blocks`
      );
      fetchStatus();
    } catch (error) {
      console.log("[Canvas] Sync error:", error);
      Alert.alert("Error", "Failed to sync Canvas data. Please try again.");
    } finally {
      setSyncing(false);
    }
  };

  const handleDisconnect = async () => {
    Alert.alert("Disconnect Canvas?", "Your assignments won't be deleted.", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Disconnect",
        style: "destructive",
        onPress: async () => {
          try {
            await api.delete("/canvas/disconnect");
            fetchStatus();
            Alert.alert("Disconnected", "Canvas has been disconnected.");
          } catch (error) {
            Alert.alert("Error", "Failed to disconnect.");
          }
        },
      },
    ]);
  };

  const renderConnectedState = () => (
    <View>
      <View style={{ backgroundColor: "white", borderRadius: 16, padding: 24, marginBottom: 16 }}>
        <View style={{ alignItems: "center", marginBottom: 20 }}>
          <View
            style={{
              width: 64,
              height: 64,
              borderRadius: 32,
              backgroundColor: "#10B981",
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 12,
            }}
          >
            <Check size={32} color="white" />
          </View>
          <Text style={{ fontSize: 20, fontWeight: "700", color: "#111827", marginBottom: 6 }}>
            Canvas Connected
          </Text>
          <Text style={{ fontSize: 14, color: "#6B7280", textAlign: "center", marginBottom: 4 }}>
            {status?.canvasUrl}
          </Text>
          {status?.lastSyncAt && (
            <Text style={{ fontSize: 13, color: "#9CA3AF", textAlign: "center" }}>
              Last synced: {new Date(status.lastSyncAt).toLocaleString()}
            </Text>
          )}
        </View>

        <Pressable
          onPress={handleSync}
          disabled={syncing}
          style={({ pressed }) => ({
            backgroundColor: pressed ? "#2563EB" : "#3A7BFF",
            borderRadius: 12,
            padding: 16,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            marginBottom: 12,
            opacity: syncing ? 0.7 : 1,
          })}
        >
          <RefreshCw size={20} color="white" />
          <Text style={{ color: "white", fontWeight: "600", fontSize: 16 }}>
            {syncing ? "Syncing..." : "Sync Now"}
          </Text>
        </Pressable>

        <Pressable
          onPress={() => {
            setCanvasUrl(status?.canvasUrl || "");
            setAccessToken("");
            setStep("token");
          }}
          style={({ pressed }) => ({
            backgroundColor: pressed ? "#F3F4F6" : "transparent",
            borderRadius: 12,
            padding: 16,
            alignItems: "center",
            borderWidth: 1,
            borderColor: "#D1D5DB",
            marginBottom: 12,
          })}
        >
          <Text style={{ color: "#6B7280", fontWeight: "600", fontSize: 15 }}>Update Connection</Text>
        </Pressable>

        <Pressable
          onPress={handleDisconnect}
          style={({ pressed }) => ({
            backgroundColor: pressed ? "#FEE2E2" : "transparent",
            borderRadius: 12,
            padding: 16,
            alignItems: "center",
            borderWidth: 1,
            borderColor: "#FEE2E2",
          })}
        >
          <Text style={{ color: "#EF4444", fontWeight: "600", fontSize: 15 }}>Disconnect Canvas</Text>
        </Pressable>
      </View>

      <View style={{ backgroundColor: "#DBEAFE", borderRadius: 12, padding: 16 }}>
        <Text style={{ fontSize: 13, fontWeight: "600", color: "#1E3A8A", marginBottom: 4 }}>
          💡 Auto-Sync Tip
        </Text>
        <Text style={{ fontSize: 12, color: "#1E40AF", lineHeight: 18 }}>
          Tap &quot;Sync Now&quot; to manually refresh, or use &quot;Update Connection&quot; if you need to enter a new access token.
        </Text>
      </View>
    </View>
  );

  const renderSetupWizard = () => (
    <View>
      <View style={{ alignItems: "center", marginBottom: 32 }}>
        <View
          style={{
            width: 80,
            height: 80,
            borderRadius: 40,
            backgroundColor: "#EBF2FF",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 16,
          }}
        >
          <BookOpen size={38} color="#3A7BFF" />
        </View>
        <Text style={{ fontSize: 24, fontWeight: "700", color: "#111827", marginBottom: 8 }}>
          Connect to Canvas
        </Text>
        <Text style={{ fontSize: 15, color: "#6B7280", textAlign: "center", maxWidth: 320, lineHeight: 22 }}>
          Import assignments, grades, and schedules automatically from your Canvas account
        </Text>
      </View>

      {/* Step Indicators */}
      <View style={{ flexDirection: "row", marginBottom: 24, gap: 8 }}>
        <View style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: step === "url" ? "#3A7BFF" : "#10B981" }} />
        <View style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: step === "token" ? "#3A7BFF" : step === "ready" ? "#10B981" : "#E5E7EB" }} />
      </View>

      {/* Step 1: Canvas URL */}
      {step === "url" && (
        <View style={{ backgroundColor: "white", borderRadius: 16, padding: 20, marginBottom: 16 }}>
          <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 16 }}>
            <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: "#EBF2FF", alignItems: "center", justifyContent: "center", marginRight: 12 }}>
              <Text style={{ fontSize: 16, fontWeight: "700", color: "#3A7BFF" }}>1</Text>
            </View>
            <Text style={{ fontSize: 18, fontWeight: "700", color: "#111827", flex: 1 }}>
              Enter Canvas URL
            </Text>
          </View>

          <Text style={{ fontSize: 14, color: "#6B7280", marginBottom: 12, lineHeight: 20 }}>
            Enter your school&apos;s Canvas URL (we&apos;ll add https:// automatically):
          </Text>

          <View style={{ backgroundColor: "#F9FAFB", borderRadius: 8, padding: 12, marginBottom: 8 }}>
            <Text style={{ fontSize: 13, color: "#4B5563", fontFamily: "monospace" }}>
              canvas.instructure.com{"\n"}
              yourschool.instructure.com{"\n"}
              canvas.yourschool.edu
            </Text>
          </View>

          <View style={{ backgroundColor: "#FEF3C7", borderRadius: 8, padding: 10, marginBottom: 16, flexDirection: "row", alignItems: "center" }}>
            <Text style={{ fontSize: 20, marginRight: 8 }}>💡</Text>
            <Text style={{ fontSize: 12, color: "#92400E", flex: 1 }}>
              Don&apos;t include &quot;https://&quot; - just enter the domain name
            </Text>
          </View>

          <TextInput
            value={canvasUrl}
            onChangeText={setCanvasUrl}
            placeholder="canvas.yourschool.edu"
            autoCapitalize="none"
            keyboardType="url"
            autoCorrect={false}
            returnKeyType="next"
            onSubmitEditing={handleUrlContinue}
            blurOnSubmit={false}
            style={{
              backgroundColor: "#F9FAFB",
              borderRadius: 10,
              padding: 14,
              fontSize: 16,
              marginBottom: 8,
              borderWidth: 2,
              borderColor: canvasUrl ? "#3A7BFF" : "#E5E7EB",
            }}
          />

          {canvasUrl && (
            <View style={{ marginBottom: 16 }}>
              <Text style={{ fontSize: 12, color: "#6B7280", marginBottom: 4 }}>
                Will connect to:
              </Text>
              <Text style={{ fontSize: 13, color: "#3A7BFF", fontWeight: "600", fontFamily: "monospace" }}>
                {normalizeCanvasUrl(canvasUrl)}
              </Text>
            </View>
          )}

          <Pressable
            onPress={handleUrlContinue}
            disabled={!canvasUrl}
            style={({ pressed }) => ({
              backgroundColor: canvasUrl ? (pressed ? "#2563EB" : "#3A7BFF") : "#E5E7EB",
              borderRadius: 12,
              padding: 16,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
            })}
          >
            <Text style={{ color: "white", fontWeight: "600", fontSize: 16 }}>
              Continue
            </Text>
            <ChevronRight size={20} color="white" />
          </Pressable>
        </View>
      )}

      {/* Step 2: Access Token */}
      {step === "token" && (
        <View style={{ backgroundColor: "white", borderRadius: 16, padding: 20, marginBottom: 16 }}>
          <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 16 }}>
            <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: "#EBF2FF", alignItems: "center", justifyContent: "center", marginRight: 12 }}>
              <Text style={{ fontSize: 16, fontWeight: "700", color: "#3A7BFF" }}>2</Text>
            </View>
            <Text style={{ fontSize: 18, fontWeight: "700", color: "#111827", flex: 1 }}>
              Get Access Token
            </Text>
          </View>

          {/* Instructions Card */}
          <Pressable
            onPress={openCanvasInstructions}
            style={({ pressed }) => ({
              backgroundColor: pressed ? "#F0F9FF" : "#EBF5FF",
              borderRadius: 12,
              padding: 16,
              marginBottom: 16,
              borderWidth: 1,
              borderColor: "#BFDBFE",
            })}
          >
            <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 12 }}>
              <HelpCircle size={20} color="#3A7BFF" style={{ marginRight: 8 }} />
              <Text style={{ fontSize: 14, fontWeight: "600", color: "#1E3A8A" }}>
                How to get your token:
              </Text>
            </View>
            <Text style={{ fontSize: 13, color: "#1E40AF", lineHeight: 20, marginBottom: 12 }}>
              1. Tap here to open Canvas Settings{"\n"}
              2. Scroll to &quot;Approved Integrations&quot;{"\n"}
              3. Click &quot;+ New Access Token&quot;{"\n"}
              4. Purpose: &quot;FocusTwin AI&quot;{"\n"}
              5. Expires: Select &quot;Never&quot; (recommended){"\n"}
              6. Click &quot;Generate Token&quot;{"\n"}
              7. Copy the ENTIRE token{"\n"}
              8. Paste it below (don&apos;t add spaces!)
            </Text>
            <View style={{ backgroundColor: "#FEF3C7", borderRadius: 8, padding: 10, marginBottom: 8 }}>
              <Text style={{ fontSize: 12, color: "#92400E", fontWeight: "600" }}>
                ⚠️ Important: Copy the full token - it&apos;s usually 60+ characters long!
              </Text>
            </View>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <ExternalLink size={16} color="#3A7BFF" style={{ marginRight: 6 }} />
              <Text style={{ fontSize: 13, fontWeight: "600", color: "#3A7BFF" }}>
                Open Canvas Settings
              </Text>
            </View>
          </Pressable>

          <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 8 }}>
            Paste Access Token
          </Text>
          <TextInput
            value={accessToken}
            onChangeText={setAccessToken}
            placeholder="Paste your Canvas token here"
            secureTextEntry
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="off"
            textContentType="none"
            returnKeyType="done"
            onSubmitEditing={handleConnect}
            enablesReturnKeyAutomatically
            multiline={false}
            style={{
              backgroundColor: "#F9FAFB",
              borderRadius: 10,
              padding: 14,
              fontSize: 16,
              marginBottom: 16,
              borderWidth: 2,
              borderColor: accessToken ? "#10B981" : "#E5E7EB",
            }}
          />

          <View style={{ flexDirection: "row", gap: 12 }}>
            <Pressable
              onPress={() => setStep("url")}
              style={({ pressed }) => ({
                flex: 1,
                backgroundColor: pressed ? "#F3F4F6" : "transparent",
                borderRadius: 12,
                padding: 16,
                alignItems: "center",
                borderWidth: 1,
                borderColor: "#E5E7EB",
              })}
            >
              <Text style={{ color: "#6B7280", fontWeight: "600", fontSize: 15 }}>Back</Text>
            </Pressable>

            <Pressable
              onPress={handleConnect}
              disabled={loading || !accessToken}
              style={({ pressed }) => ({
                flex: 2,
                backgroundColor: accessToken && !loading ? (pressed ? "#059669" : "#10B981") : "#E5E7EB",
                borderRadius: 12,
                padding: 16,
                alignItems: "center",
              })}
            >
              <Text style={{ color: "white", fontWeight: "600", fontSize: 16 }}>
                {loading ? "Connecting..." : "Connect Canvas"}
              </Text>
            </Pressable>
          </View>
        </View>
      )}

      {/* Security Note */}
      <View style={{ backgroundColor: "#F9FAFB", borderRadius: 12, padding: 16, flexDirection: "row", gap: 12, marginBottom: 16 }}>
        <Text style={{ fontSize: 24 }}>🔒</Text>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 13, fontWeight: "600", color: "#374151", marginBottom: 4 }}>
            Your data is secure
          </Text>
          <Text style={{ fontSize: 12, color: "#6B7280", lineHeight: 18 }}>
            Your Canvas token is encrypted and stored securely. We only read your assignments and grades—we never modify anything.
          </Text>
        </View>
      </View>

      {/* Skip Button (only shown during onboarding) */}
      {isOnboarding && (
        <Pressable
          onPress={handleSkip}
          style={({ pressed }) => ({
            backgroundColor: pressed ? "#F3F4F6" : "transparent",
            borderRadius: 12,
            padding: 16,
            alignItems: "center",
          })}
        >
          <Text style={{ color: "#6B7280", fontWeight: "500", fontSize: 14 }}>
            Skip for now - I&apos;ll connect later
          </Text>
        </Pressable>
      )}
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 100 }}>
        {status?.connected ? renderConnectedState() : renderSetupWizard()}
      </ScrollView>
    </View>
  );
};

export default CanvasConnectScreen;
