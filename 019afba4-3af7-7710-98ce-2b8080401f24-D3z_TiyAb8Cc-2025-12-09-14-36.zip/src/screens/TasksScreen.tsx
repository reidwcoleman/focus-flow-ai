import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, Pressable, RefreshControl } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CheckCircle2, Circle, Clock, BookOpen, AlertCircle } from "lucide-react-native";
import * as Haptics from "expo-haptics";

import type { BottomTabScreenProps } from "@/navigation/types";
import { api } from "@/lib/api";
import type { GetAssignmentsResponse } from "@/shared/contracts";
import { theme } from "@/theme/theme";

type Props = BottomTabScreenProps<"TasksTab">;

const TasksScreen = ({ navigation }: Props) => {
  const insets = useSafeAreaInsets();
  const [assignments, setAssignments] = useState<GetAssignmentsResponse["assignments"]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchAssignments = async () => {
    try {
      const response = await api.get<GetAssignmentsResponse>("/assignments");
      setAssignments(response?.assignments || []);
    } catch (error: any) {
      console.log("Error fetching assignments:", error);
      setAssignments([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchAssignments();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    fetchAssignments();
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
        return theme.colors.priorityUrgent;
      case "high":
        return theme.colors.priorityHigh;
      case "medium":
        return theme.colors.priorityMedium;
      case "low":
        return theme.colors.priorityLow;
      default:
        return theme.colors.textSecondary;
    }
  };

  const getPriorityLabel = (priority: string) => {
    return priority.charAt(0).toUpperCase() + priority.slice(1);
  };

  const getDaysUntilDue = (dueDate: string) => {
    const due = new Date(dueDate);
    const now = new Date();
    const diff = due.getTime() - now.getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));

    if (days < 0) return `${Math.abs(days)}d overdue`;
    if (days === 0) return "Due today";
    if (days === 1) return "Due tomorrow";
    return `${days} days`;
  };

  const formatDueDate = (dueDate: string) => {
    const date = new Date(dueDate);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  // Group assignments by status
  const todoTasks = assignments.filter((a) => a.status === "todo");
  const inProgressTasks = assignments.filter((a) => a.status === "in_progress");
  const completedTasks = assignments.filter((a) => a.status === "completed");

  const renderTaskCard = (assignment: GetAssignmentsResponse["assignments"][0]) => {
    const isCompleted = assignment.status === "completed";
    const isOverdue = assignment.dueDate && new Date(assignment.dueDate) < new Date() && !isCompleted;

    return (
      <Pressable
        key={assignment.id}
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          navigation.navigate("AssignmentDetail", { assignmentId: assignment.id });
        }}
        style={({ pressed }) => ({
          backgroundColor: theme.colors.secondary,
          borderRadius: theme.borderRadius.md,
          padding: theme.spacing.lg,
          marginBottom: theme.spacing.md,
          borderWidth: theme.borderWidth,
          borderColor: theme.colors.border,
          opacity: pressed ? 0.8 : 1,
          flexDirection: "row",
          alignItems: "center",
          gap: theme.spacing.md,
        })}
      >
        {/* Priority Dot */}
        <View
          style={{
            width: theme.priorityDotSize,
            height: theme.priorityDotSize,
            borderRadius: theme.priorityDotSize / 2,
            backgroundColor: getPriorityColor(assignment.priority),
          }}
        />

        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 6 }}>
            {isCompleted ? (
              <CheckCircle2 size={16} color={theme.colors.success} style={{ marginRight: 8 }} />
            ) : (
              <Circle size={16} color={theme.colors.textSecondary} style={{ marginRight: 8 }} />
            )}
            <Text
              style={{
                fontSize: theme.fontSize.md,
                fontWeight: theme.fontWeight.semibold,
                color: isCompleted ? theme.colors.textSecondary : theme.colors.textPrimary,
                textDecorationLine: isCompleted ? "line-through" : "none",
                flex: 1,
              }}
              numberOfLines={2}
            >
              {assignment.title}
            </Text>
          </View>

          {assignment.subject && (
            <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 6 }}>
              <BookOpen size={12} color={theme.colors.textSecondary} style={{ marginRight: 6 }} />
              <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary }}>
                {assignment.subject.name}
              </Text>
            </View>
          )}

          {assignment.dueDate && (
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Clock size={12} color={isOverdue ? theme.colors.error : theme.colors.textSecondary} style={{ marginRight: 6 }} />
              <Text style={{ fontSize: theme.fontSize.sm, color: isOverdue ? theme.colors.error : theme.colors.textSecondary }}>
                {formatDueDate(assignment.dueDate)} • {getDaysUntilDue(assignment.dueDate)}
              </Text>
            </View>
          )}
        </View>

        {isOverdue && (
          <AlertCircle size={16} color={theme.colors.error} style={{ marginLeft: 8 }} />
        )}
      </Pressable>
    );
  };

  const renderSection = (title: string, tasks: typeof assignments, emptyMessage: string) => {
    if (tasks.length === 0) return null;

    return (
      <View style={{ marginBottom: theme.spacing.xxl }}>
        <View style={{ flexDirection: "row", alignItems: "center", marginBottom: theme.spacing.md }}>
          <Text style={{
            fontSize: theme.fontSize.md,
            fontWeight: theme.fontWeight.semibold,
            color: theme.colors.textPrimary,
            letterSpacing: theme.letterSpacing.wide,
          }}>
            {title.toUpperCase()}
          </Text>
          <View
            style={{
              backgroundColor: theme.colors.border,
              paddingHorizontal: 8,
              paddingVertical: 2,
              borderRadius: theme.borderRadius.sm,
              marginLeft: theme.spacing.sm,
            }}
          >
            <Text style={{ fontSize: theme.fontSize.xs, fontWeight: theme.fontWeight.semibold, color: theme.colors.textSecondary }}>
              {tasks.length}
            </Text>
          </View>
        </View>
        {tasks.map(renderTaskCard)}
      </View>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.primary }}>
      <View style={{ paddingTop: insets.top, paddingBottom: theme.spacing.lg, paddingHorizontal: theme.spacing.xl }}>
        <Text style={{ fontSize: theme.fontSize.xxxl, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: 4 }}>
          Tasks
        </Text>
        <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary }}>
          {todoTasks.length + inProgressTasks.length} tasks to complete
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingHorizontal: theme.spacing.xl, paddingBottom: 100 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.accent} />
        }
      >
        {assignments.length === 0 && !loading ? (
          <View style={{ alignItems: "center", paddingTop: 60 }}>
            <View
              style={{
                width: 80,
                height: 80,
                borderRadius: 40,
                backgroundColor: `${theme.colors.accent}20`,
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 16,
              }}
            >
              <CheckCircle2 size={40} color={theme.colors.accent} />
            </View>
            <Text style={{ fontSize: theme.fontSize.xl, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: 8 }}>
              No tasks yet
            </Text>
            <Text style={{ fontSize: theme.fontSize.base, color: theme.colors.textSecondary, textAlign: "center", maxWidth: 280 }}>
              Connect Canvas to import assignments or add tasks manually
            </Text>
          </View>
        ) : (
          <>
            {renderSection("To Do", todoTasks, "No tasks to do")}
            {renderSection("In Progress", inProgressTasks, "No tasks in progress")}
            {renderSection("Completed", completedTasks, "No completed tasks")}
          </>
        )}
      </ScrollView>
    </View>
  );
};

export default TasksScreen;
