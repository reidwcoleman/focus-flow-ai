import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  RefreshControl,
  ActivityIndicator,
  Pressable,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Clock,
  Award,
  Target,
  Zap,
  BarChart3,
} from "lucide-react-native";
import { api } from "@/lib/api";
import type { GetAnalyticsResponse } from "shared/contracts";
import { theme } from "@/theme/theme";

/**
 * AnalyticsScreen
 * Comprehensive analytics dashboard with grade trends, study patterns, and insights
 */
export default function AnalyticsScreen() {
  const [analytics, setAnalytics] = useState<GetAnalyticsResponse["analytics"] | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      const response = await api.get<GetAnalyticsResponse>("/analytics");
      setAnalytics(response.analytics);
    } catch (error) {
      console.log("[Analytics] Failed to load analytics:", error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadAnalytics();
  };

  const getTrendIcon = (trend: "improving" | "stable" | "slipping" | null) => {
    if (trend === "improving") return <TrendingUp size={16} color={theme.colors.success} />;
    if (trend === "slipping") return <TrendingDown size={16} color={theme.colors.error} />;
    return <Minus size={16} color={theme.colors.textSecondary} />;
  };

  const getTrendColor = (trend: "improving" | "stable" | "slipping" | null) => {
    if (trend === "improving") return theme.colors.success;
    if (trend === "slipping") return theme.colors.error;
    return theme.colors.textSecondary;
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.primary, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator size="large" color={theme.colors.accent} />
      </View>
    );
  }

  if (!analytics) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.primary, alignItems: "center", justifyContent: "center" }}>
        <Text style={{ fontSize: theme.fontSize.md, color: theme.colors.textSecondary }}>No analytics data available</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.primary }}>
      <SafeAreaView edges={["top"]} style={{ flex: 1 }}>
        <ScrollView
          style={{ flex: 1 }}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.accent} />}
        >
          {/* Header */}
          <View style={{ paddingHorizontal: theme.spacing.xl, paddingTop: theme.spacing.lg, paddingBottom: theme.spacing.md }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: theme.spacing.md, marginBottom: theme.spacing.sm }}>
              <View
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: theme.borderRadius.md,
                  backgroundColor: theme.colors.secondary,
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: theme.borderWidth,
                  borderColor: theme.colors.border,
                }}
              >
                <BarChart3 size={24} color={theme.colors.accent} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: theme.fontSize.xxxl, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>
                  Analytics
                </Text>
                <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginTop: 2 }}>
                  Your performance insights
                </Text>
              </View>
            </View>
          </View>

          {/* Weekly Report Card */}
          <View style={{ marginHorizontal: theme.spacing.xl, marginBottom: theme.spacing.lg }}>
            <View
              style={{
                backgroundColor: theme.colors.accent,
                borderRadius: theme.borderRadius.lg,
                padding: theme.spacing.xl,
                borderWidth: theme.borderWidth,
                borderColor: theme.colors.accent,
              }}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: theme.spacing.md, marginBottom: theme.spacing.md }}>
                <Clock size={20} color={theme.colors.textPrimary} />
                <Text style={{ fontSize: theme.fontSize.lg, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>
                  Weekly Report
                </Text>
              </View>
              <Text style={{ fontSize: theme.fontSize.md, color: theme.colors.textPrimary, lineHeight: 22, marginBottom: theme.spacing.lg }}>
                {analytics.weeklyReport.message}
              </Text>
              <View style={{ flexDirection: "row", gap: theme.spacing.md }}>
                <View style={{ flex: 1, backgroundColor: `${theme.colors.primary}60`, borderRadius: theme.borderRadius.md, padding: theme.spacing.lg }}>
                  <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textPrimary, marginBottom: 4 }}>
                    This Week
                  </Text>
                  <Text style={{ fontSize: theme.fontSize.xxl, fontWeight: theme.fontWeight.bold, color: theme.colors.textPrimary }}>
                    {analytics.weeklyReport.thisWeekHours}h
                  </Text>
                </View>
                <View style={{ flex: 1, backgroundColor: `${theme.colors.primary}60`, borderRadius: theme.borderRadius.md, padding: theme.spacing.lg }}>
                  <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textPrimary, marginBottom: 4 }}>
                    Last Week
                  </Text>
                  <Text style={{ fontSize: theme.fontSize.xxl, fontWeight: theme.fontWeight.bold, color: theme.colors.textPrimary }}>
                    {analytics.weeklyReport.lastWeekHours}h
                  </Text>
                </View>
                {analytics.weeklyReport.changePercent !== 0 && (
                  <View
                    style={{
                      position: "absolute",
                      top: 0,
                      right: 0,
                      backgroundColor: analytics.weeklyReport.changePercent > 0 ? theme.colors.success : theme.colors.error,
                      borderRadius: theme.borderRadius.sm,
                      paddingHorizontal: theme.spacing.md,
                      paddingVertical: theme.spacing.sm,
                    }}
                  >
                    <Text style={{ fontSize: theme.fontSize.sm, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>
                      {analytics.weeklyReport.changePercent > 0 ? "+" : ""}
                      {analytics.weeklyReport.changePercent}%
                    </Text>
                  </View>
                )}
              </View>
            </View>
          </View>

          {/* Productivity Insight */}
          {analytics.productivity.insight && (
            <View style={{ marginHorizontal: theme.spacing.xl, marginBottom: theme.spacing.lg }}>
              <View
                style={{
                  backgroundColor: theme.colors.secondary,
                  borderRadius: theme.borderRadius.lg,
                  padding: theme.spacing.xl,
                  borderWidth: theme.borderWidth,
                  borderColor: theme.colors.border,
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "center", gap: theme.spacing.md, marginBottom: theme.spacing.md }}>
                  <Zap size={20} color={theme.colors.warning} fill={theme.colors.warning} />
                  <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>
                    Productivity Pattern
                  </Text>
                </View>
                <Text style={{ fontSize: theme.fontSize.md, color: theme.colors.textSecondary, lineHeight: 22 }}>
                  {analytics.productivity.insight}
                </Text>

                {/* Time of Day Breakdown */}
                <View style={{ marginTop: theme.spacing.lg, gap: theme.spacing.sm }}>
                  {[
                    { label: "Morning", minutes: analytics.productivity.morningMinutes, color: "#FBBF24" },
                    { label: "Afternoon", minutes: analytics.productivity.afternoonMinutes, color: "#60A5FA" },
                    { label: "Evening", minutes: analytics.productivity.eveningMinutes, color: "#A78BFA" },
                  ].map((time) => {
                    const percent = analytics.productivity.totalMinutes > 0
                      ? (time.minutes / analytics.productivity.totalMinutes) * 100
                      : 0;

                    return (
                      <View key={time.label}>
                        <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 6 }}>
                          <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary }}>{time.label}</Text>
                          <Text style={{ fontSize: theme.fontSize.sm, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>
                            {Math.round(time.minutes / 60)}h {time.minutes % 60}m
                          </Text>
                        </View>
                        <View style={{ height: 6, backgroundColor: theme.colors.primary, borderRadius: 3, overflow: "hidden" }}>
                          <View
                            style={{
                              height: "100%",
                              width: `${percent}%`,
                              backgroundColor: time.color,
                              borderRadius: 3,
                            }}
                          />
                        </View>
                      </View>
                    );
                  })}
                </View>
              </View>
            </View>
          )}

          {/* Grade Trends by Course */}
          {analytics.courses.length > 0 && (
            <View style={{ marginHorizontal: theme.spacing.xl, marginBottom: theme.spacing.lg }}>
              <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: theme.spacing.md, letterSpacing: theme.letterSpacing.wide }}>
                GRADE TRENDS
              </Text>
              <View style={{ gap: theme.spacing.md }}>
                {analytics.courses.map((course) => (
                  <View
                    key={course.courseId}
                    style={{
                      backgroundColor: theme.colors.secondary,
                      borderRadius: theme.borderRadius.md,
                      padding: theme.spacing.lg,
                      borderWidth: theme.borderWidth,
                      borderColor: theme.colors.border,
                      flexDirection: "row",
                      alignItems: "center",
                      gap: theme.spacing.md,
                    }}
                  >
                    <View
                      style={{
                        width: theme.priorityDotSize,
                        height: theme.priorityDotSize,
                        borderRadius: theme.priorityDotSize / 2,
                        backgroundColor: getTrendColor(course.trend),
                      }}
                    />

                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>
                        {course.courseName}
                      </Text>
                      {course.courseCode && (
                        <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginTop: 2 }}>
                          {course.courseCode}
                        </Text>
                      )}
                    </View>

                    <View style={{ alignItems: "flex-end" }}>
                      <Text style={{ fontSize: theme.fontSize.xl, fontWeight: theme.fontWeight.bold, color: theme.colors.textPrimary }}>
                        {course.currentGrade || "N/A"}
                      </Text>
                      {course.averageGrade && (
                        <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary, marginTop: 2 }}>
                          Avg: {Math.round(course.averageGrade)}%
                        </Text>
                      )}
                    </View>

                    {getTrendIcon(course.trend)}
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Subject Balance */}
          {analytics.subjectBalance.length > 0 && (
            <View style={{ marginHorizontal: theme.spacing.xl, marginBottom: theme.spacing.lg }}>
              <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: theme.spacing.md, letterSpacing: theme.letterSpacing.wide }}>
                SUBJECT BALANCE
              </Text>
              <View
                style={{
                  backgroundColor: theme.colors.secondary,
                  borderRadius: theme.borderRadius.lg,
                  padding: theme.spacing.xl,
                  borderWidth: theme.borderWidth,
                  borderColor: theme.colors.border,
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "center", gap: theme.spacing.md, marginBottom: theme.spacing.lg }}>
                  <Target size={18} color={theme.colors.accent} />
                  <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary }}>
                    Grade weight distribution across courses
                  </Text>
                </View>
                <View style={{ gap: theme.spacing.lg }}>
                  {analytics.subjectBalance.map((subject) => (
                    <View key={`${subject.courseName}-${subject.courseCode}`}>
                      <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: theme.spacing.sm }}>
                        <View style={{ flex: 1 }}>
                          <Text style={{ fontSize: theme.fontSize.base, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>
                            {subject.courseName}
                          </Text>
                          {subject.courseCode && (
                            <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary, marginTop: 2 }}>
                              {subject.courseCode}
                            </Text>
                          )}
                        </View>
                        <View style={{ alignItems: "flex-end" }}>
                          <Text style={{ fontSize: theme.fontSize.lg, fontWeight: theme.fontWeight.bold, color: theme.colors.textPrimary }}>
                            {subject.gradeWeight}%
                          </Text>
                          {subject.currentGrade && (
                            <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary, marginTop: 2 }}>
                              {subject.currentGrade}
                            </Text>
                          )}
                        </View>
                      </View>
                      <View style={{ height: 6, backgroundColor: theme.colors.primary, borderRadius: 3, overflow: "hidden" }}>
                        <View
                          style={{
                            height: "100%",
                            width: `${subject.gradeWeight}%`,
                            backgroundColor: subject.trend === "improving" ? theme.colors.success : subject.trend === "slipping" ? theme.colors.error : theme.colors.accent,
                            borderRadius: 3,
                          }}
                        />
                      </View>
                    </View>
                  ))}
                </View>
              </View>
            </View>
          )}

          {/* Achievement Badges */}
          {analytics.achievements.length > 0 && (
            <View style={{ marginHorizontal: theme.spacing.xl, marginBottom: theme.spacing.lg }}>
              <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: theme.spacing.md, letterSpacing: theme.letterSpacing.wide }}>
                ACHIEVEMENTS
              </Text>
              <View
                style={{
                  backgroundColor: theme.colors.secondary,
                  borderRadius: theme.borderRadius.lg,
                  padding: theme.spacing.xl,
                  borderWidth: theme.borderWidth,
                  borderColor: theme.colors.border,
                }}
              >
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: theme.spacing.md }}>
                  {analytics.achievements.map((achievement, index) => (
                    <View
                      key={index}
                      style={{
                        backgroundColor: theme.colors.primary,
                        borderRadius: theme.borderRadius.md,
                        paddingHorizontal: theme.spacing.lg,
                        paddingVertical: theme.spacing.md,
                        flexDirection: "row",
                        alignItems: "center",
                        gap: theme.spacing.sm,
                        borderWidth: theme.borderWidth,
                        borderColor: theme.colors.border,
                      }}
                    >
                      <Text style={{ fontSize: 18 }}>{achievement.icon}</Text>
                      <Text style={{ fontSize: theme.fontSize.sm, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>
                        {achievement.title}
                      </Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>
          )}

          {/* Total Stats */}
          <View style={{ marginHorizontal: theme.spacing.xl, marginBottom: theme.spacing.xxl }}>
            <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: theme.spacing.md, letterSpacing: theme.letterSpacing.wide }}>
              OVERALL STATS
            </Text>
            <View style={{ flexDirection: "row", gap: theme.spacing.md }}>
              <View
                style={{
                  flex: 1,
                  backgroundColor: theme.colors.secondary,
                  borderRadius: theme.borderRadius.md,
                  padding: theme.spacing.lg,
                  borderWidth: theme.borderWidth,
                  borderColor: theme.colors.border,
                }}
              >
                <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginBottom: 6 }}>
                  Total Hours
                </Text>
                <Text style={{ fontSize: theme.fontSize.xxl, fontWeight: theme.fontWeight.bold, color: theme.colors.textPrimary }}>
                  {analytics.totalStats.totalStudyHours}
                </Text>
              </View>
              <View
                style={{
                  flex: 1,
                  backgroundColor: theme.colors.secondary,
                  borderRadius: theme.borderRadius.md,
                  padding: theme.spacing.lg,
                  borderWidth: theme.borderWidth,
                  borderColor: theme.colors.border,
                }}
              >
                <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginBottom: 6 }}>
                  Sessions
                </Text>
                <Text style={{ fontSize: theme.fontSize.xxl, fontWeight: theme.fontWeight.bold, color: theme.colors.textPrimary }}>
                  {analytics.totalStats.totalSessions}
                </Text>
              </View>
              <View
                style={{
                  flex: 1,
                  backgroundColor: theme.colors.secondary,
                  borderRadius: theme.borderRadius.md,
                  padding: theme.spacing.lg,
                  borderWidth: theme.borderWidth,
                  borderColor: theme.colors.border,
                }}
              >
                <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginBottom: 6 }}>
                  Avg Length
                </Text>
                <Text style={{ fontSize: theme.fontSize.xxl, fontWeight: theme.fontWeight.bold, color: theme.colors.textPrimary }}>
                  {analytics.totalStats.averageSessionLength}m
                </Text>
              </View>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}
