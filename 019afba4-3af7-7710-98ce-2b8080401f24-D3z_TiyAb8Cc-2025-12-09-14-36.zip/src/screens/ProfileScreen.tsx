import React from "react";
import { View, Text, Pressable, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { User as UserIcon, Settings, Sparkles, BookOpen, Award } from "lucide-react-native";
import * as Haptics from "expo-haptics";

import type { BottomTabScreenProps } from "@/navigation/types";
import LoginButton from "@/components/LoginButton";
import { theme } from "@/theme/theme";

type Props = BottomTabScreenProps<"SettingsTab">;

const ProfileScreen = ({ navigation }: Props) => {
  const insets = useSafeAreaInsets();

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.primary }}>
      <View style={{ paddingTop: insets.top, paddingBottom: theme.spacing.lg, paddingHorizontal: theme.spacing.xl }}>
        <Text style={{ fontSize: theme.fontSize.xxxl, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>Profile</Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingHorizontal: theme.spacing.xl, paddingBottom: 100 }}>
        <View
          style={{
            backgroundColor: theme.colors.secondary,
            borderRadius: theme.borderRadius.lg,
            padding: theme.spacing.xl,
            alignItems: "center",
            marginBottom: theme.spacing.lg,
            borderWidth: theme.borderWidth,
            borderColor: theme.colors.border,
          }}
        >
          <View
            style={{
              width: 80,
              height: 80,
              borderRadius: 40,
              backgroundColor: `${theme.colors.accent}30`,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: theme.spacing.lg,
            }}
          >
            <UserIcon size={36} color={theme.colors.accent} />
          </View>
          <Text style={{ fontSize: theme.fontSize.xl, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: 4 }}>
            Welcome to FocusTwin
          </Text>
          <Text style={{ fontSize: theme.fontSize.base, color: theme.colors.textSecondary, textAlign: "center" }}>
            Sign in to sync your data across devices
          </Text>
        </View>

        <LoginButton />

        <View style={{ marginTop: theme.spacing.lg }}>
          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              navigation.navigate("CanvasConnect");
            }}
            style={{
              backgroundColor: theme.colors.secondary,
              borderRadius: theme.borderRadius.md,
              padding: theme.spacing.lg,
              flexDirection: "row",
              alignItems: "center",
              gap: theme.spacing.md,
              marginBottom: theme.spacing.sm,
              borderWidth: theme.borderWidth,
              borderColor: theme.colors.border,
            }}
          >
            <BookOpen size={20} color={theme.colors.accent} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>Canvas Integration</Text>
              <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginTop: 2 }}>Connect your Canvas account</Text>
            </View>
          </Pressable>

          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              navigation.navigate("AIScheduler");
            }}
            style={{
              backgroundColor: theme.colors.secondary,
              borderRadius: theme.borderRadius.md,
              padding: theme.spacing.lg,
              flexDirection: "row",
              alignItems: "center",
              gap: theme.spacing.md,
              marginBottom: theme.spacing.sm,
              borderWidth: theme.borderWidth,
              borderColor: theme.colors.border,
            }}
          >
            <Sparkles size={20} color={theme.colors.accent} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>AI Schedule Generator</Text>
              <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginTop: 2 }}>Describe your week, get a schedule</Text>
            </View>
          </Pressable>

          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              navigation.navigate("AnalyticsTab");
            }}
            style={{
              backgroundColor: theme.colors.secondary,
              borderRadius: theme.borderRadius.md,
              padding: theme.spacing.lg,
              flexDirection: "row",
              alignItems: "center",
              gap: theme.spacing.md,
              marginBottom: theme.spacing.sm,
              borderWidth: theme.borderWidth,
              borderColor: theme.colors.border,
            }}
          >
            <Award size={20} color={theme.colors.accent} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>View Analytics</Text>
              <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginTop: 2 }}>Track your study patterns and grades</Text>
            </View>
          </Pressable>

          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }}
            style={{
              backgroundColor: theme.colors.secondary,
              borderRadius: theme.borderRadius.md,
              padding: theme.spacing.lg,
              flexDirection: "row",
              alignItems: "center",
              gap: theme.spacing.md,
              marginBottom: theme.spacing.sm,
              borderWidth: theme.borderWidth,
              borderColor: theme.colors.border,
            }}
          >
            <Settings size={20} color={theme.colors.textSecondary} />
            <Text style={{ fontSize: theme.fontSize.md, color: theme.colors.textPrimary, flex: 1 }}>Settings</Text>
          </Pressable>
        </View>

        <View style={{ marginTop: 40, alignItems: "center" }}>
          <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary, marginBottom: 4 }}>FocusTwin AI</Text>
          <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary }}>Version 1.0.0</Text>
        </View>
      </ScrollView>
    </View>
  );
};

export default ProfileScreen;
