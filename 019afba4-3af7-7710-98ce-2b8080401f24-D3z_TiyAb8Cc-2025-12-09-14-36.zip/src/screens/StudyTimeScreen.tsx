import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  Alert,
  Platform,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import {
  Clock,
  Shield,
  Coffee,
  Play,
  Settings,
  ChevronRight,
  Info,
} from "lucide-react-native";
import { useNavigation } from "@react-navigation/native";
import type { NativeStackNavigationProp } from "@react-navigation/native-stack";
import type { RootStackParamList } from "@/navigation/types";
import ScreenTimeBlocker from "../../modules/screen-time-blocker";

type NavigationProp = NativeStackNavigationProp<RootStackParamList, "StudyTime">;

/**
 * StudyTimeScreen
 * Setup screen for starting a focused study session with app blocking
 */
export default function StudyTimeScreen() {
  const navigation = useNavigation<NavigationProp>();
  const [duration, setDuration] = useState(60); // Default 60 minutes
  const [hasPermission, setHasPermission] = useState(false);
  const [checkingPermission, setCheckingPermission] = useState(true);
  const [selectedApps, setSelectedApps] = useState<any>(null);

  // Check if we have Screen Time permission
  useEffect(() => {
    checkPermission();
  }, []);

  const checkPermission = async () => {
    try {
      if (Platform.OS !== "ios") {
        setCheckingPermission(false);
        return;
      }

      // Check if Screen Time API is available before trying to use it
      if (!ScreenTimeBlocker.isAvailable()) {
        console.log("[StudyTime] Screen Time API not available on this device");
        setCheckingPermission(false);
        return;
      }

      const authorized = await ScreenTimeBlocker.checkAuthorization();
      setHasPermission(authorized);
    } catch (error) {
      console.log("[StudyTime] Permission check error:", error);
    } finally {
      setCheckingPermission(false);
    }
  };

  const requestPermission = async () => {
    try {
      if (!ScreenTimeBlocker.isAvailable()) {
        Alert.alert(
          "Not Available",
          "Screen Time blocking is only available on physical iOS devices running iOS 16 or later. It won't work in the simulator.",
          [{ text: "OK" }]
        );
        return;
      }

      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

      const result = await ScreenTimeBlocker.requestAuthorization();

      if (result.granted) {
        setHasPermission(true);
        Alert.alert(
          "Permission Granted! 🎉",
          "You can now block apps during study sessions. Next, select which apps to block.",
          [{ text: "Got it" }]
        );
      } else {
        Alert.alert(
          "Permission Required",
          "To use Study Time, you need to:\n\n1. Open Settings app\n2. Go to Screen Time\n3. Enable Screen Time\n4. Return to this app and try again",
          [{ text: "OK" }]
        );
      }
    } catch (error: any) {
      console.log("[StudyTime] Permission request error:", error);
      Alert.alert("Error", error.message || "Failed to request permission");
    }
  };

  const selectApps = async () => {
    try {
      if (!ScreenTimeBlocker.isAvailable()) {
        Alert.alert(
          "Not Available",
          "Screen Time blocking is only available on physical iOS devices running iOS 16 or later.",
          [{ text: "OK" }]
        );
        return;
      }

      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

      const selection = await ScreenTimeBlocker.presentAppPicker();

      if (selection) {
        setSelectedApps(selection);
        const appCount = (selection.applicationTokens?.length || 0) + (selection.categoryTokens?.length || 0);
        Alert.alert(
          "Apps Selected! ✓",
          `You've selected ${appCount} app${appCount !== 1 ? "s" : ""} to block during study sessions.`,
          [{ text: "Great!" }]
        );
      }
    } catch (error: any) {
      console.log("[StudyTime] App picker error:", error);
      Alert.alert("Error", error.message || "Failed to open app picker");
    }
  };

  const startStudySession = () => {
    if (!selectedApps) {
      Alert.alert(
        "Select Apps First",
        "Please select which apps you want to block during your study session.",
        [{ text: "OK" }]
      );
      return;
    }

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    navigation.navigate("ActiveStudySession", {
      duration,
      blockedApps: selectedApps,
    });
  };

  // Duration options: 15, 30, 45, 60, 90, 120 minutes
  const durationOptions = [15, 30, 45, 60, 90, 120, 180, 240];

  if (checkingPermission) {
    return (
      <View style={{ flex: 1, backgroundColor: "#F9FAFB", alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator size="large" color="#3A7BFF" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <SafeAreaView edges={["top"]} style={{ flex: 1 }}>
        <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
          {/* Header */}
          <View style={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 12 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 8 }}>
              <View
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 12,
                  backgroundColor: "#3A7BFF",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Shield size={24} color="white" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 28, fontWeight: "700", color: "#0B0D12" }}>
                  Study Time
                </Text>
                <Text style={{ fontSize: 14, color: "#6B7280", marginTop: 2 }}>
                  Block distractions, stay focused
                </Text>
              </View>
            </View>
          </View>

          {/* iOS Only Notice */}
          {Platform.OS !== "ios" && (
            <View style={{ marginHorizontal: 20, marginBottom: 16 }}>
              <View
                style={{
                  backgroundColor: "#FEF3C7",
                  borderRadius: 12,
                  padding: 16,
                  flexDirection: "row",
                  gap: 12,
                }}
              >
                <Info size={20} color="#F59E0B" />
                <Text style={{ flex: 1, fontSize: 14, color: "#92400E" }}>
                  App blocking is only available on iOS 16+. On other platforms, Study Time works as a focus timer.
                </Text>
              </View>
            </View>
          )}

          {/* Permission Card */}
          {Platform.OS === "ios" && !hasPermission && (
            <View style={{ marginHorizontal: 20, marginBottom: 16 }}>
              <LinearGradient
                colors={["#EF4444", "#DC2626"]}
                style={{ borderRadius: 16, padding: 20 }}
              >
                <View style={{ flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 12 }}>
                  <Shield size={24} color="white" />
                  <Text style={{ fontSize: 18, fontWeight: "700", color: "white", flex: 1 }}>
                    Permission Required
                  </Text>
                </View>
                <Text style={{ fontSize: 14, color: "rgba(255,255,255,0.9)", marginBottom: 16, lineHeight: 20 }}>
                  To block apps, you need to grant Family Controls permission. This allows the app to temporarily restrict access to selected apps during study sessions.
                </Text>
                <Pressable
                  onPress={requestPermission}
                  style={{ backgroundColor: "white", borderRadius: 12, paddingVertical: 14, alignItems: "center" }}
                >
                  <Text style={{ fontSize: 16, fontWeight: "600", color: "#EF4444" }}>
                    Grant Permission
                  </Text>
                </Pressable>
              </LinearGradient>
            </View>
          )}

          {/* Select Apps Card */}
          {Platform.OS === "ios" && hasPermission && (
            <View style={{ marginHorizontal: 20, marginBottom: 16 }}>
              <Pressable
                onPress={selectApps}
                style={{
                  backgroundColor: "white",
                  borderRadius: 16,
                  padding: 20,
                  shadowColor: "#000",
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.05,
                  shadowRadius: 8,
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 8 }}>
                  <View
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 10,
                      backgroundColor: "#F3F4F6",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Settings size={20} color="#3A7BFF" />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 16, fontWeight: "600", color: "#0B0D12" }}>
                      {selectedApps ? "Apps Selected" : "Select Apps to Block"}
                    </Text>
                    <Text style={{ fontSize: 13, color: "#6B7280", marginTop: 2 }}>
                      {selectedApps
                        ? `${(selectedApps.applicationTokens?.length || 0) + (selectedApps.categoryTokens?.length || 0)} apps will be blocked`
                        : "Choose which apps to block"}
                    </Text>
                  </View>
                  <ChevronRight size={20} color="#9CA3AF" />
                </View>
              </Pressable>
            </View>
          )}

          {/* Duration Selection */}
          <View style={{ marginHorizontal: 20, marginBottom: 16 }}>
            <Text style={{ fontSize: 16, fontWeight: "600", color: "#0B0D12", marginBottom: 12 }}>
              Study Duration
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
              {durationOptions.map((option) => (
                <Pressable
                  key={option}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    setDuration(option);
                  }}
                  style={{
                    paddingHorizontal: 20,
                    paddingVertical: 12,
                    borderRadius: 12,
                    backgroundColor: duration === option ? "#3A7BFF" : "white",
                    borderWidth: 1,
                    borderColor: duration === option ? "#3A7BFF" : "#E5E7EB",
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: "600",
                      color: duration === option ? "white" : "#6B7280",
                    }}
                  >
                    {option < 60 ? `${option}m` : `${option / 60}h`}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Break Info */}
          <View style={{ marginHorizontal: 20, marginBottom: 16 }}>
            <View
              style={{
                backgroundColor: "white",
                borderRadius: 16,
                padding: 20,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.05,
                shadowRadius: 8,
              }}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 8 }}>
                <Coffee size={20} color="#F59E0B" />
                <Text style={{ fontSize: 16, fontWeight: "600", color: "#0B0D12" }}>
                  Break Policy
                </Text>
              </View>
              <Text style={{ fontSize: 14, color: "#6B7280", lineHeight: 20 }}>
                You can take up to 3 breaks during your session, each lasting 5 minutes. Use them wisely!
              </Text>
            </View>
          </View>

          {/* How It Works */}
          <View style={{ marginHorizontal: 20, marginBottom: 24 }}>
            <Text style={{ fontSize: 16, fontWeight: "600", color: "#0B0D12", marginBottom: 12 }}>
              How It Works
            </Text>
            <View style={{ gap: 12 }}>
              <View style={{ flexDirection: "row", gap: 12 }}>
                <View
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 16,
                    backgroundColor: "#DBEAFE",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Text style={{ fontSize: 14, fontWeight: "700", color: "#3A7BFF" }}>1</Text>
                </View>
                <Text style={{ flex: 1, fontSize: 14, color: "#6B7280", marginTop: 6 }}>
                  Select apps you want to block during study time
                </Text>
              </View>
              <View style={{ flexDirection: "row", gap: 12 }}>
                <View
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 16,
                    backgroundColor: "#DBEAFE",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Text style={{ fontSize: 14, fontWeight: "700", color: "#3A7BFF" }}>2</Text>
                </View>
                <Text style={{ flex: 1, fontSize: 14, color: "#6B7280", marginTop: 6 }}>
                  Choose your study duration (15 min to 4 hours)
                </Text>
              </View>
              <View style={{ flexDirection: "row", gap: 12 }}>
                <View
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 16,
                    backgroundColor: "#DBEAFE",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Text style={{ fontSize: 14, fontWeight: "700", color: "#3A7BFF" }}>3</Text>
                </View>
                <Text style={{ flex: 1, fontSize: 14, color: "#6B7280", marginTop: 6 }}>
                  Start session - selected apps will be blocked immediately
                </Text>
              </View>
              <View style={{ flexDirection: "row", gap: 12 }}>
                <View
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 16,
                    backgroundColor: "#DBEAFE",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Text style={{ fontSize: 14, fontWeight: "700", color: "#3A7BFF" }}>4</Text>
                </View>
                <Text style={{ flex: 1, fontSize: 14, color: "#6B7280", marginTop: 6 }}>
                  Take up to 3 breaks (5 minutes each) if needed
                </Text>
              </View>
            </View>
          </View>
        </ScrollView>

        {/* Start Button */}
        <View
          style={{
            padding: 20,
            paddingBottom: 32,
            backgroundColor: "white",
            borderTopWidth: 1,
            borderTopColor: "#E5E7EB",
          }}
        >
          <Pressable
            onPress={startStudySession}
            disabled={Platform.OS === "ios" && (!hasPermission || !selectedApps)}
            style={{
              backgroundColor: Platform.OS === "ios" && (!hasPermission || !selectedApps) ? "#D1D5DB" : "#3A7BFF",
              borderRadius: 16,
              paddingVertical: 18,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: 10,
            }}
          >
            <Play size={20} color="white" fill="white" />
            <Text style={{ fontSize: 17, fontWeight: "600", color: "white" }}>
              Start Study Session ({duration < 60 ? `${duration}m` : `${duration / 60}h`})
            </Text>
          </Pressable>
        </View>
      </SafeAreaView>
    </View>
  );
}
