import React, { useState } from "react";
import { Alert, Pressable, Text, TextInput, View, ActivityIndicator, Image } from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { SafeAreaView } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import { Sparkles } from "lucide-react-native";

import { authClient } from "@/lib/authClient";

export default function AuthScreen() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSignIn = async () => {
    if (!email || !password) {
      Alert.alert("Error", "Please enter email and password");
      return;
    }

    setIsLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      console.log("[Auth] Signing in...");
      const result = await authClient.signIn.email({
        email,
        password,
      });

      if (result.error) {
        console.log("[Auth] Sign in error:", result.error);
        Alert.alert("Sign In Failed", result.error.message || "Please check your credentials");
      } else {
        console.log("[Auth] Sign in successful");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        // Navigation will happen automatically when session is detected
      }
    } catch (error) {
      console.log("[Auth] Sign in exception:", error);
      Alert.alert("Error", "An unexpected error occurred");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignUp = async () => {
    if (!email || !password || !name) {
      Alert.alert("Error", "Please fill in all fields");
      return;
    }

    if (password.length < 6) {
      Alert.alert("Error", "Password must be at least 6 characters");
      return;
    }

    setIsLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      console.log("[Auth] Signing up...");
      const result = await authClient.signUp.email({
        email,
        password,
        name,
      });

      if (result.error) {
        console.log("[Auth] Sign up error:", result.error);
        Alert.alert("Sign Up Failed", result.error.message || "Please try again");
      } else {
        console.log("[Auth] Sign up successful");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        // Navigation will happen automatically when session is detected
      }
    } catch (error) {
      console.log("[Auth] Sign up exception:", error);
      Alert.alert("Error", "An unexpected error occurred");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <KeyboardAwareScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View style={{ flex: 1, padding: 24, justifyContent: "center" }}>
          {/* App Logo/Header */}
          <View style={{ alignItems: "center", marginBottom: 48 }}>
            <View
              style={{
                width: 80,
                height: 80,
                borderRadius: 20,
                backgroundColor: "#3A7BFF",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 16,
              }}
            >
              <Sparkles size={40} color="white" />
            </View>
            <Text style={{ fontSize: 32, fontWeight: "700", color: "#111827", marginBottom: 8 }}>
              FocusTwin AI
            </Text>
            <Text style={{ fontSize: 16, color: "#6B7280", textAlign: "center" }}>
              Your AI-powered student productivity assistant
            </Text>
          </View>

          {/* Auth Form */}
          <View style={{ backgroundColor: "white", borderRadius: 16, padding: 24, gap: 16 }}>
            <Text style={{ fontSize: 24, fontWeight: "700", color: "#111827", textAlign: "center", marginBottom: 8 }}>
              {isSignUp ? "Create Account" : "Welcome Back"}
            </Text>

            {isSignUp && (
              <View>
                <Text style={{ fontSize: 14, fontWeight: "600", color: "#6B7280", marginBottom: 8 }}>Name</Text>
                <TextInput
                  value={name}
                  onChangeText={setName}
                  placeholder="Enter your name"
                  placeholderTextColor="#9CA3AF"
                  autoCapitalize="words"
                  editable={!isLoading}
                  style={{
                    borderWidth: 1,
                    borderColor: "#E5E7EB",
                    borderRadius: 12,
                    padding: 16,
                    fontSize: 16,
                    backgroundColor: "#F9FAFB",
                  }}
                />
              </View>
            )}

            <View>
              <Text style={{ fontSize: 14, fontWeight: "600", color: "#6B7280", marginBottom: 8 }}>Email</Text>
              <TextInput
                value={email}
                onChangeText={setEmail}
                placeholder="Enter your email"
                placeholderTextColor="#9CA3AF"
                keyboardType="email-address"
                autoCapitalize="none"
                editable={!isLoading}
                style={{
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  borderRadius: 12,
                  padding: 16,
                  fontSize: 16,
                  backgroundColor: "#F9FAFB",
                }}
              />
            </View>

            <View>
              <Text style={{ fontSize: 14, fontWeight: "600", color: "#6B7280", marginBottom: 8 }}>Password</Text>
              <TextInput
                value={password}
                onChangeText={setPassword}
                placeholder="Enter your password"
                placeholderTextColor="#9CA3AF"
                secureTextEntry
                editable={!isLoading}
                style={{
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  borderRadius: 12,
                  padding: 16,
                  fontSize: 16,
                  backgroundColor: "#F9FAFB",
                }}
              />
            </View>

            <Pressable
              onPress={isSignUp ? handleSignUp : handleSignIn}
              disabled={isLoading}
              style={{
                backgroundColor: isLoading ? "#93C5FD" : "#3A7BFF",
                borderRadius: 12,
                padding: 16,
                alignItems: "center",
                marginTop: 8,
              }}
            >
              {isLoading ? (
                <ActivityIndicator color="white" />
              ) : (
                <Text style={{ color: "white", fontWeight: "600", fontSize: 16 }}>
                  {isSignUp ? "Sign Up" : "Sign In"}
                </Text>
              )}
            </Pressable>

            <Pressable
              onPress={() => {
                setIsSignUp(!isSignUp);
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              }}
              disabled={isLoading}
              style={{ alignItems: "center", paddingVertical: 8 }}
            >
              <Text style={{ color: "#3A7BFF", fontSize: 14, fontWeight: "500" }}>
                {isSignUp ? "Already have an account? Sign In" : "Don't have an account? Sign Up"}
              </Text>
            </Pressable>
          </View>

          {/* Footer */}
          <Text style={{ textAlign: "center", color: "#9CA3AF", fontSize: 12, marginTop: 32 }}>
            By continuing, you agree to our Terms of Service and Privacy Policy
          </Text>
        </View>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
}
