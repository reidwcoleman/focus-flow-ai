import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, Pressable, RefreshControl } from "react-native";
import { Calendar, Clock, BookOpen, Coffee, GraduationCap } from "lucide-react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import type { BottomTabScreenProps } from "@/navigation/types";
import { api } from "@/lib/api";
import type { GetCurrentScheduleResponse } from "@/shared/contracts";
import { theme } from "@/theme/theme";

type Props = BottomTabScreenProps<"ScheduleTab">;

const WeeklyScheduleScreen = ({ navigation }: Props) => {
  const insets = useSafeAreaInsets();
  const [schedule, setSchedule] = useState<GetCurrentScheduleResponse["schedule"]>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchSchedule = async () => {
    try {
      const response = await api.get<GetCurrentScheduleResponse>("/schedule/current");
      setSchedule(response.schedule);
    } catch (error: any) {
      if (error?.status !== 401) {
        console.log("Error fetching schedule:", error);
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchSchedule();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    fetchSchedule();
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  };

  const formatDay = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const isToday = date.toDateString() === today.toDateString();
    const isTomorrow = date.toDateString() === new Date(today.getTime() + 86400000).toDateString();

    if (isToday) return "Today";
    if (isTomorrow) return "Tomorrow";
    return date.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" });
  };

  const groupByDay = (blocks: any[]) => {
    const grouped: Record<string, any[]> = {};
    blocks.forEach((block) => {
      const day = new Date(block.startTime).toDateString();
      if (!grouped[day]) grouped[day] = [];
      grouped[day].push(block);
    });

    // Sort blocks within each day by start time
    Object.keys(grouped).forEach((day) => {
      grouped[day].sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
    });

    return grouped;
  };

  const getBlockIcon = (type: string) => {
    switch (type) {
      case "class":
        return <GraduationCap size={16} color={theme.colors.success} />;
      case "break":
        return <Coffee size={16} color={theme.colors.warning} />;
      case "study":
        return <BookOpen size={16} color={theme.colors.accent} />;
      default:
        return <Clock size={16} color={theme.colors.textSecondary} />;
    }
  };

  const getBlockColor = (type: string) => {
    switch (type) {
      case "class":
        return theme.colors.success;
      case "break":
        return theme.colors.warning;
      case "study":
        return theme.colors.accent;
      case "personal":
        return "#8B5CF6";
      default:
        return theme.colors.textSecondary;
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: theme.colors.primary }}>
        <Text style={{ color: theme.colors.textSecondary }}>Loading...</Text>
      </View>
    );
  }

  if (!schedule) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.primary }}>
        <View style={{ paddingTop: insets.top, paddingBottom: theme.spacing.lg, paddingHorizontal: theme.spacing.xl }}>
          <Text style={{ fontSize: theme.fontSize.xxxl, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>Schedule</Text>
        </View>
        <ScrollView contentContainerStyle={{ paddingHorizontal: theme.spacing.xl, paddingTop: 40 }}>
          <View style={{ backgroundColor: theme.colors.secondary, borderRadius: theme.borderRadius.lg, padding: 40, alignItems: "center", borderWidth: theme.borderWidth, borderColor: theme.colors.border }}>
            <Calendar size={48} color={theme.colors.textSecondary} />
            <Text style={{ fontSize: theme.fontSize.lg, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginTop: 16, marginBottom: 8 }}>
              No Schedule Yet
            </Text>
            <Text style={{ fontSize: theme.fontSize.base, color: theme.colors.textSecondary, textAlign: "center", marginBottom: 20 }}>
              Generate your first AI schedule or connect Canvas to import your class schedule
            </Text>
            <Pressable
              onPress={() => navigation.navigate("AISchedulerTab")}
              style={{
                backgroundColor: theme.colors.accent,
                borderRadius: theme.borderRadius.md,
                paddingHorizontal: 24,
                paddingVertical: 12,
              }}
            >
              <Text style={{ color: theme.colors.textPrimary, fontWeight: theme.fontWeight.semibold, fontSize: theme.fontSize.md }}>Generate Schedule</Text>
            </Pressable>
          </View>
        </ScrollView>
      </View>
    );
  }

  const groupedBlocks = groupByDay(schedule.studyBlocks);
  const sortedDays = Object.keys(groupedBlocks).sort((a, b) => new Date(a).getTime() - new Date(b).getTime());

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.primary }}>
      <View style={{ paddingTop: insets.top, paddingBottom: theme.spacing.lg, paddingHorizontal: theme.spacing.xl }}>
        <Text style={{ fontSize: theme.fontSize.xxxl, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: 4 }}>
          Schedule
        </Text>
        <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary }}>
          {new Date(schedule.weekStartDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })} - {new Date(schedule.weekEndDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingHorizontal: theme.spacing.xl, paddingBottom: 100 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.accent} />
        }
      >
        {schedule.aiGenerated && (
          <View style={{ backgroundColor: `${theme.colors.accent}20`, borderRadius: theme.borderRadius.md, padding: theme.spacing.md, marginBottom: theme.spacing.lg, borderWidth: theme.borderWidth, borderColor: theme.colors.accent }}>
            <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.accent, fontWeight: theme.fontWeight.semibold }}>AI Generated Schedule</Text>
          </View>
        )}

        {sortedDays.map((day, dayIndex) => (
          <View key={day} style={{ marginBottom: theme.spacing.xxl }}>
            <View style={{ flexDirection: "row", alignItems: "center", marginBottom: theme.spacing.md }}>
              <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, letterSpacing: theme.letterSpacing.wide }}>
                {formatDay(groupedBlocks[day][0].startTime).toUpperCase()}
              </Text>
              <View
                style={{
                  backgroundColor: theme.colors.border,
                  paddingHorizontal: 8,
                  paddingVertical: 2,
                  borderRadius: theme.borderRadius.sm,
                  marginLeft: theme.spacing.sm,
                }}
              >
                <Text style={{ fontSize: theme.fontSize.xs, fontWeight: theme.fontWeight.semibold, color: theme.colors.textSecondary }}>
                  {groupedBlocks[day].length}
                </Text>
              </View>
            </View>

            {groupedBlocks[day].map((block, blockIndex) => (
              <View
                key={block.id}
                style={{
                  backgroundColor: theme.colors.secondary,
                  borderRadius: theme.borderRadius.md,
                  padding: theme.spacing.lg,
                  marginBottom: theme.spacing.sm,
                  borderWidth: theme.borderWidth,
                  borderColor: theme.colors.border,
                  flexDirection: "row",
                  alignItems: "center",
                  gap: theme.spacing.md,
                }}
              >
                <View
                  style={{
                    width: theme.priorityDotSize,
                    height: theme.priorityDotSize,
                    borderRadius: theme.priorityDotSize / 2,
                    backgroundColor: getBlockColor(block.type),
                  }}
                />

                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: 6 }}>
                    {block.title || block.assignment?.title || "Study Block"}
                  </Text>
                  <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 4 }}>
                    <Clock size={12} color={theme.colors.textSecondary} style={{ marginRight: 6 }} />
                    <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary }}>
                      {formatTime(block.startTime)} - {formatTime(block.endTime)}
                    </Text>
                    <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginLeft: 8 }}>
                      ({block.duration} min)
                    </Text>
                  </View>
                  {block.description && (
                    <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginTop: 4 }} numberOfLines={2}>
                      {block.description}
                    </Text>
                  )}
                </View>

                {getBlockIcon(block.type)}
              </View>
            ))}
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

export default WeeklyScheduleScreen;
