import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, Pressable, RefreshControl } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Plus, Clock, ChevronRight, Flame, Trophy, Star } from "lucide-react-native";
import * as Haptics from "expo-haptics";

import type { BottomTabScreenProps } from "@/navigation/types";
import { api } from "@/lib/api";
import type { GetAssignmentsResponse, GetStreakResponse } from "@/shared/contracts";
import { useCanvasAutoSync } from "@/hooks/useCanvasAutoSync";
import { useStreakCheck } from "@/hooks/useStreakCheck";
import { theme } from "@/theme/theme";

type Props = BottomTabScreenProps<"HomeTab">;

const HomeScreen = ({ navigation }: Props) => {
  const insets = useSafeAreaInsets();
  const [assignments, setAssignments] = useState<GetAssignmentsResponse["assignments"]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [streak, setStreak] = useState<GetStreakResponse["streak"] | null>(null);

  useCanvasAutoSync();
  useStreakCheck();

  const fetchStreak = async () => {
    try {
      const response = await api.get<GetStreakResponse>("/streak");
      setStreak(response?.streak || null);
    } catch (error: any) {
      console.log("[Home] Error fetching streak:", error?.message || error);
    }
  };

  const fetchAssignments = async () => {
    try {
      const response = await api.get<GetAssignmentsResponse>("/assignments");
      setAssignments(response?.assignments || []);
      setIsAuthenticated(true);
    } catch (error: any) {
      if (error?.status === 401) {
        setIsAuthenticated(false);
        setAssignments([]);
      } else {
        console.log("Error fetching assignments:", error);
        setAssignments([]);
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchAssignments();
    fetchStreak();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    fetchAssignments();
    fetchStreak();
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
        return theme.colors.priorityUrgent;
      case "high":
        return theme.colors.priorityHigh;
      case "medium":
        return theme.colors.priorityMedium;
      case "low":
        return theme.colors.priorityLow;
      default:
        return theme.colors.textSecondary;
    }
  };

  const getDaysUntilDue = (dueDate: string) => {
    const due = new Date(dueDate);
    const now = new Date();
    const diff = due.getTime() - now.getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));

    if (days < 0) return `${Math.abs(days)}d overdue`;
    if (days === 0) return "Due today";
    if (days === 1) return "Due tomorrow";
    return `${days} days`;
  };

  const getStreakBadge = (currentStreak: number): string => {
    if (currentStreak >= 365) return "🎊";
    if (currentStreak >= 200) return "🦸";
    if (currentStreak >= 150) return "🎯";
    if (currentStreak >= 100) return "👑";
    if (currentStreak >= 75) return "💎";
    if (currentStreak >= 50) return "🚀";
    if (currentStreak >= 30) return "🌟";
    if (currentStreak >= 21) return "🏆";
    if (currentStreak >= 14) return "💪";
    if (currentStreak >= 7) return "⭐";
    if (currentStreak >= 3) return "🔥";
    return "🎯";
  };

  const getStreakTitle = (currentStreak: number): string => {
    if (currentStreak >= 365) return "Yearly Champion";
    if (currentStreak >= 200) return "Superhuman";
    if (currentStreak >= 150) return "Super Centurion";
    if (currentStreak >= 100) return "Centurion";
    if (currentStreak >= 75) return "Diamond Achiever";
    if (currentStreak >= 50) return "Superstar";
    if (currentStreak >= 30) return "Monthly Legend";
    if (currentStreak >= 21) return "3 Week Master";
    if (currentStreak >= 14) return "2 Week Champion";
    if (currentStreak >= 7) return "Week Warrior";
    if (currentStreak >= 3) return "On Fire";
    return "Getting Started";
  };

  const incompleteTasks = assignments?.filter((a) => a.status !== "completed") || [];
  const completedToday = assignments?.filter((a) => {
    if (!a.completedAt) return false;
    const completedDate = new Date(a.completedAt);
    const today = new Date();
    return (
      completedDate.getDate() === today.getDate() &&
      completedDate.getMonth() === today.getMonth() &&
      completedDate.getFullYear() === today.getFullYear()
    );
  }) || [];

  const currentDate = new Date();
  const timeOfDay = currentDate.getHours() < 12 ? "morning" : currentDate.getHours() < 17 ? "afternoon" : "evening";
  const userName = "Student";

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.primary }}>
      <View style={{ flex: 1, paddingTop: insets.top }}>
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.accent} />
          }
        >
          {/* Header */}
          <View style={{ paddingHorizontal: theme.spacing.xl, paddingTop: theme.spacing.xl, paddingBottom: theme.spacing.md }}>
            <Text style={{
              fontSize: theme.fontSize.sm,
              color: theme.colors.textSecondary,
              letterSpacing: theme.letterSpacing.wide,
              marginBottom: theme.spacing.xs,
            }}>
              Good {timeOfDay}
            </Text>
            <Text style={{
              fontSize: theme.fontSize.xxxl,
              fontWeight: theme.fontWeight.semibold,
              color: theme.colors.textPrimary,
              letterSpacing: theme.letterSpacing.tight,
            }}>
              {userName}
            </Text>
          </View>

          {/* Streak Card */}
          {streak && (
            <View style={{ marginHorizontal: theme.spacing.xl, marginBottom: theme.spacing.lg }}>
              <View style={{
                backgroundColor: theme.colors.secondary,
                borderRadius: theme.borderRadius.lg,
                padding: theme.spacing.lg,
                borderWidth: theme.borderWidth,
                borderColor: theme.colors.border,
              }}>
                <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: theme.spacing.md }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{
                      fontSize: theme.fontSize.lg,
                      fontWeight: theme.fontWeight.semibold,
                      color: theme.colors.textPrimary,
                      marginBottom: theme.spacing.xs,
                    }}>
                      {getStreakTitle(streak.currentStreak)}
                    </Text>
                    <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary }}>
                      Achievement Unlocked
                    </Text>
                  </View>
                  <View style={{
                    width: 56,
                    height: 56,
                    borderRadius: 28,
                    backgroundColor: `${theme.colors.accent}20`,
                    alignItems: "center",
                    justifyContent: "center",
                    borderWidth: 2,
                    borderColor: theme.colors.accent,
                  }}>
                    <Text style={{ fontSize: 28 }}>{getStreakBadge(streak.currentStreak)}</Text>
                  </View>
                </View>

                <View style={{ flexDirection: "row", alignItems: "center", gap: theme.spacing.sm, marginBottom: theme.spacing.md }}>
                  <Flame size={20} color={theme.colors.accent} />
                  <Text style={{
                    fontSize: theme.fontSize.xxl,
                    fontWeight: theme.fontWeight.bold,
                    color: theme.colors.textPrimary,
                  }}>
                    {streak.currentStreak} Days
                  </Text>
                </View>

                <View style={{ flexDirection: "row", gap: theme.spacing.lg }}>
                  <View>
                    <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary, marginBottom: 2 }}>
                      LONGEST
                    </Text>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
                      <Trophy size={14} color={theme.colors.textSecondary} />
                      <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>
                        {streak.longestStreak}
                      </Text>
                    </View>
                  </View>
                  <View>
                    <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary, marginBottom: 2 }}>
                      TOTAL
                    </Text>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
                      <Star size={14} color={theme.colors.textSecondary} />
                      <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>
                        {streak.totalDays}
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </View>
          )}

          {/* Stats */}
          <View style={{
            flexDirection: "row",
            gap: theme.spacing.md,
            paddingHorizontal: theme.spacing.xl,
            marginBottom: theme.spacing.xl,
          }}>
            <View style={{
              flex: 1,
              backgroundColor: theme.colors.secondary,
              borderRadius: theme.borderRadius.md,
              padding: theme.spacing.lg,
              borderWidth: theme.borderWidth,
              borderColor: theme.colors.border,
            }}>
              <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary, marginBottom: theme.spacing.xs }}>
                TO DO
              </Text>
              <Text style={{ fontSize: theme.fontSize.xxl, fontWeight: theme.fontWeight.bold, color: theme.colors.textPrimary }}>
                {incompleteTasks.length}
              </Text>
            </View>
            <View style={{
              flex: 1,
              backgroundColor: theme.colors.secondary,
              borderRadius: theme.borderRadius.md,
              padding: theme.spacing.lg,
              borderWidth: theme.borderWidth,
              borderColor: theme.colors.border,
            }}>
              <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary, marginBottom: theme.spacing.xs }}>
                COMPLETED TODAY
              </Text>
              <Text style={{ fontSize: theme.fontSize.xxl, fontWeight: theme.fontWeight.bold, color: theme.colors.textPrimary }}>
                {completedToday.length}
              </Text>
            </View>
          </View>

          {/* Section Header */}
          <View style={{
            paddingHorizontal: theme.spacing.xl,
            marginBottom: theme.spacing.md,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}>
            <Text style={{
              fontSize: theme.fontSize.md,
              fontWeight: theme.fontWeight.semibold,
              color: theme.colors.textPrimary,
              letterSpacing: theme.letterSpacing.wide,
            }}>
              UPCOMING ASSIGNMENTS
            </Text>
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                navigation.navigate("AddAssignment", {});
              }}
              style={{
                width: 32,
                height: 32,
                borderRadius: theme.borderRadius.sm,
                backgroundColor: theme.colors.accent,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Plus size={18} color="#ffffff" />
            </Pressable>
          </View>

          {/* Assignments List */}
          <View style={{ paddingHorizontal: theme.spacing.xl, gap: theme.spacing.sm }}>
            {incompleteTasks.slice(0, 10).map((assignment) => (
              <Pressable
                key={assignment.id}
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  navigation.navigate("AssignmentDetail", { assignmentId: assignment.id });
                }}
                style={{
                  backgroundColor: theme.colors.secondary,
                  borderRadius: theme.borderRadius.md,
                  padding: theme.spacing.lg,
                  borderWidth: theme.borderWidth,
                  borderColor: theme.colors.border,
                  flexDirection: "row",
                  alignItems: "center",
                  gap: theme.spacing.md,
                }}
              >
                {/* Priority Dot */}
                <View
                  style={{
                    width: theme.priorityDotSize,
                    height: theme.priorityDotSize,
                    borderRadius: theme.priorityDotSize / 2,
                    backgroundColor: getPriorityColor(assignment.priority),
                  }}
                />

                <View style={{ flex: 1 }}>
                  <Text style={{
                    fontSize: theme.fontSize.md,
                    fontWeight: theme.fontWeight.semibold,
                    color: theme.colors.textPrimary,
                    marginBottom: 2,
                  }}>
                    {assignment.title}
                  </Text>
                  {assignment.subject && (
                    <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginBottom: 4 }}>
                      {assignment.subject.name}
                    </Text>
                  )}
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                    <Clock size={12} color={theme.colors.textSecondary} />
                    <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary }}>
                      {getDaysUntilDue(assignment.dueDate)}
                    </Text>
                  </View>
                </View>

                <ChevronRight size={16} color={theme.colors.textSecondary} />
              </Pressable>
            ))}

            {incompleteTasks.length === 0 && (
              <View style={{
                alignItems: "center",
                paddingVertical: theme.spacing.xxl * 2,
              }}>
                <Text style={{ fontSize: theme.fontSize.md, color: theme.colors.textSecondary }}>
                  No assignments yet
                </Text>
              </View>
            )}
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

export default HomeScreen;
