import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { BottomTabScreenProps } from "@/navigation/types";
import { api } from "../lib/api";
import { type GetGradesResponse } from "@/shared/contracts";
import { Award, BookOpen, Calendar } from "lucide-react-native";
import * as Haptics from "expo-haptics";
import { theme } from "@/theme/theme";

type Props = BottomTabScreenProps<"GradesTab">;

export default function GradesScreen({ navigation }: Props) {
  const insets = useSafeAreaInsets();
  const [grades, setGrades] = useState<GetGradesResponse["grades"]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchGrades = async () => {
    try {
      const response = await api.get<GetGradesResponse>("/grades");
      setGrades(response?.grades || []);
    } catch (error) {
      console.log("Error fetching grades:", error);
      setGrades([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchGrades();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    fetchGrades();
  };

  // Group grades by course
  const gradesByCourse = (grades || []).reduce((acc, grade) => {
    const key = grade.courseId;
    if (!acc[key]) {
      acc[key] = {
        courseName: grade.courseName,
        courseCode: grade.courseCode,
        grades: [],
      };
    }
    acc[key].grades.push(grade);
    return acc;
  }, {} as Record<string, { courseName: string; courseCode: string | null; grades: typeof grades }>);

  const getLetterGradeColor = (grade: string | null) => {
    if (!grade) return theme.colors.textSecondary;
    const letter = grade.charAt(0);
    if (letter === "A") return theme.colors.gradeA;
    if (letter === "B") return theme.colors.gradeB;
    if (letter === "C") return theme.colors.gradeC;
    if (letter === "D") return theme.colors.gradeD;
    return theme.colors.gradeF;
  };

  const calculateCourseAverage = (courseGrades: typeof grades) => {
    if (!courseGrades || !Array.isArray(courseGrades)) return null;
    const validGrades = courseGrades.filter((g) => g.percentage !== null);
    if (validGrades.length === 0) return null;
    const sum = validGrades.reduce((acc, g) => acc + (g.percentage || 0), 0);
    return sum / validGrades.length;
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.primary, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator size="large" color={theme.colors.accent} />
      </View>
    );
  }

  if (grades.length === 0) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.primary }}>
        <View style={{ paddingTop: insets.top, paddingBottom: theme.spacing.lg, paddingHorizontal: theme.spacing.xl }}>
          <Text style={{ fontSize: theme.fontSize.xxxl, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>Grades</Text>
        </View>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.accent} />}
        >
          <View style={{ flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: theme.spacing.xxl }}>
            <View
              style={{
                width: 100,
                height: 100,
                borderRadius: 50,
                backgroundColor: `${theme.colors.accent}20`,
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 20,
              }}
            >
              <Award size={50} color={theme.colors.accent} />
            </View>
            <Text style={{ fontSize: theme.fontSize.xl, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: 8, textAlign: "center" }}>
              No Grades Yet
            </Text>
            <Text style={{ fontSize: theme.fontSize.base, color: theme.colors.textSecondary, marginBottom: 24, textAlign: "center", lineHeight: 20, maxWidth: 300 }}>
              Your grades will appear here once you sync your Canvas account
            </Text>
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                navigation.navigate("CanvasConnect");
              }}
              style={({ pressed }) => ({
                backgroundColor: pressed ? "#2563EB" : theme.colors.accent,
                paddingHorizontal: 32,
                paddingVertical: 14,
                borderRadius: theme.borderRadius.md,
              })}
            >
              <Text style={{ color: theme.colors.textPrimary, fontWeight: theme.fontWeight.semibold, fontSize: theme.fontSize.md }}>Connect Canvas</Text>
            </Pressable>
          </View>
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.primary }}>
      <View style={{ paddingTop: insets.top, paddingBottom: theme.spacing.lg, paddingHorizontal: theme.spacing.xl }}>
        <Text style={{ fontSize: theme.fontSize.xxxl, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: 4 }}>
          Grades
        </Text>
        <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary }}>
          {grades.length} {grades.length === 1 ? "grade" : "grades"} across{" "}
          {Object.keys(gradesByCourse).length}{" "}
          {Object.keys(gradesByCourse).length === 1 ? "course" : "courses"}
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingHorizontal: theme.spacing.xl, paddingBottom: 100 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.accent} />}
      >
        {Object.entries(gradesByCourse).map(([courseId, courseData], index) => {
          const avg = calculateCourseAverage(courseData.grades);
          const avgLetter = avg
            ? avg >= 90
              ? "A"
              : avg >= 80
              ? "B"
              : avg >= 70
              ? "C"
              : avg >= 60
              ? "D"
              : "F"
            : null;

          return (
            <View key={courseId} style={{ marginBottom: theme.spacing.xxl }}>
              {/* Course Header Card */}
              <View
                style={{
                  backgroundColor: theme.colors.secondary,
                  borderRadius: theme.borderRadius.lg,
                  padding: theme.spacing.xl,
                  marginBottom: theme.spacing.md,
                  borderWidth: theme.borderWidth,
                  borderColor: theme.colors.border,
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 6 }}>
                      <BookOpen size={16} color={theme.colors.accent} style={{ marginRight: 8 }} />
                      <Text style={{ fontSize: theme.fontSize.lg, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>
                        {courseData.courseName}
                      </Text>
                    </View>
                    {courseData.courseCode && (
                      <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginLeft: 24 }}>
                        {courseData.courseCode}
                      </Text>
                    )}
                    <View
                      style={{
                        marginTop: 8,
                        marginLeft: 24,
                      }}
                    >
                      <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary }}>
                        {courseData.grades.length} {courseData.grades.length === 1 ? "grade" : "grades"}
                      </Text>
                    </View>
                  </View>
                  {avg !== null && (
                    <View style={{ alignItems: "center" }}>
                      <Text
                        style={{
                          fontSize: 40,
                          fontWeight: theme.fontWeight.bold,
                          color: getLetterGradeColor(avgLetter),
                          lineHeight: 44,
                        }}
                      >
                        {avgLetter}
                      </Text>
                      <Text style={{ fontSize: theme.fontSize.base, color: theme.colors.textSecondary, marginTop: 2 }}>
                        {avg.toFixed(1)}%
                      </Text>
                    </View>
                  )}
                </View>
              </View>

              {/* Grade Items */}
              {courseData.grades.map((grade, gradeIndex) => (
                <Pressable
                  key={grade.id}
                  onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)}
                  style={({ pressed }) => ({
                    backgroundColor: theme.colors.secondary,
                    borderRadius: theme.borderRadius.md,
                    padding: theme.spacing.lg,
                    marginBottom: theme.spacing.sm,
                    borderWidth: theme.borderWidth,
                    borderColor: theme.colors.border,
                    opacity: pressed ? 0.8 : 1,
                    flexDirection: "row",
                    alignItems: "center",
                    gap: theme.spacing.md,
                  })}
                >
                  <View
                    style={{
                      width: theme.priorityDotSize,
                      height: theme.priorityDotSize,
                      borderRadius: theme.priorityDotSize / 2,
                      backgroundColor: getLetterGradeColor(grade.letterGrade),
                    }}
                  />

                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: 6 }}>
                      {grade.assignmentName}
                    </Text>
                    {grade.gradedAt && (
                      <View style={{ flexDirection: "row", alignItems: "center" }}>
                        <Calendar size={12} color={theme.colors.textSecondary} style={{ marginRight: 4 }} />
                        <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary }}>
                          Graded {new Date(grade.gradedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                        </Text>
                      </View>
                    )}
                  </View>

                  <View style={{ alignItems: "flex-end" }}>
                    {grade.letterGrade && (
                      <Text
                        style={{
                          fontSize: 28,
                          fontWeight: theme.fontWeight.bold,
                          color: getLetterGradeColor(grade.letterGrade),
                          lineHeight: 32,
                        }}
                      >
                        {grade.letterGrade}
                      </Text>
                    )}
                    {grade.score !== null && grade.maxScore !== null && (
                      <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginTop: 2 }}>
                        {grade.score}/{grade.maxScore}
                      </Text>
                    )}
                    {grade.percentage !== null && (
                      <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.textSecondary, marginTop: 1 }}>
                        {grade.percentage.toFixed(1)}%
                      </Text>
                    )}
                  </View>
                </Pressable>
              ))}
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}
