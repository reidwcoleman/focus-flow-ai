import React, { useState } from "react";
import { View, Text, TextInput, Pressable, ScrollView, Alert, ActivityIndicator } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Sparkles, Calendar, CheckCircle2 } from "lucide-react-native";
import * as Haptics from "expo-haptics";

import type { BottomTabScreenProps, RootStackScreenProps } from "@/navigation/types";
import { api } from "@/lib/api";
import type { GenerateActivitiesFromDescriptionRequest, GenerateActivitiesFromDescriptionResponse } from "@/shared/contracts";

type Props = BottomTabScreenProps<"AISchedulerTab"> | RootStackScreenProps<"AIScheduler">;

const AISchedulerScreen = ({ navigation }: Props) => {
  const insets = useSafeAreaInsets();
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [generatedCount, setGeneratedCount] = useState<number | null>(null);

  const handleGenerate = async () => {
    if (!description.trim()) {
      Alert.alert("Description Required", "Please describe your activities before generating.");
      return;
    }

    setLoading(true);
    setGeneratedCount(null);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      console.log("[AIScheduler] Generating calendar activities...");
      const response = await api.post<GenerateActivitiesFromDescriptionRequest, GenerateActivitiesFromDescriptionResponse>(
        "/activities/generate-from-description",
        { description }
      );

      const count = response?.count || 0;
      console.log(`[AIScheduler] Generated ${count} activities`);
      setGeneratedCount(count);

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

      setTimeout(() => {
        Alert.alert(
          "Activities Created!",
          `Your ${count} calendar ${count === 1 ? 'activity' : 'activities'} ${count === 1 ? 'is' : 'are'} ready to view.`,
          [
            {
              text: "View Calendar",
              onPress: () => {
                // @ts-ignore - navigation type is union, both support this
                navigation.navigate("Tabs", { screen: "CalendarTab" });
              },
            },
            {
              text: "Create More",
              onPress: () => {
                setDescription("");
                setGeneratedCount(null);
              }
            },
          ]
        );
      }, 500);

    } catch (error: any) {
      console.log("[AIScheduler] Error:", error?.message || error);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);

      if (error?.status === 401) {
        Alert.alert("Sign In Required", "Please sign in to use AI scheduling.");
      } else {
        Alert.alert(
          "Error Creating Activities",
          "Unable to generate activities. Please try again or check your connection.",
          [
            { text: "OK" },
          ]
        );
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingBottom: 20,
          paddingHorizontal: 20,
          backgroundColor: "white",
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
        }}
      >
        <Text style={{ fontSize: 28, fontWeight: "700", color: "#111827" }}>AI Scheduler</Text>
      </View>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 100 }}>
        <View style={{ alignItems: "center", marginBottom: 30 }}>
          <View
            style={{
              width: 80,
              height: 80,
              borderRadius: 40,
              backgroundColor: "#EBF2FF",
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 16,
            }}
          >
            <Sparkles size={36} color="#3A7BFF" />
          </View>
          <Text style={{ fontSize: 22, fontWeight: "700", color: "#111827", marginBottom: 8 }}>
            AI Activity Planner
          </Text>
          <Text style={{ fontSize: 14, color: "#6B7280", textAlign: "center", maxWidth: 300 }}>
            Describe your activities and AI will add them to your calendar
          </Text>
          <Text style={{ fontSize: 12, color: "#9CA3AF", marginTop: 6, fontStyle: "italic" }}>
            Powered by Hugging Face AI
          </Text>
        </View>

        <View style={{ backgroundColor: "white", borderRadius: 16, padding: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 8 }}>
            Describe Your Activities
          </Text>
          <Text style={{ fontSize: 13, color: "#6B7280", marginBottom: 12 }}>
            Tell AI about your plans, events, tasks, or activities you want to schedule
          </Text>

          <Pressable
            onPress={() => {
              setDescription("I have a dentist appointment on Tuesday at 2pm. Need to study for my math exam on Thursday. Going to the gym Monday, Wednesday, and Friday evenings around 6pm. Meeting Sarah for coffee on Saturday morning.");
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }}
            style={{
              backgroundColor: "#F3F4F6",
              borderRadius: 8,
              padding: 10,
              marginBottom: 12,
              borderWidth: 1,
              borderColor: "#E5E7EB",
            }}
          >
            <Text style={{ fontSize: 12, color: "#3A7BFF", fontWeight: "600", marginBottom: 4 }}>
              Try Example
            </Text>
            <Text style={{ fontSize: 11, color: "#6B7280", lineHeight: 16 }}>
              Dentist Tuesday 2pm, study math Thursday, gym Mon/Wed/Fri 6pm...
            </Text>
          </Pressable>

          <TextInput
            value={description}
            onChangeText={setDescription}
            placeholder="Describe your activities: appointments, study sessions, workouts, social events..."
            multiline
            numberOfLines={8}
            textAlignVertical="top"
            style={{
              backgroundColor: "#F9FAFB",
              borderRadius: 8,
              padding: 12,
              fontSize: 15,
              marginBottom: 20,
              borderWidth: 1,
              borderColor: "#E5E7EB",
              minHeight: 150,
            }}
          />

          <Pressable
            onPress={handleGenerate}
            disabled={loading || !description.trim()}
            style={{
              backgroundColor: description.trim() && !loading ? "#3A7BFF" : "#D1D5DB",
              borderRadius: 12,
              padding: 16,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
            }}
          >
            {loading ? (
              <>
                <ActivityIndicator color="white" size="small" />
                <Text style={{ color: "white", fontWeight: "600", fontSize: 15 }}>
                  Creating activities...
                </Text>
              </>
            ) : generatedCount !== null ? (
              <>
                <CheckCircle2 size={20} color="white" />
                <Text style={{ color: "white", fontWeight: "600", fontSize: 15 }}>
                  Created {generatedCount} {generatedCount === 1 ? 'activity' : 'activities'}!
                </Text>
              </>
            ) : (
              <>
                <Sparkles size={20} color="white" />
                <Text style={{ color: "white", fontWeight: "600", fontSize: 15 }}>
                  Generate Activities
                </Text>
              </>
            )}
          </Pressable>
        </View>

        <View style={{ backgroundColor: "#EBF2FF", borderRadius: 12, padding: 16, marginBottom: 16 }}>
          <Text style={{ fontSize: 13, fontWeight: "600", color: "#1E40AF", marginBottom: 8 }}>
            💡 Tips for best results:
          </Text>
          <Text style={{ fontSize: 12, color: "#1E40AF", lineHeight: 18 }}>
            • Mention specific dates and times{"\n"}
            • Include appointments and meetings{"\n"}
            • Add recurring activities{"\n"}
            • Describe study sessions or work blocks{"\n"}
            • Mention social events or personal time
          </Text>
        </View>

        <Pressable
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            // @ts-ignore - navigation type is union, both support this
            navigation.navigate("Tabs", { screen: "CalendarTab" });
          }}
          style={{
            backgroundColor: "white",
            borderRadius: 12,
            padding: 16,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <Calendar size={20} color="#111827" />
          <Text style={{ color: "#111827", fontWeight: "600", fontSize: 15 }}>View Calendar</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
};

export default AISchedulerScreen;
