import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  TextInput,
  Alert,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Calendar as CalendarIcon, Plus, Sparkles, Edit2, Trash2, Check, X } from "lucide-react-native";
import * as Haptics from "expo-haptics";

import type { BottomTabScreenProps } from "@/navigation/types";
import { api } from "@/lib/api";
import type { GetActivitiesResponse, CreateActivityRequest, CreateActivityResponse } from "@/shared/contracts";
import { theme } from "@/theme/theme";

type Props = BottomTabScreenProps<"CalendarTab">;

type Activity = GetActivitiesResponse["activities"][number];

const CalendarScreen = ({ navigation }: Props) => {
  const insets = useSafeAreaInsets();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [activities, setActivities] = useState<Activity[]>([]);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [aiInput, setAiInput] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [pendingActivity, setPendingActivity] = useState<Partial<Activity> | null>(null);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);

  useEffect(() => {
    loadActivities();
  }, []);

  const loadActivities = async () => {
    try {
      console.log("[Calendar] Loading activities from API...");
      const response = await api.get<GetActivitiesResponse>("/activities");
      console.log(`[Calendar] Loaded ${response?.activities?.length || 0} activities`);
      setActivities(response?.activities || []);
    } catch (error: any) {
      console.log("[Calendar] Error loading activities:", error?.message || error);
      if (error?.status !== 401) {
        Alert.alert("Error", "Failed to load activities. Please try again.");
      }
      setActivities([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadActivities();
  };

  const getWeekDays = (date: Date) => {
    const startOfWeek = new Date(date);
    const day = startOfWeek.getDay();
    const diff = startOfWeek.getDate() - day;
    startOfWeek.setDate(diff);

    const days = [];
    for (let i = 0; i < 7; i++) {
      const currentDay = new Date(startOfWeek);
      currentDay.setDate(startOfWeek.getDate() + i);
      days.push(currentDay);
    }
    return days;
  };

  const weekDays = getWeekDays(selectedDate);

  const getActivitiesForDate = (date: Date) => {
    const dateStr = date.toISOString().split("T")[0];
    return activities.filter((a) => {
      const activityDate = typeof a.date === 'string' ? a.date.split("T")[0] : new Date(a.date).toISOString().split("T")[0];
      return activityDate === dateStr;
    });
  };

  const handlePrevWeek = () => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() - 7);
    setSelectedDate(newDate);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleNextWeek = () => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + 7);
    setSelectedDate(newDate);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleDayPress = (date: Date) => {
    setSelectedDate(date);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleAICreate = async () => {
    if (!aiInput.trim()) return;

    setAiLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      console.log("[Calendar] Creating activity with AI...");
      const activityData: CreateActivityRequest = {
        title: aiInput,
        date: selectedDate.toISOString().split("T")[0],
        color: theme.colors.accent,
        allDay: true,
      };

      const response = await api.post<CreateActivityRequest, CreateActivityResponse>(
        "/activities",
        activityData
      );

      console.log("[Calendar] Activity created:", response?.activity?.id);

      if (response?.activity) {
        setActivities([...activities, response.activity]);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        Alert.alert("Activity Added", "Your activity has been added to the calendar.");
      }

      setShowAIAssistant(false);
      setAiInput("");
    } catch (error: any) {
      console.log("[Calendar] Error creating activity:", error?.message || error);
      if (error?.status === 401) {
        Alert.alert("Sign In Required", "Please sign in to create activities.");
      } else {
        Alert.alert("Error", "Failed to create activity. Try again.");
      }
    } finally {
      setAiLoading(false);
    }
  };

  const handleSaveActivity = async () => {
    if (pendingActivity && pendingActivity.title) {
      try {
        console.log("[Calendar] Saving activity...");
        const activityData: CreateActivityRequest = {
          title: pendingActivity.title,
          description: pendingActivity.description || undefined,
          date: pendingActivity.date || selectedDate.toISOString().split("T")[0],
          startTime: pendingActivity.startTime || undefined,
          endTime: pendingActivity.endTime || undefined,
          color: pendingActivity.color || theme.colors.accent,
          allDay: pendingActivity.allDay ?? true,
        };

        const response = await api.post<CreateActivityRequest, CreateActivityResponse>(
          "/activities",
          activityData
        );

        if (response?.activity) {
          setActivities([...activities, response.activity]);
          setPendingActivity(null);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          Alert.alert("Activity Added", "Your activity has been added to the calendar.");
        }
      } catch (error: any) {
        console.log("[Calendar] Error saving activity:", error?.message || error);
        Alert.alert("Error", "Failed to save activity. Try again.");
      }
    }
  };

  const handleEditActivity = (activity: Activity) => {
    setEditingActivity(activity);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleSaveEdit = async () => {
    if (editingActivity) {
      try {
        console.log("[Calendar] Updating activity:", editingActivity.id);
        const updateData = {
          title: editingActivity.title,
          description: editingActivity.description,
          date: editingActivity.date,
          startTime: editingActivity.startTime,
          endTime: editingActivity.endTime,
          color: editingActivity.color,
          allDay: editingActivity.allDay,
          completed: editingActivity.completed,
        };

        await api.patch(`/activities/${editingActivity.id}`, updateData);

        setActivities(activities.map((a) => (a.id === editingActivity.id ? editingActivity : a)));
        setEditingActivity(null);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (error: any) {
        console.log("[Calendar] Error updating activity:", error?.message || error);
        Alert.alert("Error", "Failed to update activity. Try again.");
      }
    }
  };

  const handleDeleteActivity = (id: string) => {
    Alert.alert("Delete Activity", "Are you sure you want to delete this activity?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          try {
            console.log("[Calendar] Deleting activity:", id);
            await api.delete(`/activities/${id}`);
            setActivities(activities.filter((a) => a.id !== id));
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          } catch (error: any) {
            console.log("[Calendar] Error deleting activity:", error?.message || error);
            Alert.alert("Error", "Failed to delete activity. Try again.");
          }
        },
      },
    ]);
  };

  const getActivitiesForSelectedDate = () => {
    return getActivitiesForDate(selectedDate);
  };

  const formatWeekRange = () => {
    const startDate = weekDays[0];
    const endDate = weekDays[6];
    const startMonth = monthNames[startDate.getMonth()];
    const endMonth = monthNames[endDate.getMonth()];

    if (startMonth === endMonth) {
      return `${startMonth} ${startDate.getDate()} - ${endDate.getDate()}, ${endDate.getFullYear()}`;
    } else {
      return `${startMonth} ${startDate.getDate()} - ${endMonth} ${endDate.getDate()}, ${endDate.getFullYear()}`;
    }
  };

  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.primary, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator size="large" color={theme.colors.accent} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.primary }}>
      <View style={{ paddingTop: insets.top, paddingBottom: theme.spacing.lg, paddingHorizontal: theme.spacing.xl }}>
        <Text style={{ fontSize: theme.fontSize.xxxl, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>Calendar</Text>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingHorizontal: theme.spacing.xl, paddingBottom: 100 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.accent} />
        }
      >
        {/* Week Header */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: theme.spacing.lg,
          }}
        >
          <Pressable onPress={handlePrevWeek} style={{ padding: 8 }}>
            <Text style={{ fontSize: 18, color: theme.colors.accent, fontWeight: theme.fontWeight.semibold }}>←</Text>
          </Pressable>

          <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, letterSpacing: theme.letterSpacing.tight }}>
            {formatWeekRange().toUpperCase()}
          </Text>

          <Pressable onPress={handleNextWeek} style={{ padding: 8 }}>
            <Text style={{ fontSize: 18, color: theme.colors.accent, fontWeight: theme.fontWeight.semibold }}>→</Text>
          </Pressable>
        </View>

        {/* Weekly Calendar Grid */}
        <View style={{ backgroundColor: theme.colors.secondary, borderRadius: theme.borderRadius.lg, padding: theme.spacing.lg, marginBottom: theme.spacing.lg, borderWidth: theme.borderWidth, borderColor: theme.colors.border }}>
          {/* Day Labels */}
          <View style={{ flexDirection: "row", marginBottom: theme.spacing.md }}>
            {["S", "M", "T", "W", "T", "F", "S"].map((day, i) => (
              <View key={i} style={{ flex: 1, alignItems: "center" }}>
                <Text style={{ fontSize: theme.fontSize.xs, fontWeight: theme.fontWeight.semibold, color: theme.colors.textSecondary }}>{day}</Text>
              </View>
            ))}
          </View>

          {/* Week Days */}
          <View style={{ flexDirection: "row" }}>
            {weekDays.map((day, i) => {
              const isSelected = selectedDate.toDateString() === day.toDateString();
              const isToday = new Date().toDateString() === day.toDateString();
              const dayActivities = getActivitiesForDate(day);
              const hasActivities = dayActivities.length > 0;

              return (
                <Pressable
                  key={i}
                  onPress={() => handleDayPress(day)}
                  style={{
                    flex: 1,
                    alignItems: "center",
                    justifyContent: "center",
                    paddingVertical: 8,
                  }}
                >
                  <View
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 20,
                      backgroundColor: isSelected ? theme.colors.accent : isToday ? `${theme.colors.accent}30` : "transparent",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: theme.fontSize.md,
                        fontWeight: isSelected || isToday ? theme.fontWeight.semibold : theme.fontWeight.normal,
                        color: isSelected ? theme.colors.textPrimary : theme.colors.textPrimary,
                      }}
                    >
                      {day.getDate()}
                    </Text>
                  </View>
                  {hasActivities && (
                    <View style={{ flexDirection: "row", marginTop: 4, gap: 2 }}>
                      {dayActivities.slice(0, 3).map((activity, idx) => (
                        <View
                          key={idx}
                          style={{
                            width: theme.priorityDotSize,
                            height: theme.priorityDotSize,
                            borderRadius: theme.priorityDotSize / 2,
                            backgroundColor: activity.color || theme.colors.accent,
                          }}
                        />
                      ))}
                    </View>
                  )}
                </Pressable>
              );
            })}
          </View>
        </View>

        {/* AI Assistant Button */}
        <Pressable
          onPress={() => {
            setShowAIAssistant(true);
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          }}
          style={{
            backgroundColor: theme.colors.accent,
            borderRadius: theme.borderRadius.md,
            padding: theme.spacing.lg,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            marginBottom: theme.spacing.lg,
          }}
        >
          <Sparkles size={18} color={theme.colors.textPrimary} />
          <Text style={{ color: theme.colors.textPrimary, fontWeight: theme.fontWeight.semibold, fontSize: theme.fontSize.md }}>Add Activity with AI</Text>
        </Pressable>

        {/* AI Assistant Modal */}
        {showAIAssistant && (
          <View style={{ backgroundColor: theme.colors.secondary, borderRadius: theme.borderRadius.lg, padding: theme.spacing.xl, marginBottom: theme.spacing.lg, borderWidth: theme.borderWidth, borderColor: theme.colors.border }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: theme.spacing.lg }}>
              <Text style={{ fontSize: theme.fontSize.lg, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>AI Assistant</Text>
              <Pressable onPress={() => setShowAIAssistant(false)}>
                <X size={24} color={theme.colors.textSecondary} />
              </Pressable>
            </View>

            <Text style={{ fontSize: theme.fontSize.base, color: theme.colors.textSecondary, marginBottom: theme.spacing.md }}>
              Describe your activity in natural language:
            </Text>

            <TextInput
              value={aiInput}
              onChangeText={setAiInput}
              placeholder="e.g., 'Dentist appointment tomorrow at 2pm'"
              placeholderTextColor={theme.colors.textSecondary}
              multiline
              numberOfLines={3}
              style={{
                backgroundColor: theme.colors.primary,
                borderRadius: theme.borderRadius.md,
                padding: theme.spacing.lg,
                fontSize: theme.fontSize.md,
                marginBottom: theme.spacing.lg,
                borderWidth: theme.borderWidth,
                borderColor: theme.colors.border,
                minHeight: 80,
                color: theme.colors.textPrimary,
              }}
            />

            <Pressable
              onPress={handleAICreate}
              disabled={aiLoading || !aiInput.trim()}
              style={{
                backgroundColor: aiInput.trim() && !aiLoading ? theme.colors.success : theme.colors.border,
                borderRadius: theme.borderRadius.md,
                padding: theme.spacing.lg,
                alignItems: "center",
              }}
            >
              {aiLoading ? (
                <ActivityIndicator color={theme.colors.textPrimary} />
              ) : (
                <Text style={{ color: theme.colors.textPrimary, fontWeight: theme.fontWeight.semibold, fontSize: theme.fontSize.md }}>Create Activity</Text>
              )}
            </Pressable>
          </View>
        )}

        {/* Activities for Selected Date */}
        <View style={{ backgroundColor: theme.colors.secondary, borderRadius: theme.borderRadius.lg, padding: theme.spacing.xl, borderWidth: theme.borderWidth, borderColor: theme.colors.border }}>
          <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: theme.spacing.lg, letterSpacing: theme.letterSpacing.wide }}>
            {selectedDate.toLocaleDateString("en-US", { month: "long", day: "numeric" }).toUpperCase()}
          </Text>

          {getActivitiesForSelectedDate().length === 0 ? (
            <View style={{ alignItems: "center", paddingVertical: theme.spacing.xl }}>
              <CalendarIcon size={48} color={theme.colors.textSecondary} />
              <Text style={{ fontSize: theme.fontSize.base, color: theme.colors.textSecondary, marginTop: theme.spacing.md }}>No activities for this day</Text>
            </View>
          ) : (
            getActivitiesForSelectedDate().map((activity) => (
              <View
                key={activity.id}
                style={{
                  backgroundColor: theme.colors.primary,
                  borderRadius: theme.borderRadius.md,
                  padding: theme.spacing.lg,
                  marginBottom: theme.spacing.md,
                  borderWidth: theme.borderWidth,
                  borderColor: theme.colors.border,
                  flexDirection: "row",
                  alignItems: "center",
                  gap: theme.spacing.md,
                }}
              >
                <View
                  style={{
                    width: theme.priorityDotSize,
                    height: theme.priorityDotSize,
                    borderRadius: theme.priorityDotSize / 2,
                    backgroundColor: activity.color || theme.colors.accent,
                  }}
                />

                {editingActivity?.id === activity.id ? (
                  <View style={{ flex: 1 }}>
                    <TextInput
                      value={editingActivity.title}
                      onChangeText={(text) => setEditingActivity({ ...editingActivity, title: text })}
                      style={{
                        backgroundColor: theme.colors.secondary,
                        borderRadius: theme.borderRadius.sm,
                        padding: theme.spacing.md,
                        fontSize: theme.fontSize.md,
                        marginBottom: theme.spacing.md,
                        borderWidth: theme.borderWidth,
                        borderColor: theme.colors.border,
                        color: theme.colors.textPrimary,
                      }}
                    />
                    <View style={{ flexDirection: "row", gap: 8 }}>
                      <Pressable
                        onPress={() => setEditingActivity(null)}
                        style={{
                          flex: 1,
                          backgroundColor: theme.colors.border,
                          borderRadius: theme.borderRadius.sm,
                          padding: theme.spacing.md,
                          alignItems: "center",
                        }}
                      >
                        <Text style={{ fontSize: theme.fontSize.sm, fontWeight: theme.fontWeight.semibold, color: theme.colors.textSecondary }}>Cancel</Text>
                      </Pressable>
                      <Pressable
                        onPress={handleSaveEdit}
                        style={{
                          flex: 1,
                          backgroundColor: theme.colors.success,
                          borderRadius: theme.borderRadius.sm,
                          padding: theme.spacing.md,
                          alignItems: "center",
                        }}
                      >
                        <Text style={{ fontSize: theme.fontSize.sm, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary }}>Save</Text>
                      </Pressable>
                    </View>
                  </View>
                ) : (
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: theme.fontSize.md, fontWeight: theme.fontWeight.semibold, color: theme.colors.textPrimary, marginBottom: 4 }}>
                      {activity.title}
                    </Text>
                    {activity.description && (
                      <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginBottom: 8 }}>{activity.description}</Text>
                    )}
                    {(activity.startTime || activity.endTime) && (
                      <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.textSecondary, marginBottom: 8 }}>
                        {activity.startTime || "?"} - {activity.endTime || "?"}
                      </Text>
                    )}
                    <View style={{ flexDirection: "row", gap: 8 }}>
                      <Pressable
                        onPress={() => handleEditActivity(activity)}
                        style={{
                          flexDirection: "row",
                          alignItems: "center",
                          gap: 4,
                          backgroundColor: theme.colors.secondary,
                          borderRadius: theme.borderRadius.sm,
                          padding: theme.spacing.sm,
                          borderWidth: theme.borderWidth,
                          borderColor: theme.colors.border,
                        }}
                      >
                        <Edit2 size={12} color={theme.colors.accent} />
                        <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.accent, fontWeight: theme.fontWeight.semibold }}>Edit</Text>
                      </Pressable>
                      <Pressable
                        onPress={() => handleDeleteActivity(activity.id)}
                        style={{
                          flexDirection: "row",
                          alignItems: "center",
                          gap: 4,
                          backgroundColor: theme.colors.secondary,
                          borderRadius: theme.borderRadius.sm,
                          padding: theme.spacing.sm,
                          borderWidth: theme.borderWidth,
                          borderColor: theme.colors.border,
                        }}
                      >
                        <Trash2 size={12} color={theme.colors.error} />
                        <Text style={{ fontSize: theme.fontSize.xs, color: theme.colors.error, fontWeight: theme.fontWeight.semibold }}>Delete</Text>
                      </Pressable>
                    </View>
                  </View>
                )}
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
};

export default CalendarScreen;
