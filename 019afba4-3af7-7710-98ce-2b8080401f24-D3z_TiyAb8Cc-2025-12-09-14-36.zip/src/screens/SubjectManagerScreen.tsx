import React, { useState, useEffect } from "react";
import { View, Text, TextInput, ScrollView, Pressable, Alert } from "react-native";
import * as Haptics from "expo-haptics";
import { Plus, Trash2 } from "lucide-react-native";

import type { RootStackScreenProps } from "@/navigation/types";
import { api } from "@/lib/api";
import type { CreateSubjectRequest, GetSubjectsResponse } from "@/shared/contracts";

type Props = RootStackScreenProps<"SubjectManager">;

const PRESET_COLORS = [
  "#EF4444", // red
  "#F59E0B", // orange
  "#10B981", // green
  "#3A7BFF", // blue
  "#8B5CF6", // purple
  "#EC4899", // pink
  "#14B8A6", // teal
  "#F97316", // orange
];

const SubjectManagerScreen = ({ navigation }: Props) => {
  const [subjects, setSubjects] = useState<GetSubjectsResponse["subjects"]>([]);
  const [newSubjectName, setNewSubjectName] = useState("");
  const [selectedColor, setSelectedColor] = useState(PRESET_COLORS[0]);

  const fetchSubjects = async () => {
    try {
      const response = await api.get<GetSubjectsResponse>("/subjects");
      setSubjects(response?.subjects || []);
    } catch (error) {
      console.log("Error fetching subjects:", error);
      setSubjects([]);
    }
  };

  useEffect(() => {
    fetchSubjects();
  }, []);

  const handleCreate = async () => {
    if (!newSubjectName.trim()) return;

    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      await api.post<CreateSubjectRequest>("/subjects", {
        name: newSubjectName,
        color: selectedColor,
      });
      setNewSubjectName("");
      setSelectedColor(PRESET_COLORS[0]);
      fetchSubjects();
    } catch (error) {
      console.log("Error creating subject:", error);
    }
  };

  const handleDelete = async (subjectId: string, subjectName: string) => {
    Alert.alert("Delete Subject", `Delete "${subjectName}"? Assignments will not be deleted.`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          try {
            await api.delete(`/subjects/${subjectId}`);
            fetchSubjects();
          } catch (error) {
            console.log("Error deleting subject:", error);
          }
        },
      },
    ]);
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 100 }}>
        <View
          style={{
            backgroundColor: "white",
            borderRadius: 16,
            padding: 20,
            marginBottom: 20,
          }}
        >
          <Text style={{ fontSize: 16, fontWeight: "600", color: "#111827", marginBottom: 12 }}>
            Add New Subject
          </Text>

          <TextInput
            value={newSubjectName}
            onChangeText={setNewSubjectName}
            placeholder="e.g. Mathematics"
            style={{
              backgroundColor: "#F9FAFB",
              borderRadius: 8,
              padding: 12,
              fontSize: 15,
              marginBottom: 16,
              borderWidth: 1,
              borderColor: "#E5E7EB",
            }}
          />

          <Text style={{ fontSize: 13, fontWeight: "600", color: "#6B7280", marginBottom: 8 }}>
            Choose Color
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 12, marginBottom: 16 }}>
            {PRESET_COLORS.map((color) => (
              <Pressable
                key={color}
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  setSelectedColor(color);
                }}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: color,
                  borderWidth: selectedColor === color ? 3 : 0,
                  borderColor: "#111827",
                }}
              />
            ))}
          </View>

          <Pressable
            onPress={handleCreate}
            style={{
              backgroundColor: newSubjectName.trim() ? "#3A7BFF" : "#D1D5DB",
              borderRadius: 8,
              padding: 14,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
            }}
            disabled={!newSubjectName.trim()}
          >
            <Plus size={20} color="white" />
            <Text style={{ color: "white", fontWeight: "600", fontSize: 15 }}>Add Subject</Text>
          </Pressable>
        </View>

        <Text style={{ fontSize: 16, fontWeight: "600", color: "#111827", marginBottom: 12 }}>
          Your Subjects
        </Text>

        {!subjects || subjects.length === 0 ? (
          <View
            style={{
              backgroundColor: "white",
              borderRadius: 16,
              padding: 40,
              alignItems: "center",
            }}
          >
            <Text style={{ fontSize: 14, color: "#6B7280", textAlign: "center" }}>
              No subjects yet. Add your first subject above!
            </Text>
          </View>
        ) : (
          subjects.map((subject) => (
            <View
              key={subject.id}
              style={{
                backgroundColor: "white",
                borderRadius: 12,
                padding: 16,
                marginBottom: 8,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                borderLeftWidth: 4,
                borderLeftColor: subject.color,
              }}
            >
              <Text style={{ fontSize: 15, fontWeight: "600", color: "#111827" }}>
                {subject.name}
              </Text>
              <Pressable
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  handleDelete(subject.id, subject.name);
                }}
                style={{ padding: 8 }}
              >
                <Trash2 size={18} color="#EF4444" />
              </Pressable>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
};

export default SubjectManagerScreen;
