import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, Pressable, Alert } from "react-native";
import * as Haptics from "expo-haptics";
import { Check, Trash2, ChevronLeft } from "lucide-react-native";

import type { RootStackScreenProps } from "@/navigation/types";
import { api } from "@/lib/api";
import type { GetAssignmentsResponse, UpdateAssignmentRequest } from "@/shared/contracts";

type Props = RootStackScreenProps<"AssignmentDetail">;

const AssignmentDetailScreen = ({ route, navigation }: Props) => {
  const { assignmentId } = route.params;
  const [assignment, setAssignment] = useState<GetAssignmentsResponse["assignments"][0] | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchAssignment = async () => {
    try {
      const response = await api.get<GetAssignmentsResponse>("/assignments");
      const found = response.assignments.find((a) => a.id === assignmentId);
      setAssignment(found || null);
    } catch (error) {
      console.log("Error fetching assignment:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAssignment();
  }, [assignmentId]);

  const updateStatus = async (status: "todo" | "in_progress" | "completed") => {
    if (!assignment) return;

    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      await api.patch<UpdateAssignmentRequest>(`/assignments/${assignmentId}`, { status });
      navigation.goBack();
    } catch (error) {
      console.log("Error updating assignment:", error);
    }
  };

  const deleteAssignment = async () => {
    Alert.alert("Delete Assignment", "Are you sure you want to delete this assignment?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          try {
            await api.delete(`/assignments/${assignmentId}`);
            navigation.goBack();
          } catch (error) {
            console.log("Error deleting assignment:", error);
          }
        },
      },
    ]);
  };

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <Text>Loading...</Text>
      </View>
    );
  }

  if (!assignment) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <Text>Assignment not found</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <View
          style={{
            backgroundColor: "white",
            borderRadius: 16,
            padding: 20,
            marginBottom: 20,
            borderLeftWidth: 4,
            borderLeftColor: assignment.subject?.color || "#3A7BFF",
          }}
        >
          <Text style={{ fontSize: 24, fontWeight: "700", color: "#111827", marginBottom: 8 }}>
            {assignment.title}
          </Text>
          {assignment.subject && (
            <Text style={{ fontSize: 15, color: "#6B7280", marginBottom: 16 }}>
              {assignment.subject.name}
            </Text>
          )}
          {assignment.description && (
            <Text style={{ fontSize: 14, color: "#4B5563", marginBottom: 16 }}>
              {assignment.description}
            </Text>
          )}
          <Text style={{ fontSize: 13, color: "#9CA3AF" }}>
            Due: {new Date(assignment.dueDate).toLocaleDateString()}
          </Text>
        </View>

        <Text style={{ fontSize: 16, fontWeight: "600", color: "#111827", marginBottom: 12 }}>
          Update Status
        </Text>

        <Pressable
          onPress={() => updateStatus("completed")}
          style={{
            backgroundColor: "#10B981",
            borderRadius: 12,
            padding: 16,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            marginBottom: 12,
          }}
        >
          <Check size={20} color="white" />
          <Text style={{ color: "white", fontWeight: "600", fontSize: 15 }}>Mark as Complete</Text>
        </Pressable>

        <Pressable
          onPress={deleteAssignment}
          style={{
            backgroundColor: "#EF4444",
            borderRadius: 12,
            padding: 16,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <Trash2 size={20} color="white" />
          <Text style={{ color: "white", fontWeight: "600", fontSize: 15 }}>Delete Assignment</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
};

export default AssignmentDetailScreen;
