import React, { useState, useEffect } from "react";
import { View, Text, TextInput, ScrollView, Pressable, Platform } from "react-native";
import * as Haptics from "expo-haptics";
import DateTimePicker from "@react-native-community/datetimepicker";
import { X } from "lucide-react-native";

import type { RootStackScreenProps } from "@/navigation/types";
import { api } from "@/lib/api";
import type { CreateAssignmentRequest, GetSubjectsResponse } from "@/shared/contracts";

type Props = RootStackScreenProps<"AddAssignment">;

const AddAssignmentScreen = ({ navigation }: Props) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [priority, setPriority] = useState<"low" | "medium" | "high" | "urgent">("medium");
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | undefined>();
  const [subjects, setSubjects] = useState<GetSubjectsResponse["subjects"]>([]);

  useEffect(() => {
    const fetchSubjects = async () => {
      try {
        const response = await api.get<GetSubjectsResponse>("/subjects");
        setSubjects(response.subjects);
      } catch (error) {
        console.log("Error fetching subjects:", error);
      }
    };
    fetchSubjects();
  }, []);

  const handleCreate = async () => {
    if (!title.trim()) {
      return;
    }

    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      await api.post<CreateAssignmentRequest>("/assignments", {
        title,
        description: description || undefined,
        dueDate: dueDate.toISOString(),
        priority,
        subjectId: selectedSubjectId,
      });
      navigation.goBack();
    } catch (error) {
      console.log("Error creating assignment:", error);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 8 }}>
          Title
        </Text>
        <TextInput
          value={title}
          onChangeText={setTitle}
          placeholder="e.g. Math Homework Ch. 5"
          style={{
            backgroundColor: "white",
            borderRadius: 12,
            padding: 16,
            fontSize: 15,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: "#E5E7EB",
          }}
        />

        <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 8 }}>
          Description (Optional)
        </Text>
        <TextInput
          value={description}
          onChangeText={setDescription}
          placeholder="Add details..."
          multiline
          numberOfLines={3}
          style={{
            backgroundColor: "white",
            borderRadius: 12,
            padding: 16,
            fontSize: 15,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: "#E5E7EB",
            textAlignVertical: "top",
          }}
        />

        <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 8 }}>
          Due Date
        </Text>
        <Pressable
          onPress={() => setShowDatePicker(true)}
          style={{
            backgroundColor: "white",
            borderRadius: 12,
            padding: 16,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: "#E5E7EB",
          }}
        >
          <Text style={{ fontSize: 15, color: "#111827" }}>
            {dueDate.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
          </Text>
        </Pressable>
        {showDatePicker && (
          <DateTimePicker
            value={dueDate}
            mode="date"
            display={Platform.OS === "ios" ? "spinner" : "default"}
            onChange={(event, selectedDate) => {
              setShowDatePicker(Platform.OS === "ios");
              if (selectedDate) {
                setDueDate(selectedDate);
              }
            }}
          />
        )}

        <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 8 }}>
          Priority
        </Text>
        <View style={{ flexDirection: "row", gap: 8, marginBottom: 20 }}>
          {(["low", "medium", "high", "urgent"] as const).map((p) => (
            <Pressable
              key={p}
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setPriority(p);
              }}
              style={{
                flex: 1,
                backgroundColor: priority === p ? "#3A7BFF" : "white",
                borderRadius: 8,
                padding: 12,
                alignItems: "center",
                borderWidth: 1,
                borderColor: priority === p ? "#3A7BFF" : "#E5E7EB",
              }}
            >
              <Text
                style={{
                  fontSize: 13,
                  fontWeight: "600",
                  color: priority === p ? "white" : "#6B7280",
                  textTransform: "capitalize",
                }}
              >
                {p}
              </Text>
            </Pressable>
          ))}
        </View>

        {subjects.length > 0 && (
          <>
            <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 8 }}>
              Subject (Optional)
            </Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 20 }}>
              <View style={{ flexDirection: "row", gap: 8 }}>
                {subjects.map((subject) => (
                  <Pressable
                    key={subject.id}
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      setSelectedSubjectId(selectedSubjectId === subject.id ? undefined : subject.id);
                    }}
                    style={{
                      backgroundColor: selectedSubjectId === subject.id ? subject.color : "white",
                      borderRadius: 20,
                      paddingHorizontal: 16,
                      paddingVertical: 10,
                      borderWidth: 2,
                      borderColor: subject.color,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 14,
                        fontWeight: "600",
                        color: selectedSubjectId === subject.id ? "white" : subject.color,
                      }}
                    >
                      {subject.name}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </ScrollView>
          </>
        )}

        <Pressable
          onPress={handleCreate}
          style={{
            backgroundColor: title.trim() ? "#3A7BFF" : "#D1D5DB",
            borderRadius: 12,
            padding: 18,
            alignItems: "center",
            marginTop: 20,
          }}
          disabled={!title.trim()}
        >
          <Text style={{ color: "white", fontWeight: "600", fontSize: 16 }}>Create Assignment</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
};

export default AddAssignmentScreen;
