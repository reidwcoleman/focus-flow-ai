import { useEffect, useState } from "react";
import { StyleSheet, View, ActivityIndicator } from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { BlurView } from "expo-blur";
import * as Haptics from "expo-haptics";
import { Home, Calendar, CalendarDays, Sparkles, Award, Settings, CheckSquare, Shield, BarChart3 } from "lucide-react-native";

import type { BottomTabParamList, RootStackParamList } from "@/navigation/types";
import { useSession } from "@/lib/useSession";
import { api } from "@/lib/api";
import HomeScreen from "@/screens/HomeScreen";
import TasksScreen from "@/screens/TasksScreen";
import WeeklyScheduleScreen from "@/screens/WeeklyScheduleScreen";
import CalendarScreen from "@/screens/CalendarScreen";
import AnalyticsScreen from "@/screens/AnalyticsScreen";
import GradesScreen from "@/screens/GradesScreen";
import ProfileScreen from "@/screens/ProfileScreen";
import AuthScreen from "@/screens/AuthScreen";
import LoginModalScreen from "@/screens/LoginModalScreen";
import AssignmentDetailScreen from "@/screens/AssignmentDetailScreen";
import AddAssignmentScreen from "@/screens/AddAssignmentScreen";
import SubjectManagerScreen from "@/screens/SubjectManagerScreen";
import CanvasConnectScreen from "@/screens/CanvasConnectScreen";
import AISchedulerScreen from "@/screens/AISchedulerScreen";
import StudyTimeScreen from "@/screens/StudyTimeScreen";
import ActiveStudySessionScreen from "@/screens/ActiveStudySessionScreen";

/**
 * RootStackNavigator
 * The root navigator for the app, which handles authentication and Canvas onboarding
 */
const RootStack = createNativeStackNavigator<RootStackParamList>();
const RootNavigator = () => {
  const { data: session, isPending: sessionLoading } = useSession();
  const [canvasConnected, setCanvasConnected] = useState<boolean | null>(null);
  const [checkingCanvas, setCheckingCanvas] = useState(true);

  // Check Canvas connection status when user is authenticated
  useEffect(() => {
    const checkCanvasStatus = async () => {
      if (!session) {
        setCanvasConnected(null);
        setCheckingCanvas(false);
        return;
      }

      try {
        console.log("[RootNavigator] Checking Canvas connection status...");
        const response = await api.get<{ connected: boolean }>("/canvas/status");
        console.log("[RootNavigator] Canvas connected:", response?.connected);
        setCanvasConnected(response?.connected || false);
      } catch (error: any) {
        console.log("[RootNavigator] Error checking Canvas status:", error?.message || error);
        setCanvasConnected(false);
      } finally {
        setCheckingCanvas(false);
      }
    };

    checkCanvasStatus();
  }, [session]);

  // Show loading screen while checking authentication
  if (sessionLoading || (session && checkingCanvas)) {
    return (
      <View style={{ flex: 1, backgroundColor: "#F9FAFB", alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator size="large" color="#3A7BFF" />
      </View>
    );
  }

  // If not authenticated, show auth screen
  if (!session) {
    return (
      <RootStack.Navigator screenOptions={{ headerShown: false }}>
        <RootStack.Screen name="Auth" component={AuthScreen} />
      </RootStack.Navigator>
    );
  }

  // User is authenticated, show main app with all screens
  // Include all modal/detail screens regardless of Canvas connection status
  return (
    <RootStack.Navigator>
      {canvasConnected === false && (
        <RootStack.Screen
          name="CanvasOnboarding"
          component={CanvasConnectScreen}
          options={{ headerShown: false }}
        />
      )}
      <RootStack.Screen
        name="Tabs"
        component={BottomTabNavigator}
        options={{ headerShown: false }}
      />
      <RootStack.Screen
        name="LoginModalScreen"
        component={LoginModalScreen}
        options={{ presentation: "modal", title: "Login" }}
      />
      <RootStack.Screen
        name="AssignmentDetail"
        component={AssignmentDetailScreen}
        options={{ title: "Assignment Details" }}
      />
      <RootStack.Screen
        name="AddAssignment"
        component={AddAssignmentScreen}
        options={{ presentation: "modal", title: "Add Assignment" }}
      />
      <RootStack.Screen
        name="SubjectManager"
        component={SubjectManagerScreen}
        options={{ presentation: "modal", title: "Manage Subjects" }}
      />
      <RootStack.Screen
        name="CanvasConnect"
        component={CanvasConnectScreen}
        options={{ title: "Canvas Integration" }}
      />
      <RootStack.Screen
        name="AIScheduler"
        component={AISchedulerScreen}
        options={{ title: "AI Schedule Generator" }}
      />
      <RootStack.Screen
        name="StudyTime"
        component={StudyTimeScreen}
        options={{ title: "Study Time" }}
      />
      <RootStack.Screen
        name="ActiveStudySession"
        component={ActiveStudySessionScreen}
        options={{ headerShown: false, gestureEnabled: false }}
      />
    </RootStack.Navigator>
  );
};

/**
 * BottomTabNavigator
 * The bottom tab navigator for the app, containing the 6 main tabs
 */
const BottomTab = createBottomTabNavigator<BottomTabParamList>();
const BottomTabNavigator = () => {
  return (
    <BottomTab.Navigator
      initialRouteName="HomeTab"
      screenOptions={{
        tabBarStyle: {
          position: "absolute",
          backgroundColor: "rgba(255, 255, 255, 0.95)",
          borderTopWidth: 0,
          elevation: 0,
        },
        tabBarBackground: () => (
          <BlurView tint="light" intensity={95} style={StyleSheet.absoluteFill} />
        ),
        tabBarActiveTintColor: "#3A7BFF",
        tabBarInactiveTintColor: "#9CA3AF",
      }}
      screenListeners={() => ({
        tabPress: () => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        },
      })}
    >
      <BottomTab.Screen
        name="HomeTab"
        component={HomeScreen}
        options={{
          title: "Home",
          headerShown: false,
          tabBarIcon: ({ color, size }) => <Home size={size} color={color} />,
        }}
      />
      <BottomTab.Screen
        name="TasksTab"
        component={TasksScreen}
        options={{
          title: "Tasks",
          headerShown: false,
          tabBarIcon: ({ color, size }) => <CheckSquare size={size} color={color} />,
        }}
      />
      <BottomTab.Screen
        name="ScheduleTab"
        component={WeeklyScheduleScreen}
        options={{
          title: "Schedule",
          headerShown: false,
          tabBarIcon: ({ color, size }) => <Calendar size={size} color={color} />,
        }}
      />
      <BottomTab.Screen
        name="CalendarTab"
        component={CalendarScreen}
        options={{
          title: "Calendar",
          headerShown: false,
          tabBarIcon: ({ color, size }) => <CalendarDays size={size} color={color} />,
        }}
      />
      <BottomTab.Screen
        name="StudyTimeTab"
        component={StudyTimeScreen}
        options={{
          title: "Study",
          headerShown: false,
          tabBarIcon: ({ color, size }) => <Shield size={size} color={color} />,
        }}
      />
      <BottomTab.Screen
        name="AISchedulerTab"
        component={AISchedulerScreen}
        options={{
          title: "AI",
          headerShown: false,
          tabBarIcon: ({ color, size }) => <Sparkles size={size} color={color} />,
        }}
      />
      <BottomTab.Screen
        name="GradesTab"
        component={GradesScreen}
        options={{
          title: "Grades",
          headerShown: false,
          tabBarIcon: ({ color, size }) => <Award size={size} color={color} />,
        }}
      />
      <BottomTab.Screen
        name="AnalyticsTab"
        component={AnalyticsScreen}
        options={{
          title: "Analytics",
          headerShown: false,
          tabBarIcon: ({ color, size }) => <BarChart3 size={size} color={color} />,
        }}
      />
      <BottomTab.Screen
        name="SettingsTab"
        component={ProfileScreen}
        options={{
          title: "Settings",
          headerShown: false,
          tabBarIcon: ({ color, size }) => <Settings size={size} color={color} />,
        }}
      />
    </BottomTab.Navigator>
  );
};

export default RootNavigator;
