import type { BottomTabScreenProps as BottomTabScreenPropsBase } from "@react-navigation/bottom-tabs";
import { CompositeScreenProps, NavigatorScreenParams } from "@react-navigation/native";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";

declare global {
  namespace ReactNavigation {
    // eslint-disable-next-line @typescript-eslint/no-empty-object-type
    interface RootParamList extends RootStackParamList {}
  }
}

export type RootStackParamList = {
  Auth: undefined;
  Tabs: NavigatorScreenParams<BottomTabParamList> | undefined;
  LoginModalScreen: undefined;
  AssignmentDetail: { assignmentId: string };
  AddAssignment: { subjectId?: string };
  SubjectManager: undefined;
  CanvasOnboarding: undefined; // First-time Canvas setup
  CanvasConnect: undefined; // Canvas integration settings
  AIScheduler: undefined;
  StudyTime: undefined; // Study time setup screen
  ActiveStudySession: { duration: number; blockedApps: any }; // Active study session with timer
};

export type BottomTabParamList = {
  HomeTab: undefined;
  TasksTab: undefined;
  ScheduleTab: undefined;
  CalendarTab: undefined;
  StudyTimeTab: undefined; // Study Time tab
  AISchedulerTab: undefined;
  GradesTab: undefined; // Grades tab
  AnalyticsTab: undefined; // Analytics tab
  SettingsTab: undefined;
};

export type RootStackScreenProps<T extends keyof RootStackParamList> = NativeStackScreenProps<
  RootStackParamList,
  T
>;

export type BottomTabScreenProps<Screen extends keyof BottomTabParamList> = CompositeScreenProps<
  BottomTabScreenPropsBase<BottomTabParamList, Screen>,
  NativeStackScreenProps<RootStackParamList>
>;
