// API client for making authenticated requests to the backend
import { authClient } from "./authClient";

const BACKEND_URL = process.env.EXPO_PUBLIC_VIBECODE_BACKEND_URL || "http://localhost:3000";

interface ApiError {
  message: string;
  status?: number;
}

class ApiClient {
  private baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseUrl}/api${endpoint}`;

    try {
      console.log(`[API] Making request to: ${url}`);
      const response = await authClient.$fetch(url, {
        ...options,
        method: options.method || "GET",
      });

      console.log(`[API] Response for ${endpoint}:`, JSON.stringify(response, null, 2));

      // Better Auth $fetch returns { data, error } structure
      const betterAuthResponse = response as { data?: any; error?: any };

      // Check if Better Auth returned an error
      if (betterAuthResponse.error) {
        console.log(`[API] Better Auth returned error for ${endpoint}`);
        const errorData = betterAuthResponse.error;
        const apiError: ApiError = {
          message: errorData.message || 'Request failed',
          status: errorData.status || 400,
        };
        throw apiError;
      }

      // If response has data property, return the data
      if (betterAuthResponse.data !== undefined) {
        return betterAuthResponse.data as T;
      }

      // Check if response has a success field and it's false (API returned an error response directly)
      const data = response as any;
      if (data && typeof data === 'object' && 'success' in data && data.success === false) {
        console.log(`[API] Detected success=false in response, throwing error`);
        const apiError: ApiError = {
          message: data.message || 'Request failed',
          status: 400,
        };
        throw apiError;
      }

      return response as T;
    } catch (error: any) {
      // Extract error message from various error formats
      let errorMessage = 'Request failed';
      let status = 500;

      console.log(`[API] Caught error for ${endpoint}:`, JSON.stringify(error, null, 2));

      if (error) {
        // If it has a message property, use it
        if (error.message) {
          errorMessage = error.message;
        }
        // If it has a status property, use it
        if (error.status) {
          status = error.status;
        }
        // If the error itself is a string
        if (typeof error === 'string') {
          errorMessage = error;
        }
        // Check for nested error data (some fetch wrappers nest the response)
        if (error.data && typeof error.data === 'object') {
          if (error.data.message) {
            errorMessage = error.data.message;
          }
          if (error.data.success === false && error.data.message) {
            errorMessage = error.data.message;
          }
        }
        // Check for body property (Better Auth may use this)
        if (error.body && typeof error.body === 'object') {
          if (error.body.message) {
            errorMessage = error.body.message;
          }
          if (error.body.success === false && error.body.message) {
            errorMessage = error.body.message;
          }
        }
        // Check for response property
        if (error.response && typeof error.response === 'object') {
          if (error.response.message) {
            errorMessage = error.response.message;
          }
        }
      }

      const apiError: ApiError = {
        message: errorMessage,
        status,
      };

      // Only log non-401 errors (401 is handled gracefully in the UI)
      if (status !== 401) {
        console.log(`API Error [${endpoint}]:`, apiError.message);
      }

      throw apiError;
    }
  }

  async get<T>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, {
      method: "GET",
    });
  }

  async post<TBody = any, TResponse = any>(
    endpoint: string,
    body: TBody
  ): Promise<TResponse> {
    return this.request<TResponse>(endpoint, {
      method: "POST",
      body: JSON.stringify(body),
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  async patch<TBody = any, TResponse = any>(
    endpoint: string,
    body: TBody
  ): Promise<TResponse> {
    return this.request<TResponse>(endpoint, {
      method: "PATCH",
      body: JSON.stringify(body),
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  async delete<T = any>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, {
      method: "DELETE",
    });
  }
}

export const api = new ApiClient(BACKEND_URL);
