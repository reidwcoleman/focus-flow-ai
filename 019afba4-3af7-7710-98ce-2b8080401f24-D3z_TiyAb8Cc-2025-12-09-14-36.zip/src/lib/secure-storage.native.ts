// Native storage using expo-secure-store
import * as SecureStore from "expo-secure-store";

export const storage = SecureStore;
