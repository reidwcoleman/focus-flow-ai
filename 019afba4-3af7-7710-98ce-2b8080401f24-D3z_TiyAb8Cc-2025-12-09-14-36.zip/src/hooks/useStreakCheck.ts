import { useEffect } from "react";
import { Alert } from "react-native";
import { api } from "@/lib/api";
import type { CheckStreakResponse } from "@/shared/contracts";

let hasCheckedStreak = false; // Prevent multiple checks in same session

// Milestone definitions with emoji and messages
const MILESTONES = [
  { days: 3, emoji: "🔥", title: "3 Day Streak!", message: "You're building momentum! Keep it going!" },
  { days: 7, emoji: "⭐", title: "Week Warrior!", message: "A full week! You're crushing it!" },
  { days: 14, emoji: "💪", title: "Two Week Champion!", message: "Your dedication is inspiring!" },
  { days: 21, emoji: "🏆", title: "3 Week Master!", message: "You've built an amazing habit!" },
  { days: 30, emoji: "🌟", title: "Monthly Legend!", message: "30 days straight! You're unstoppable!" },
  { days: 50, emoji: "🚀", title: "50 Day Superstar!", message: "Half a hundred! Absolutely phenomenal!" },
  { days: 75, emoji: "💎", title: "Diamond Achiever!", message: "75 days of dedication! You're elite!" },
  { days: 100, emoji: "👑", title: "Centurion!", message: "100 DAYS! You're a productivity LEGEND!" },
  { days: 150, emoji: "🎯", title: "Super Centurion!", message: "150 days! Nothing can stop you now!" },
  { days: 200, emoji: "🦸", title: "Superhuman!", message: "200 days! You're an inspiration to everyone!" },
  { days: 365, emoji: "🎊", title: "YEARLY CHAMPION!", message: "A FULL YEAR! You've achieved the impossible! 🎉🎉🎉" },
];

// Get the appropriate milestone for a given streak
function getMilestone(streak: number) {
  // Find the milestone for this exact streak count
  return MILESTONES.find(m => m.days === streak);
}

// Get encouraging message based on streak count
function getEncouragingMessage(streak: number): string {
  if (streak >= 365) return "You're a yearly champion! Legendary dedication! 🎊";
  if (streak >= 200) return `${streak} days! You're superhuman! Keep dominating! 🦸`;
  if (streak >= 100) return `${streak} days! Elite level achieved! 👑`;
  if (streak >= 75) return `${streak} days! Diamond tier productivity! 💎`;
  if (streak >= 50) return `${streak} days! You're on fire! 🔥`;
  if (streak >= 30) return `${streak} days! Unstoppable force! 🌟`;
  if (streak >= 21) return `${streak} days! Habit mastery achieved! 🏆`;
  if (streak >= 14) return `${streak} days! Consistency king/queen! 💪`;
  if (streak >= 7) return `${streak} days! Week by week, you're winning! ⭐`;
  if (streak >= 3) return `${streak} days! Building momentum! 🔥`;
  return `${streak} day${streak === 1 ? '' : 's'}! Keep it up! 🎯`;
}

export function useStreakCheck() {
  useEffect(() => {
    const checkStreak = async () => {
      // Only check once per app session
      if (hasCheckedStreak) {
        return;
      }

      try {
        console.log("[StreakCheck] Checking daily streak...");
        const response = await api.post<{}, CheckStreakResponse>("/streak/check", {});

        hasCheckedStreak = true;

        if (response) {
          console.log("[StreakCheck] Streak checked:", response.message);

          const currentStreak = response.streak.currentStreak;
          const milestone = getMilestone(currentStreak);

          // Show different alerts based on situation
          if (response.isStreakBroken) {
            // Streak was broken - show encouraging restart message
            setTimeout(() => {
              Alert.alert(
                "Welcome Back! 🔄",
                "Your streak was reset, but that's okay! Every expert was once a beginner. Let's start fresh and build an even better streak!",
                [{ text: "Let's Go! 💪" }]
              );
            }, 1500);
          } else if (milestone) {
            // Hit a major milestone - BIG celebration!
            setTimeout(() => {
              Alert.alert(
                `${milestone.emoji} ${milestone.title} ${milestone.emoji}`,
                milestone.message,
                [{ text: "Amazing! 🎉" }]
              );
            }, 1500);
          } else if (currentStreak > 1 && currentStreak % 5 === 0) {
            // Every 5 days (that isn't a major milestone) - mini celebration
            setTimeout(() => {
              Alert.alert(
                `${currentStreak} Day Streak! 🔥`,
                getEncouragingMessage(currentStreak),
                [{ text: "Keep Going! 💪" }]
              );
            }, 1500);
          } else if (response.isNewStreak) {
            // Brand new user or fresh start
            setTimeout(() => {
              Alert.alert(
                "Welcome! 🎉",
                "Your streak journey begins today! Come back tomorrow to keep it going!",
                [{ text: "Let's Do This! 🔥" }]
              );
            }, 1500);
          }
          // For all other days (2, 4, 6, 8, 9, etc.) - silent update, visible on home screen
        }
      } catch (error: any) {
        // Silently fail - streak check shouldn't block the app
        console.log("[StreakCheck] Error checking streak:", error?.message || error);
      }
    };

    checkStreak();
  }, []);
}
