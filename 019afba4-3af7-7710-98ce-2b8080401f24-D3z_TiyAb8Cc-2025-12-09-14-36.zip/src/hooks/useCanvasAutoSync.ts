import { useEffect, useRef } from "react";
import { api } from "@/lib/api";
import type { GetCanvasStatusResponse, SyncCanvasResponse } from "@/shared/contracts";

/**
 * Hook to automatically check Canvas connection status and sync data on app start
 */
export const useCanvasAutoSync = () => {
  const hasChecked = useRef(false);

  useEffect(() => {
    const checkAndSync = async () => {
      // Only check once per app session
      if (hasChecked.current) return;
      hasChecked.current = true;

      try {
        // Check if Canvas is connected
        const status = await api.get<GetCanvasStatusResponse>("/canvas/status");

        if (status.connected && status.syncEnabled) {
          console.log("[Canvas] Connection detected, auto-syncing...");

          // Auto-sync Canvas data
          try {
            const syncResult = await api.post<{}, SyncCanvasResponse>("/canvas/sync", {});
            console.log("[Canvas] Auto-sync complete:", {
              courses: syncResult.coursesImported,
              assignments: syncResult.assignmentsImported,
              grades: syncResult.gradesImported,
              scheduleBlocks: syncResult.scheduleBlocksCreated,
            });
          } catch (syncError) {
            console.log("[Canvas] Auto-sync failed:", syncError);
          }
        }
      } catch (error: any) {
        // Don't log 401 errors (user not authenticated yet)
        if (error?.status !== 401) {
          console.log("[Canvas] Auto-sync check error:", error);
        }
      }
    };

    // Wait a bit for authentication to be ready
    const timer = setTimeout(checkAndSync, 1000);
    return () => clearTimeout(timer);
  }, []);
};
