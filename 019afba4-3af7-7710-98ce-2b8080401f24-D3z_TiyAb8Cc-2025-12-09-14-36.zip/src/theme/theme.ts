/**
 * Modern Dark Navy Theme
 * Minimal & sophisticated design for focused productivity
 */

export const theme = {
  colors: {
    // Backgrounds
    primary: '#0f1729',      // Deep navy blue - main background
    secondary: '#1a2332',    // Lighter navy - cards/surfaces
    border: '#1f2937',       // Subtle gray-navy - borders

    // Text
    textPrimary: '#ffffff',      // Pure white - headings
    textSecondary: '#6b7280',    // Muted gray - labels/metadata

    // Accent
    accent: '#3b82f6',       // Clean blue - interactive elements

    // Priority dots
    priorityUrgent: '#ef4444',   // Red
    priorityHigh: '#f59e0b',     // Orange
    priorityMedium: '#3b82f6',   // Blue
    priorityLow: '#10b981',      // Green

    // Status
    success: '#10b981',
    warning: '#f59e0b',
    error: '#ef4444',

    // Grades
    gradeA: '#10b981',
    gradeB: '#3b82f6',
    gradeC: '#f59e0b',
    gradeD: '#ef4444',
    gradeF: '#ef4444',
  },

  spacing: {
    xs: 4,
    sm: 8,
    md: 12,
    lg: 16,
    xl: 20,
    xxl: 24,
  },

  borderRadius: {
    sm: 8,
    md: 12,
    lg: 14,
  },

  fontSize: {
    xs: 12,
    sm: 13,
    base: 14,
    md: 15,
    lg: 16,
    xl: 20,
    xxl: 24,
    xxxl: 28,
  },

  fontWeight: {
    normal: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
  },

  // Priority indicator size
  priorityDotSize: 6,

  // Border width
  borderWidth: 1,

  // Letter spacing
  letterSpacing: {
    tight: -0.5,
    normal: 0,
    wide: 0.5,
  },
};

export type Theme = typeof theme;
