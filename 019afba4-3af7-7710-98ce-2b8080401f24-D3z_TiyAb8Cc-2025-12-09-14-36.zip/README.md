# FocusTwin AI — Student Productivity App

FocusTwin AI is an AI-powered productivity app that automatically organizes a student's entire school life — homework, tests, grades, schedules, and study time — without requiring manual input.

## Overview

This app provides an intelligent system for students to manage their academic workload through:
- **Auto-organized homework dashboard** with priority sorting
- **AI-generated study planner** that creates optimal study schedules
- **Canvas LMS Integration** - Auto-import assignments, courses, grades, and schedules
- **AI Calendar with Natural Language** - Describe activities and AI creates calendar events
- **AI Weekly Scheduler Tab** - Describe your week in natural language, get a complete schedule
- **Grades Dashboard** - View all your grades and course performance
- **Analytics Dashboard** - Track study habits, grade trends, and productivity insights
- **Screenshot capture** for instantly extracting assignment details (coming soon)
- **Subject-based organization** with color coding
- **Smart study time allocation** based on courses and deadlines

## Design

The app uses a **Modern Dark Navy Design Philosophy**:
- Deep navy blue backgrounds (#0f1729, #1a2332) for professional dark mode
- Minimal color palette with single blue accent (#3b82f6)
- 6px priority dots instead of bulky badges for at-a-glance information
- No gradients, minimal emojis, 1px borders, 12-14px corner radius
- Refined typography with adjusted letter-spacing and reduced font weights
- Information-dense layout optimized for productivity

## Tech Stack

### Frontend
- **Expo SDK 53** + React Native 0.76.7
- **React Navigation 7** for navigation
- **NativeWind (TailwindCSS)** for styling
- **Centralized Theme System** for consistent design tokens
- **TypeScript** with strict mode
- **Lucide Icons** for iconography
- **Better Auth (Expo Client)** for authentication

### Backend (Vibecode Cloud)
- **Bun** + **Hono** server framework
- **Prisma ORM** with SQLite database
- **Better Auth** for authentication
- **RESTful API** with type-safe contracts
- **Grok AI (grok-2-1212)** for AI schedule generation

## API Integrations

### Hugging Face AI
- Powers the AI Activity Generator feature
- Uses `Qwen/Qwen2.5-72B-Instruct` model for natural language activity parsing
- Intelligently creates calendar activities from student descriptions
- Extracts dates, times, and activity types automatically
- Color-codes activities based on type (study, exercise, social, etc.)
- API Key: `process.env.HUGGINGFACE_API_KEY`

### Grok AI (xAI) - Legacy
- Previously powered the AI Weekly Scheduler feature
- Uses `grok-2-1212` model for natural language schedule generation
- API Key: `process.env.EXPO_PUBLIC_VIBECODE_GROK_API_KEY`

## Project Structure

```
/home/user/workspace/
├── src/
│   ├── screens/
│   │   ├── HomeScreen.tsx              # Main dashboard with assignments
│   │   ├── PlannerScreen.tsx           # AI study planner
│   │   ├── CaptureScreen.tsx           # Screenshot capture interface
│   │   ├── ProfileScreen.tsx           # User profile & settings
│   │   ├── CanvasConnectScreen.tsx     # Canvas LMS integration
│   │   ├── AISchedulerScreen.tsx       # Natural language schedule generator
│   │   ├── WeeklyScheduleScreen.tsx    # Weekly schedule view
│   │   ├── AssignmentDetailScreen.tsx
│   │   ├── AddAssignmentScreen.tsx
│   │   └── SubjectManagerScreen.tsx
│   ├── navigation/
│   │   ├── RootNavigator.tsx           # App navigation structure
│   │   └── types.ts                    # Navigation type definitions
│   ├── lib/
│   │   └── api.ts                      # API client for backend calls
│   └── components/
│
├── backend/
│   ├── src/
│   │   ├── index.ts                    # Hono server entry point
│   │   ├── routes/
│   │   │   ├── subjects.ts             # Subject CRUD endpoints
│   │   │   ├── assignments.ts          # Assignment CRUD + AI extraction
│   │   │   ├── study-blocks.ts         # AI study block generation
│   │   │   ├── canvas.ts               # Canvas LMS integration
│   │   │   ├── schedule.ts             # AI schedule generation
│   │   │   ├── courses.ts              # Course management
│   │   │   ├── grades.ts               # Grades endpoints
│   │   │   └── activities.ts           # Calendar activities CRUD + AI generation
│   │   ├── auth.ts                     # Better Auth configuration
│   │   └── db.ts                       # Prisma client singleton
│   └── prisma/
│       ├── schema.prisma               # Database schema
│       └── dev.db                      # SQLite database
│
└── shared/
    └── contracts.ts                 # Shared Zod schemas & types
```

## Database Models

### Subject
- Student's academic subjects (Math, Science, etc.)
- Color-coded for visual organization
- Linked to assignments

### Assignment
- Title, description, due date
- Priority levels: low, medium, high, urgent
- Status: todo, in_progress, completed
- Linked to subject (optional)
- Can be imported from Canvas

### StudyBlock
- AI-generated study sessions or custom time blocks
- Time-blocked schedules
- Can be linked to assignments or standalone
- Types: study, class, break, personal
- Part of weekly schedules

### CanvasIntegration
- Stores Canvas URL and API token
- Syncs assignments, courses, grades, and schedules automatically
- Tracks last sync time

### WeeklySchedule
- AI-generated or manual weekly schedule
- Contains study blocks organized by week
- Can be created from natural language description

### Course
- Student's enrolled courses
- Class meeting times and locations
- Estimated study hours per week
- Current grade and enrollment status
- Can be synced from Canvas

### Grade
- Individual assignment grades
- Score, percentage, and letter grade
- Submission and grading dates
- Linked to courses
- Auto-imported from Canvas

### Activity
- Calendar activities created manually or via AI
- Title, description, date, and optional start/end times
- Color-coded by activity type
- All-day or timed activities
- Completion tracking
- Can be created in bulk using AI Activity Planner

### Streak
- Daily login streak tracking
- Current streak and longest streak
- Total days logged in
- Last login date
- Milestone achievements at 3, 7, 14, 21, 30, 50, 75, 100, 150, 200, 365 days

### StudySession
- Study session tracking with app blocking
- Planned vs actual duration
- Blocked apps (JSON array of app identifiers)
- Break tracking (up to 3 breaks, 5 minutes each)
- Session status (active, completed, cancelled)
- Start and end times
- Total break time used

## Features

### 1. Home Dashboard
- Visual stats (tasks to-do, completed today)
- Priority-sorted assignment list
- **Login Streak Tracker** with daily check-ins
- **Achievement Badges** for streak milestones (3, 7, 14, 21, 30, 50, 75, 100, 150, 200, 365 days)
- Color-coded by subject
- Quick actions (Add Task, Manage Subjects)
- Pull-to-refresh

### 2. Tasks Tab ✨ NEW
- **Organized task view** with assignments grouped by status (To Do, In Progress, Completed)
- **Visual priority indicators** with color-coded badges
- **Due date tracking** with overdue warnings
- **Subject categorization** with color-coded borders
- **Quick task details** - tap any task to view full details
- **Progress tracking** - see count of pending tasks at a glance
- Pull-to-refresh to sync latest assignments

### 3. Study Planner
- AI-generated study blocks based on due dates and priorities
- Smart time distribution algorithm
- Daily schedule view
- Tracks completion

### 4. Canvas Integration ✨ ENHANCED
- **Easy 2-step wizard setup** with clear instructions and visual feedback
- **Auto-URL normalization** - automatically adds https:// prefix for secure connections
- **Real-time URL preview** - see the exact URL that will be used for connection
- **Clear guidance** - helpful tips to avoid common mistakes (like including https:// manually)
- **One-tap access to Canvas settings** - opens directly to token generation page
- **Visual progress indicators** showing connection steps
- Connect to any Canvas LMS instance
- Auto-import assignments with due dates
- **Sync grades from graded assignments**
- **Import course enrollment data with current grades**
- **Auto-create class schedule blocks from Canvas calendar**
- One-click sync button
- Secure token storage with encryption
- Full sync includes: courses, assignments, grades, and class schedule

### 5. AI Calendar ✨ ENHANCED
- **AI Activity Planner** - Describe activities in natural language and AI creates them
- **Smart AI parsing** - Uses Grok AI to extract dates, times, and activity details
- **Automatic calendar population** - Activities are immediately added to your calendar
- **Monthly calendar view** - Visual calendar with day selection
- **Real-time activity loading** - Activities load from backend and sync across sessions
- **Activity management** - Edit, delete, and organize activities
- **Color-coded activities** - Different colors for different activity types (study, exercise, social, etc.)
- **Pull-to-refresh** - Refresh to see latest activities
- Easy day navigation with activity lists
- Works seamlessly with AI Scheduler tab for bulk activity creation

### 6. Grades Dashboard ✨ IMPROVED
- **Grouped by course** with prominent course headers
- **Course averages** displayed with large letter grades
- **Color-coded letter grades** (A=green, B=blue, C=yellow, D/F=red)
- **Individual assignment grades** with scores and percentages
- **Course information** including course codes
- **Grading dates** for each assignment
- **Clean card-based design** with improved readability
- Pull-to-refresh to sync latest grades

### 7. AI Activity Planner (AI Scheduler Tab) ✨ POWERED BY HUGGING FACE
- **Bulk activity creation** - Describe multiple activities at once in natural language
- **AI-powered activity generation** - Uses Hugging Face Qwen2.5-72B-Instruct model to parse your description
- **Advanced language understanding** - Leverages state-of-the-art open-source AI for better accuracy
- **Smart date and time extraction** - Automatically extracts dates and times from your description
- **Intelligent activity creation** based on:
  - Specific dates and times you mention
  - Activity types (appointments, study sessions, meetings, social events)
  - Recurring patterns (e.g., "gym every Monday, Wednesday, Friday")
  - Automatic scheduling if no date is mentioned (spreads over next 7 days)
- **Color coding by activity type**:
  - Study/Work: Blue (#3A7BFF)
  - Exercise/Sports: Green (#10B981)
  - Social/Fun: Orange (#F59E0B)
  - Class/Meeting: Purple (#8B5CF6)
  - Break/Rest: Red (#EF4444)
- **Real-time feedback** - Loading states and success confirmation
- **Direct calendar navigation** - Takes you straight to calendar to view created activities
- **Example templates** - Try example button to see how it works
- **Fallback mode** - Creates basic activity if AI is unavailable
- **Authentication-aware** - Properly handles user sessions with Better Auth
- **Open-source AI** - Powered by Hugging Face's inference API

### 8. Weekly Schedule View ✨ IMPROVED
- **Calendar-style weekly view** grouped by day
- **Color-coded time blocks** by type (study, class, break, personal)
- **Smart day labels** - Shows "Today" and "Tomorrow" for quick reference
- **Time block details** with duration and descriptions
- **Visual icons** for different block types
- **Block counts** per day for quick overview
- **Sorted chronologically** for easy navigation
- AI-generated or manual schedules
- Pull-to-refresh
- Easy navigation through weeks

### 9. Capture (Coming Soon)
- Take photos of whiteboards, syllabi, or assignments
- AI vision extracts assignment details automatically
- No manual typing required

### 10. Study Time ✨ NEW - Focus Mode with App Blocking
- **Real App Blocking** - Uses Apple's Screen Time API (Family Controls) to actually block apps (iOS 16+ only)
- **Custom Session Duration** - Choose from 15 minutes to 4 hours
- **App Selection** - Pick exactly which apps to block during study time
- **Break Management** - Take up to 3 breaks (5 minutes each) during your session
- **Full-Screen Timer** - Large, beautiful timer shows time remaining
- **Session Tracking** - All study sessions saved with statistics
- **Smart Break System** - Apps temporarily unblock during breaks, then auto-reblock
- **Study Statistics** - View total study time, session count, and weekly hours
- **Motivational Design** - Achievement-focused UI keeps you motivated
- Works on honor system on Android (no native app blocking available)

### 11. Subject Management
- Create custom subjects with color coding
- Assign subjects to tasks
- Delete subjects (assignments remain intact)

### 12. Settings
- User authentication with Better Auth
- Canvas integration setup and management
- App settings and preferences
- Version information

### 13. Analytics Dashboard ✨ NEW - Performance Insights
- **Weekly Study Report** - Compare this week vs last week with percentage change
- **Grade Trend Analysis** - See if you're improving, stable, or slipping in each course
- **Productivity Patterns** - "You're 40% more productive studying in the morning"
- **Time of Day Breakdown** - Visual breakdown of study time by morning/afternoon/evening
- **Subject Balance** - Grade weight distribution across all courses
- **Course-Level Insights** - Individual course trends with detailed statistics
- **Achievement Badges** - Earn badges for study milestones without being overly gamified
- **Overall Statistics** - Total study hours, session count, average session length
- **Smart Recommendations** - Personalized insights based on your patterns
- **Beautiful Visualizations** - Progress bars, trend indicators, and color-coded performance

## API Endpoints

All API endpoints require authentication via Better Auth. The API client (`src/lib/api.ts`) automatically handles session management using Better Auth's `authClient.$fetch()`.

### Authentication
- Better Auth handles all authentication flows
- Session tokens are automatically included in API requests
- Frontend uses `authClient.$fetch()` for authenticated requests
- Backend middleware extracts session from request headers

### Subjects
- `GET /api/subjects` - List all subjects
- `POST /api/subjects` - Create new subject
- `DELETE /api/subjects/:id` - Delete subject

### Assignments
- `GET /api/assignments` - List all assignments (sorted by due date)
- `POST /api/assignments` - Create new assignment
- `PATCH /api/assignments/:id` - Update assignment
- `DELETE /api/assignments/:id` - Delete assignment
- `POST /api/assignments/extract-from-screenshot` - AI extraction (coming soon)

### Study Blocks
- `GET /api/study-blocks` - List study blocks
- `POST /api/study-blocks/generate` - Generate AI study plan

### Canvas Integration
- `POST /api/canvas/connect` - Connect Canvas account
- `GET /api/canvas/status` - Get connection status
- `POST /api/canvas/sync` - Sync assignments, courses, grades, and schedules
- `DELETE /api/canvas/disconnect` - Disconnect Canvas

### Courses
- `GET /api/courses` - List all courses with grades

### Grades
- `GET /api/grades` - Get all grades for user
- `GET /api/grades/course/:courseId` - Get grades for specific course

### Activities
- `GET /api/activities` - List all activities for authenticated user
- `GET /api/activities/month/:year/:month` - Get activities for a specific month
- `POST /api/activities` - Create new activity
- `PATCH /api/activities/:id` - Update activity
- `DELETE /api/activities/:id` - Delete activity
- `POST /api/activities/generate-from-description` - AI-powered bulk activity generation from natural language

### Weekly Schedules
- `POST /api/schedule/generate-from-description` - AI schedule from natural language
- `GET /api/schedule/current` - Get current week's schedule

### Streak
- `GET /api/streak` - Get user's streak information
- `POST /api/streak/check` - Check in for daily streak

### Study Sessions
- `GET /api/study-sessions` - List all study sessions
- `GET /api/study-sessions/active` - Get current active session
- `GET /api/study-sessions/stats` - Get study statistics
- `POST /api/study-sessions` - Create new study session
- `PATCH /api/study-sessions/:id` - Update session (breaks, etc.)
- `POST /api/study-sessions/:id/end` - End session (mark complete)
- `POST /api/study-sessions/:id/cancel` - Cancel session early

### Analytics
- `GET /api/analytics` - Get comprehensive analytics dashboard data
- `GET /api/analytics/course/:courseId/trends` - Get detailed grade trends for specific course

## Design System

### Colors
- **Primary Blue**: `#3A7BFF` (electric blue for actions)
- **Midnight Black**: `#0B0D12` (depth and premium feel)
- **Soft Gray**: `#DCE1E9` (cards and subtle elements)

### Priority Colors
- **Urgent**: Red (`#EF4444`)
- **High**: Orange (`#F59E0B`)
- **Medium**: Blue (`#3A7BFF`)
- **Low**: Green (`#10B981`)

### UI Principles
- Clean, iOS-native feel
- Smooth haptic feedback on interactions
- Gesture-friendly design
- Blur effects for depth
- Rounded corners (12-16px)
- Card-based layouts

## Development

### Running Locally
Both frontend and backend servers run automatically in the Vibecode environment:
- Frontend: Expo dev server on port 8081
- Backend: Hono server on port 3000
- Database: SQLite at `backend/prisma/dev.db`

### Type Safety
All API requests/responses are type-checked via shared Zod contracts in `shared/contracts.ts`. The frontend and backend share these types for compile-time safety.

### Database Migrations
```bash
cd backend
bunx prisma migrate dev --name <migration-name>
bunx prisma generate
```

## Recent Updates

### Latest Improvements (Current)
1. **Hugging Face AI Integration** ✨ NEW - AI Activity Generator now powered by Hugging Face
   - Migrated from Grok AI to Hugging Face's Qwen2.5-72B-Instruct model
   - Better natural language understanding for activity parsing
   - Improved date/time extraction and activity categorization
   - Open-source AI with reliable inference API
   - Automatic fallback mode for robust activity creation
1. **Analytics Dashboard** - NEW comprehensive performance insights replacing the Grades tab
   - Weekly study report comparing this week vs last week with percentage changes
   - Grade trend analysis showing if you're improving, stable, or slipping per course
   - Productivity patterns revealing your most productive times (morning/afternoon/evening)
   - Time of day breakdown with visual progress bars
   - Subject balance showing grade weight distribution across courses
   - Achievement badges for reaching study milestones
   - Course-level insights with detailed statistics and recommendations
   - Beautiful visualizations with trend indicators and color-coded performance
2. **Study Time Feature** - Dedicated tab for focused study sessions with real app blocking
   - Uses Apple's Screen Time API (Family Controls) to block distracting apps during study
   - Custom session durations from 15 minutes to 4 hours
   - Break management system (3 breaks, 5 minutes each)
   - Full-screen timer with beautiful UI
   - Session tracking and statistics
   - Works on iOS 16+ with actual app blocking (honor system on Android)
3. **Enhanced Authentication Flow** - Login and sign up with Better Auth, Canvas onboarding (skippable)
4. **Weekly Calendar View** - Changed from monthly to weekly view with activity indicators on dates
5. **Activity Editing** - Full edit capabilities for calendar activities with time selection
6. **Login Streak System** - Daily check-in tracking with milestone celebrations
7. **Achievement Badges** - 11 major milestones with unique badges and titles

### Previous Updates
1. **AI Activity Planner Integration** - AI Scheduler tab creates actual calendar activities
2. **Enhanced Calendar Screen** - Real-time sync with database-backed activities
3. **New Tasks Tab** - Dedicated tab with assignments organized by status
4. **Improved Schedule View** - Better day formatting and visual organization
5. **Improved Grades Display** - Cleaner card-based layout with course averages
6. **9-Tab Navigation** - Home, Tasks, Schedule, Calendar, Study, AI, Grades, Analytics, Settings

### Bug Fixes (Latest)
1. **Fixed Analytics 500 Error** - Added defensive checks for division by zero in productivity calculations and better error handling
2. **Fixed Screen Time Blocker Error** - Added proper availability checks before calling Screen Time API methods to prevent crashes in simulator and on non-iOS devices
3. **Fixed Navigation Errors** - Resolved "AddAssignment" and "AIScheduler" navigation issues by properly structuring the navigation stack
4. **Fixed Canvas Connection Validation** - The app now properly validates Canvas connection and shows "Connection Failed" error when credentials are invalid, instead of falsely showing success
2. **Improved API Error Handling** - API client now properly detects and throws errors when server returns `success: false`, ensuring failed operations don't appear successful
3. **Enhanced Canvas Sync** - Improved Canvas sync to properly import all courses, assignments, grades, and calendar events with detailed logging
4. **Added "Update Connection" Button** - You can now refresh your Canvas access token without disconnecting and reconnecting
5. **Improved Canvas Assignment Import** - Assignments now show correct priority based on due date and status based on submission state
6. **Enhanced Canvas Logging** - Added comprehensive logging for every step of Canvas sync (courses, assignments, grades) to help debug issues
7. **Fixed Canvas Auto-Sync** - Canvas now automatically syncs your data when you login, and immediately after connecting your Canvas account
8. **Fixed Canvas Connection Persistence** - Canvas connection is now properly saved and persists across app sessions
9. **Added Canvas Auto-Sync on App Start** - Added automatic Canvas sync when the app starts if Canvas is connected
10. **Fixed SubjectManagerScreen Crash** - Fixed "Cannot read property 'length' of undefined" error by adding null safety checks and ensuring database tables are properly initialized
11. **Fixed Database Tables** - Created missing database tables (subjects, assignments, study_blocks, etc.) that were causing 500 errors
12. **Fixed API Authentication** - Resolved 401 errors by properly using Better Auth's `authClient.$fetch()` for API requests instead of manual Bearer token authentication
13. **Fixed HomeScreen Crash** - Added null safety checks for assignments array to prevent "Cannot read property 'filter' of undefined" error
14. **Migrated to Grok AI** - Switched from OpenAI to Grok AI (grok-2-1212) for schedule generation with proper API integration

### Technical Improvements
- **Hugging Face AI Integration** - Activities now generated using Qwen2.5-72B-Instruct via Hugging Face Inference API
- **Enhanced AI prompting** - Improved system prompts for better JSON output and activity parsing
- **Robust fallback handling** - Creates basic activity if AI service is unavailable or fails to parse
- **Enhanced Canvas sync with detailed logging** - Every step of Canvas sync is logged (courses found, assignments processed, grades imported)
- **Improved Canvas API calls** - Added pagination support (per_page=100) and better parameter formatting
- **Smart assignment filtering** - Only imports assignments due within 30 days to avoid clutter
- **Priority-based assignment import** - Assignments get priority levels (high/medium/low) based on due date
- **Status-aware assignment import** - Completed assignments are marked as such based on Canvas submission state
- **Update Connection feature** - Users can refresh their Canvas token without disconnecting
- **Canvas auto-sync on app start** - New `useCanvasAutoSync` hook checks for Canvas connection and syncs data automatically
- **Canvas connection persists across sessions** - Connection is properly saved in database and retrieved on app restart
- **Immediate sync after connection** - Canvas data is automatically synced right after connecting your account
- API client now properly handles Better Auth session management
- All error handling uses `console.log` for expected errors (like 401) to avoid triggering error overlays
- Improved null safety across the app with optional chaining
- Better fallback handling when API responses are malformed
- Canvas connection now shows real-time URL preview with automatic https:// prefix
- Added helpful tips to prevent common Canvas connection mistakes

## Future Roadmap

### Phase 2 Features (Partially Complete!)
- ✅ Canvas integration - DONE
- ✅ Grade tracking - DONE
- ✅ Full schedule import - DONE
- Google Classroom integration
- Email and text parsing for assignments
- Advanced AI tutor with study guides
- Grade predictions and analytics
- Parent/teacher dashboards
- Test countdown and study reminders
- After-school time optimization
- Sleep-optimized scheduling

## Version History

### v3.1.0 (Current) - AI Scheduler Tab & Fully Functional AI
- **NEW:** AI Scheduler now has its own dedicated tab in bottom navigation
- **ENHANCED:** AI Scheduler is now fully functional with OpenAI GPT-4o-mini integration
- **NEW:** Smart AI prompting that considers your courses and upcoming assignments
- **NEW:** Example template button to help users get started quickly
- **NEW:** Improved loading states with real-time feedback
- **NEW:** Success confirmation with schedule preview
- **NEW:** Intelligent fallback schedule generator when AI is unavailable
- **IMPROVED:** Better error handling and user messaging
- **MAJOR:** Redesigned app with 6-tab bottom navigation structure
  - Home: Assignments and tasks dashboard
  - Schedule: Weekly AI-generated study schedule
  - Calendar: AI calendar with activity management
  - AI: AI Schedule Generator with natural language input
  - Grades: Course grades and analytics
  - Settings: Canvas integration and app settings
- AI scheduler moved from Settings to dedicated tab for easier access
- All features now easily accessible from dedicated tabs

### v3.0.0 - Tab-Based Navigation & AI Calendar
- **NEW:** AI-powered Calendar with natural language activity creation
- **MAJOR:** Redesigned app with 5-tab bottom navigation structure
- AI assistant parses natural language to create calendar activities
- Activity review and editing before adding to calendar
- Monthly calendar view with day selection
- Activity management (edit, delete, organize)
- Improved tab navigation with better UX

### v2.2.1 - Authentication & Canvas Fixes
- **FIXED:** Authentication issue causing "sign in required" errors on all features
- **FIXED:** Canvas connection 401 errors
- API client now uses Better Auth's `$fetch` for automatic session management
- Added keyboard "Enter" button support for Canvas URL and token fields
- Enhanced paste functionality for Canvas access tokens
- Improved error logging for Canvas connection and authentication
- Better debugging output for failed authentication attempts

### v2.2.0 - Simplified Canvas Connection
- Redesigned Canvas connection with 2-step wizard interface
- Added step-by-step progress indicators
- Auto-normalizes Canvas URLs (users don't need to type https://)
- Direct link to Canvas settings page for easy token generation
- Enhanced visual feedback and instructions
- Improved error messaging
- Better mobile-optimized layout

### v2.1.0 - Grade Tracking & Enhanced Canvas Integration
- Added comprehensive grade tracking system
- Enhanced Canvas sync to import grades, course enrollment, and class schedules
- Created beautiful Grades dashboard with course averages
- Auto-import class schedule blocks from Canvas calendar
- Added grade analytics with color-coded performance indicators
- Updated Canvas sync to show detailed import statistics

### v2.0.0 - Canvas & AI Scheduler
- Canvas LMS integration
- AI Weekly Scheduler with natural language input
- Weekly schedule view
- Course management

### v1.0.0 - MVP Launch
- Basic assignment management
- Study planner
- Subject organization
- Better Auth authentication

---

Built with Vibecode - The AI app builder for non-technical founders.
