import { Hono } from "hono";
import { z } from "zod";
import { zValidator } from "@hono/zod-validator";
import type { AppType } from "./types";
import { db } from "../db";

const streakRouter = new Hono<AppType>();

/**
 * GET /api/streak
 * Get current user's streak info
 */
streakRouter.get("/", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  try {
    console.log("[Streak] Fetching streak for user:", user.id);

    // Get or create streak
    let streak = await db.streak.findUnique({
      where: { userId: user.id },
    });

    if (!streak) {
      console.log("[Streak] Creating new streak for user");
      streak = await db.streak.create({
        data: {
          userId: user.id,
          currentStreak: 0,
          longestStreak: 0,
          totalDays: 0,
        },
      });
    }

    return c.json({ streak });
  } catch (error) {
    console.error("[Streak] Error fetching streak:", error);
    return c.json({ message: "Failed to fetch streak" }, 500);
  }
});

/**
 * POST /api/streak/check
 * Check and update streak for today
 * This should be called when the user opens the app
 */
streakRouter.post("/check", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  try {
    console.log("[Streak] Checking streak for user:", user.id);

    // Get or create streak
    let streak = await db.streak.findUnique({
      where: { userId: user.id },
    });

    if (!streak) {
      console.log("[Streak] Creating initial streak");
      streak = await db.streak.create({
        data: {
          userId: user.id,
          currentStreak: 1,
          longestStreak: 1,
          totalDays: 1,
          lastLoginDate: new Date(),
        },
      });

      return c.json({
        streak,
        isNewStreak: true,
        message: "Welcome! Your streak has started! 🔥"
      });
    }

    // Get today's date at midnight (local time)
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Get last login date at midnight
    const lastLogin = streak.lastLoginDate ? new Date(streak.lastLoginDate) : null;
    if (lastLogin) {
      lastLogin.setHours(0, 0, 0, 0);
    }

    // Check if user already logged in today
    if (lastLogin && lastLogin.getTime() === today.getTime()) {
      console.log("[Streak] User already logged in today");
      return c.json({
        streak,
        alreadyLoggedToday: true,
        message: "You've already logged in today! Keep it up! 💪"
      });
    }

    // Check if this is a consecutive day
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    let newCurrentStreak: number;
    let isStreakBroken = false;

    if (lastLogin && lastLogin.getTime() === yesterday.getTime()) {
      // Consecutive day - increment streak
      newCurrentStreak = streak.currentStreak + 1;
      console.log("[Streak] Consecutive day! Streak:", newCurrentStreak);
    } else if (!lastLogin || lastLogin.getTime() < yesterday.getTime()) {
      // Streak broken - restart at 1
      newCurrentStreak = 1;
      isStreakBroken = lastLogin !== null; // Only broken if they had a previous login
      console.log("[Streak] Streak broken, restarting");
    } else {
      // This shouldn't happen, but just in case
      newCurrentStreak = streak.currentStreak;
    }

    // Update longest streak if current is higher
    const newLongestStreak = Math.max(newCurrentStreak, streak.longestStreak);

    // Update streak in database
    const updatedStreak = await db.streak.update({
      where: { userId: user.id },
      data: {
        currentStreak: newCurrentStreak,
        longestStreak: newLongestStreak,
        totalDays: streak.totalDays + 1,
        lastLoginDate: today,
      },
    });

    let message: string;
    if (isStreakBroken) {
      message = "Your streak was broken, but you're back! Let's start fresh! 🔄";
    } else if (newCurrentStreak === 1) {
      message = "Great to have you back! Your streak has started! 🔥";
    } else if (newCurrentStreak >= 30) {
      message = `Amazing! ${newCurrentStreak} day streak! You're unstoppable! 🌟`;
    } else if (newCurrentStreak >= 7) {
      message = `Fantastic! ${newCurrentStreak} day streak! Keep going! 🚀`;
    } else {
      message = `Great! ${newCurrentStreak} day streak! 🔥`;
    }

    return c.json({
      streak: updatedStreak,
      isNewStreak: newCurrentStreak === 1,
      isStreakBroken,
      message
    });
  } catch (error) {
    console.error("[Streak] Error checking streak:", error);
    return c.json({ message: "Failed to check streak" }, 500);
  }
});

export { streakRouter };
