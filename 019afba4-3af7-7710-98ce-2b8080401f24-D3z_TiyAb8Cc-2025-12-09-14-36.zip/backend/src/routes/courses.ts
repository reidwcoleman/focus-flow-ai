import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import {
  createCourseRequestSchema,
  type GetCoursesResponse,
} from "@/shared/contracts";
import { type AppType } from "../types";
import { db } from "../db";

const coursesRouter = new Hono<AppType>();

// ============================================
// GET /api/courses - Get all courses for user
// ============================================
coursesRouter.get("/", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const courses = await db.course.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "asc" },
  });

  return c.json({
    courses: courses.map((course) => ({
      ...course,
      createdAt: course.createdAt.toISOString(),
    })),
  } satisfies GetCoursesResponse);
});

// ============================================
// POST /api/courses - Create a new course
// ============================================
coursesRouter.post("/", zValidator("json", createCourseRequestSchema), async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const data = c.req.valid("json");

  const course = await db.course.create({
    data: {
      userId: user.id,
      name: data.name,
      courseCode: data.courseCode,
      instructor: data.instructor,
      credits: data.credits,
      color: data.color,
      meetingDays: data.meetingDays ? JSON.stringify(data.meetingDays) : null,
      meetingStartTime: data.meetingStartTime,
      meetingEndTime: data.meetingEndTime,
      location: data.location,
      estimatedStudyHoursPerWeek: data.estimatedStudyHoursPerWeek,
    },
  });

  return c.json(course);
});

export { coursesRouter };
