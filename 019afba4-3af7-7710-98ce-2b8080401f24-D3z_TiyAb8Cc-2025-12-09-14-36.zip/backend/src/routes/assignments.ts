import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import {
  type GetAssignmentsResponse,
  createAssignmentRequestSchema,
  type CreateAssignmentResponse,
  updateAssignmentRequestSchema,
  type UpdateAssignmentResponse,
  type DeleteAssignmentResponse,
  extractFromScreenshotRequestSchema,
  type ExtractFromScreenshotResponse,
} from "@/shared/contracts";
import { type AppType } from "../types";
import { db } from "../db";

const assignmentsRouter = new Hono<AppType>();

// ============================================
// GET /api/assignments - Get all assignments for user
// ============================================
assignmentsRouter.get("/", async (c) => {
  const user = c.get("user");

  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const assignments = await db.assignment.findMany({
    where: { userId: user.id },
    include: {
      subject: {
        select: {
          id: true,
          name: true,
          color: true,
          icon: true,
        },
      },
    },
    orderBy: { dueDate: "asc" },
  });

  return c.json({
    assignments: assignments.map((a) => ({
      ...a,
      dueDate: a.dueDate.toISOString(),
      priority: a.priority as "low" | "medium" | "high" | "urgent",
      status: a.status as "todo" | "in_progress" | "completed",
      createdAt: a.createdAt.toISOString(),
      updatedAt: a.updatedAt.toISOString(),
      completedAt: a.completedAt?.toISOString() ?? null,
    })),
  } satisfies GetAssignmentsResponse);
});

// ============================================
// POST /api/assignments - Create a new assignment
// ============================================
assignmentsRouter.post("/", zValidator("json", createAssignmentRequestSchema), async (c) => {
  const user = c.get("user");

  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const data = c.req.valid("json");

  const assignment = await db.assignment.create({
    data: {
      title: data.title,
      description: data.description,
      dueDate: new Date(data.dueDate),
      priority: data.priority ?? "medium",
      subjectId: data.subjectId,
      userId: user.id,
    },
  });

  return c.json({
    id: assignment.id,
    title: assignment.title,
    description: assignment.description,
    dueDate: assignment.dueDate.toISOString(),
    priority: assignment.priority,
    status: assignment.status,
    subjectId: assignment.subjectId,
    createdAt: assignment.createdAt.toISOString(),
    updatedAt: assignment.updatedAt.toISOString(),
  } satisfies CreateAssignmentResponse);
});

// ============================================
// PATCH /api/assignments/:id - Update an assignment
// ============================================
assignmentsRouter.patch("/:id", zValidator("json", updateAssignmentRequestSchema), async (c) => {
  const user = c.get("user");

  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const id = c.req.param("id");
  const data = c.req.valid("json");

  const existing = await db.assignment.findFirst({
    where: { id, userId: user.id },
  });

  if (!existing) {
    return c.json({ message: "Assignment not found" }, 404);
  }

  const updateData: Record<string, any> = {};
  if (data.title !== undefined) updateData.title = data.title;
  if (data.description !== undefined) updateData.description = data.description;
  if (data.dueDate !== undefined) updateData.dueDate = new Date(data.dueDate);
  if (data.priority !== undefined) updateData.priority = data.priority;
  if (data.status !== undefined) {
    updateData.status = data.status;
    if (data.status === "completed") {
      updateData.completedAt = new Date();
    } else if (existing.status === "completed") {
      updateData.completedAt = null;
    }
  }
  if (data.subjectId !== undefined) updateData.subjectId = data.subjectId;

  const assignment = await db.assignment.update({
    where: { id },
    data: updateData,
  });

  return c.json({
    id: assignment.id,
    title: assignment.title,
    description: assignment.description,
    dueDate: assignment.dueDate.toISOString(),
    priority: assignment.priority,
    status: assignment.status,
    subjectId: assignment.subjectId,
    createdAt: assignment.createdAt.toISOString(),
    updatedAt: assignment.updatedAt.toISOString(),
    completedAt: assignment.completedAt?.toISOString() ?? null,
  } satisfies UpdateAssignmentResponse);
});

// ============================================
// DELETE /api/assignments/:id - Delete an assignment
// ============================================
assignmentsRouter.delete("/:id", async (c) => {
  const user = c.get("user");

  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const id = c.req.param("id");

  const assignment = await db.assignment.findFirst({
    where: { id, userId: user.id },
  });

  if (!assignment) {
    return c.json({ message: "Assignment not found" }, 404);
  }

  await db.assignment.delete({
    where: { id },
  });

  return c.json({ success: true } satisfies DeleteAssignmentResponse);
});

// ============================================
// POST /api/assignments/extract-from-screenshot - AI extraction
// ============================================
assignmentsRouter.post(
  "/extract-from-screenshot",
  zValidator("json", extractFromScreenshotRequestSchema),
  async (c) => {
    const user = c.get("user");

    if (!user) {
      return c.json({ message: "Unauthorized" }, 401);
    }

    const { imageUrl } = c.req.valid("json");

    // TODO: Implement AI vision extraction
    // For now, return a mock response
    console.log("🔍 [AI] Extracting assignments from screenshot...");

    return c.json({
      assignments: [
        {
          title: "Example extracted assignment",
          description: "This would be extracted from the screenshot using AI",
          dueDate: new Date().toISOString(),
          subject: "Math",
        },
      ],
    } satisfies ExtractFromScreenshotResponse);
  }
);

export { assignmentsRouter };
