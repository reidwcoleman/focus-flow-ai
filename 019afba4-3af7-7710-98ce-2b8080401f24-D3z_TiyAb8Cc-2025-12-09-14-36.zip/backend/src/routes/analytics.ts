import { Hono } from "hono";
import { db } from "../db";
import type { AppType } from "../types";

const analyticsRouter = new Hono<AppType>();

// Get comprehensive analytics for the user
analyticsRouter.get("/", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  try {
    // Get all study sessions
    const studySessions = await db.studySession.findMany({
      where: {
        userId: user.id,
        status: "completed",
      },
      orderBy: { startTime: "desc" },
    });

    // Get all grades with courses
    const grades = await db.grade.findMany({
      where: { userId: user.id },
      include: { course: true },
      orderBy: { gradedAt: "desc" },
    });

    // Calculate weekly study time (current week vs last week)
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay()); // Sunday
    startOfWeek.setHours(0, 0, 0, 0);

    const startOfLastWeek = new Date(startOfWeek);
    startOfLastWeek.setDate(startOfLastWeek.getDate() - 7);

    const thisWeekSessions = studySessions.filter((s) => s.startTime >= startOfWeek);
    const lastWeekSessions = studySessions.filter(
      (s) => s.startTime >= startOfLastWeek && s.startTime < startOfWeek
    );

    const thisWeekMinutes = thisWeekSessions.reduce((sum, s) => sum + (s.actualDuration || 0), 0);
    const lastWeekMinutes = lastWeekSessions.reduce((sum, s) => sum + (s.actualDuration || 0), 0);

    // Calculate most productive day of week and time of day
    const sessionsByDay = studySessions.reduce((acc, session) => {
      const dayOfWeek = session.startTime.getDay();
      acc[dayOfWeek] = (acc[dayOfWeek] || 0) + (session.actualDuration || 0);
      return acc;
    }, {} as Record<number, number>);

    const sessionsByHour = studySessions.reduce((acc, session) => {
      const hour = session.startTime.getHours();
      const timeOfDay = hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening";
      acc[timeOfDay] = (acc[timeOfDay] || 0) + (session.actualDuration || 0);
      return acc;
    }, {} as Record<string, number>);

    const mostProductiveDay = Object.entries(sessionsByDay).reduce(
      (max, [day, minutes]) => (minutes > max.minutes ? { day: parseInt(day), minutes } : max),
      { day: 0, minutes: 0 }
    );

    const mostProductiveTime = Object.entries(sessionsByHour).reduce(
      (max, [time, minutes]) => (minutes > max.minutes ? { time, minutes } : max),
      { time: "morning", minutes: 0 }
    );

    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

    // Calculate productivity increase
    const morningMinutes = sessionsByHour["morning"] || 0;
    const afternoonMinutes = sessionsByHour["afternoon"] || 0;
    const eveningMinutes = sessionsByHour["evening"] || 0;
    const totalMinutes = morningMinutes + afternoonMinutes + eveningMinutes;

    let productivityInsight = "";
    if (totalMinutes > 0) {
      const morningPercent = Math.round((morningMinutes / totalMinutes) * 100);
      const afternoonPercent = Math.round((afternoonMinutes / totalMinutes) * 100);
      const eveningPercent = Math.round((eveningMinutes / totalMinutes) * 100);

      if (morningPercent > afternoonPercent && morningPercent > eveningPercent) {
        const diff = afternoonMinutes > 0 ? Math.round(((morningMinutes - afternoonMinutes) / afternoonMinutes) * 100) : 100;
        productivityInsight = `You're ${diff > 0 ? diff : "more"}% more productive studying in the morning`;
      } else if (afternoonPercent > morningPercent && afternoonPercent > eveningPercent) {
        const diff = morningMinutes > 0 ? Math.round(((afternoonMinutes - morningMinutes) / morningMinutes) * 100) : 100;
        productivityInsight = `You're ${diff > 0 ? diff : "more"}% more productive studying in the afternoon`;
      } else {
        const diff = morningMinutes > 0 ? Math.round(((eveningMinutes - morningMinutes) / morningMinutes) * 100) : 100;
        productivityInsight = `You're ${diff > 0 ? diff : "more"}% more productive studying in the evening`;
      }
    }

    // Calculate study time per course
    const courses = await db.course.findMany({
      where: { userId: user.id },
      include: { grades: true },
    });

    const courseAnalytics = courses.map((course) => {
      // Calculate average grade
      const courseGrades = course.grades.filter((g) => g.percentage !== null);
      const avgGrade =
        courseGrades.length > 0
          ? courseGrades.reduce((sum, g) => sum + (g.percentage || 0), 0) / courseGrades.length
          : null;

      // Calculate grade trend (comparing first half vs second half of grades)
      let trend: "improving" | "stable" | "slipping" | null = null;
      if (courseGrades.length >= 4) {
        const midpoint = Math.floor(courseGrades.length / 2);
        const firstHalf = courseGrades.slice(0, midpoint);
        const secondHalf = courseGrades.slice(midpoint);

        const firstAvg =
          firstHalf.reduce((sum, g) => sum + (g.percentage || 0), 0) / firstHalf.length;
        const secondAvg =
          secondHalf.reduce((sum, g) => sum + (g.percentage || 0), 0) / secondHalf.length;

        const diff = secondAvg - firstAvg;
        if (diff > 3) {
          trend = "improving";
        } else if (diff < -3) {
          trend = "slipping";
        } else {
          trend = "stable";
        }
      }

      return {
        courseId: course.id,
        courseName: course.name,
        courseCode: course.courseCode,
        currentGrade: course.currentGrade,
        currentScore: course.currentScore,
        averageGrade: avgGrade,
        gradeCount: courseGrades.length,
        trend,
        credits: course.credits,
      };
    });

    // Calculate subject balance (study time vs grade weight)
    const totalCredits = courses.reduce((sum, c) => sum + (c.credits || 3), 0);
    const subjectBalance = courseAnalytics.map((course) => {
      const courseWeight = ((course.credits || 3) / totalCredits) * 100;
      // In a real app, we'd track study time per course
      // For now, we'll use a placeholder
      return {
        courseName: course.courseName,
        courseCode: course.courseCode,
        gradeWeight: Math.round(courseWeight),
        currentGrade: course.currentGrade,
        trend: course.trend,
      };
    });

    // Generate weekly report message
    const weeklyReportMessage =
      lastWeekMinutes > 0
        ? `You spent ${Math.round(thisWeekMinutes / 60)} hours studying this week, ${thisWeekMinutes > lastWeekMinutes ? "up from" : "down from"} ${Math.round(lastWeekMinutes / 60)} last week. Most productive time: ${mostProductiveDay.minutes > 0 ? dayNames[mostProductiveDay.day] : "N/A"} ${mostProductiveTime.minutes > 0 ? mostProductiveTime.time + "s" : ""}`
        : thisWeekMinutes > 0
        ? `You spent ${Math.round(thisWeekMinutes / 60)} hours studying this week. Most productive time: ${mostProductiveDay.minutes > 0 ? dayNames[mostProductiveDay.day] : "N/A"} ${mostProductiveTime.minutes > 0 ? mostProductiveTime.time + "s" : ""}`
        : "No study sessions recorded yet. Start your first session to see analytics!";

    // Achievement tracking
    const achievements = [];
    const totalStudyHours = Math.round(
      studySessions.reduce((sum, s) => sum + (s.actualDuration || 0), 0) / 60
    );

    if (totalStudyHours >= 10) achievements.push({ title: "Study Warrior", icon: "⚔️" });
    if (totalStudyHours >= 25) achievements.push({ title: "Study Master", icon: "🏆" });
    if (totalStudyHours >= 50) achievements.push({ title: "Study Legend", icon: "👑" });
    if (totalStudyHours >= 100) achievements.push({ title: "Study Champion", icon: "🎊" });

    if (studySessions.length >= 10) achievements.push({ title: "Consistent", icon: "📅" });
    if (studySessions.length >= 25) achievements.push({ title: "Dedicated", icon: "💪" });
    if (studySessions.length >= 50) achievements.push({ title: "Unstoppable", icon: "🚀" });

    const improvingCourses = courseAnalytics.filter((c) => c.trend === "improving").length;
    if (improvingCourses >= 2) achievements.push({ title: "Rising Star", icon: "⭐" });
    if (improvingCourses >= 4) achievements.push({ title: "Academic Excellence", icon: "🌟" });

    return c.json({
      analytics: {
        weeklyReport: {
          thisWeekHours: Math.round((thisWeekMinutes / 60) * 10) / 10,
          lastWeekHours: Math.round((lastWeekMinutes / 60) * 10) / 10,
          change: thisWeekMinutes - lastWeekMinutes,
          changePercent:
            lastWeekMinutes > 0
              ? Math.round(((thisWeekMinutes - lastWeekMinutes) / lastWeekMinutes) * 100)
              : 0,
          message: weeklyReportMessage,
          mostProductiveDay: dayNames[mostProductiveDay.day],
          mostProductiveTime: mostProductiveTime.time,
        },
        productivity: {
          insight: productivityInsight,
          morningMinutes,
          afternoonMinutes,
          eveningMinutes,
          totalMinutes,
        },
        courses: courseAnalytics,
        subjectBalance,
        achievements,
        totalStats: {
          totalStudyHours,
          totalSessions: studySessions.length,
          averageSessionLength:
            studySessions.length > 0
              ? Math.round(
                  studySessions.reduce((sum, s) => sum + (s.actualDuration || 0), 0) /
                    studySessions.length
                )
              : 0,
        },
      },
    });
  } catch (error: any) {
    console.error("[Analytics] Error fetching analytics:", error);
    console.error("[Analytics] Error stack:", error?.stack);
    return c.json({ message: "Failed to fetch analytics", error: error?.message }, 500);
  }
});

// Get grade trends for a specific course
analyticsRouter.get("/course/:courseId/trends", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const courseId = c.req.param("courseId");

  try {
    const course = await db.course.findFirst({
      where: {
        id: courseId,
        userId: user.id,
      },
      include: {
        grades: {
          orderBy: { gradedAt: "asc" },
        },
      },
    });

    if (!course) {
      return c.json({ message: "Course not found" }, 404);
    }

    const gradesWithPercentage = course.grades.filter((g) => g.percentage !== null);

    // Calculate trend
    let trend: "improving" | "stable" | "slipping" | null = null;
    let trendMessage = "";

    if (gradesWithPercentage.length >= 4) {
      const midpoint = Math.floor(gradesWithPercentage.length / 2);
      const firstHalf = gradesWithPercentage.slice(0, midpoint);
      const secondHalf = gradesWithPercentage.slice(midpoint);

      const firstAvg =
        firstHalf.reduce((sum, g) => sum + (g.percentage || 0), 0) / firstHalf.length;
      const secondAvg =
        secondHalf.reduce((sum, g) => sum + (g.percentage || 0), 0) / secondHalf.length;

      const diff = secondAvg - firstAvg;
      if (diff > 3) {
        trend = "improving";
        trendMessage = `Your grades are improving! Up ${Math.round(diff)}% from earlier assignments.`;
      } else if (diff < -3) {
        trend = "slipping";
        trendMessage = `Your grades have dropped ${Math.round(Math.abs(diff))}%. Consider reviewing recent material.`;
      } else {
        trend = "stable";
        trendMessage = "Your grades are consistent. Keep up the good work!";
      }
    }

    // Calculate statistics
    const avgGrade =
      gradesWithPercentage.length > 0
        ? gradesWithPercentage.reduce((sum, g) => sum + (g.percentage || 0), 0) /
          gradesWithPercentage.length
        : null;

    const highestGrade =
      gradesWithPercentage.length > 0
        ? Math.max(...gradesWithPercentage.map((g) => g.percentage || 0))
        : null;

    const lowestGrade =
      gradesWithPercentage.length > 0
        ? Math.min(...gradesWithPercentage.map((g) => g.percentage || 0))
        : null;

    // Recent performance (last 3 grades vs previous 3)
    let recentTrend: "up" | "down" | "stable" | null = null;
    if (gradesWithPercentage.length >= 6) {
      const recent = gradesWithPercentage.slice(-3);
      const previous = gradesWithPercentage.slice(-6, -3);

      const recentAvg = recent.reduce((sum, g) => sum + (g.percentage || 0), 0) / recent.length;
      const previousAvg =
        previous.reduce((sum, g) => sum + (g.percentage || 0), 0) / previous.length;

      if (recentAvg > previousAvg + 2) {
        recentTrend = "up";
      } else if (recentAvg < previousAvg - 2) {
        recentTrend = "down";
      } else {
        recentTrend = "stable";
      }
    }

    return c.json({
      courseName: course.name,
      courseCode: course.courseCode,
      currentGrade: course.currentGrade,
      currentScore: course.currentScore,
      trend,
      trendMessage,
      recentTrend,
      statistics: {
        averageGrade: avgGrade ? Math.round(avgGrade * 10) / 10 : null,
        highestGrade,
        lowestGrade,
        totalGrades: gradesWithPercentage.length,
      },
      grades: gradesWithPercentage.map((g) => ({
        id: g.id,
        assignmentName: g.assignmentName,
        percentage: g.percentage,
        letterGrade: g.letterGrade,
        gradedAt: g.gradedAt,
      })),
    });
  } catch (error: any) {
    console.error("[Analytics] Error fetching course trends:", error);
    return c.json({ message: "Failed to fetch course trends" }, 500);
  }
});

export { analyticsRouter };
