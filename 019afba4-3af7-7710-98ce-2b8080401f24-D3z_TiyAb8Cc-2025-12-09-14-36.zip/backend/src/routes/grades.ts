import { Hono } from "hono";
import { type AppType } from "../types";
import { db } from "../db";
import { type GetGradesResponse, type GetCourseGradesResponse } from "@/shared/contracts";

const gradesRouter = new Hono<AppType>();

// ============================================
// GET /api/grades - Get all grades for user
// ============================================
gradesRouter.get("/", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const grades = await db.grade.findMany({
    where: { userId: user.id },
    include: {
      course: {
        select: {
          name: true,
          courseCode: true,
        },
      },
    },
    orderBy: { gradedAt: "desc" },
  });

  return c.json({
    grades: grades.map((grade) => ({
      id: grade.id,
      courseId: grade.courseId,
      courseName: grade.course.name,
      courseCode: grade.course.courseCode,
      assignmentName: grade.assignmentName,
      score: grade.score,
      maxScore: grade.maxScore,
      percentage: grade.percentage,
      letterGrade: grade.letterGrade,
      submittedAt: grade.submittedAt?.toISOString() ?? null,
      gradedAt: grade.gradedAt?.toISOString() ?? null,
      createdAt: grade.createdAt.toISOString(),
    })),
  } satisfies GetGradesResponse);
});

// ============================================
// GET /api/grades/course/:courseId - Get grades for a specific course
// ============================================
gradesRouter.get("/course/:courseId", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const courseId = c.req.param("courseId");

  const course = await db.course.findFirst({
    where: {
      id: courseId,
      userId: user.id,
    },
  });

  if (!course) {
    return c.json({ message: "Course not found" }, 404);
  }

  const grades = await db.grade.findMany({
    where: {
      courseId,
      userId: user.id,
    },
    orderBy: { gradedAt: "desc" },
  });

  return c.json({
    course: {
      id: course.id,
      name: course.name,
      courseCode: course.courseCode,
      currentGrade: course.currentGrade,
      currentScore: course.currentScore,
    },
    grades: grades.map((grade) => ({
      id: grade.id,
      assignmentName: grade.assignmentName,
      score: grade.score,
      maxScore: grade.maxScore,
      percentage: grade.percentage,
      letterGrade: grade.letterGrade,
      submittedAt: grade.submittedAt?.toISOString() ?? null,
      gradedAt: grade.gradedAt?.toISOString() ?? null,
    })),
  } satisfies GetCourseGradesResponse);
});

export { gradesRouter };
