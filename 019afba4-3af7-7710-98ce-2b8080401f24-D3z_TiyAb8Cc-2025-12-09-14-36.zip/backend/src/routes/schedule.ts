import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import {
  generateScheduleFromDescriptionRequestSchema,
  type GenerateScheduleFromDescriptionResponse,
  type GetCurrentScheduleResponse,
} from "@/shared/contracts";
import { type AppType } from "../types";
import { db } from "../db";

const scheduleRouter = new Hono<AppType>();

// Helper function to get start of week (Monday)
function getWeekStart(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
  return new Date(d.setDate(diff));
}

// Helper function to get end of week (Sunday)
function getWeekEnd(startDate: Date): Date {
  const d = new Date(startDate);
  d.setDate(d.getDate() + 6);
  return d;
}

// ============================================
// POST /api/schedule/generate-from-description
// AI-powered schedule generation from natural language
// ============================================
scheduleRouter.post(
  "/generate-from-description",
  zValidator("json", generateScheduleFromDescriptionRequestSchema),
  async (c) => {
    const user = c.get("user");
    if (!user) return c.json({ message: "Unauthorized" }, 401);

    const { description, weekStartDate } = c.req.valid("json");

    const startDate = weekStartDate ? new Date(weekStartDate) : getWeekStart(new Date());
    const endDate = getWeekEnd(startDate);

    try {
      // Get user's courses for context
      const courses = await db.course.findMany({
        where: { userId: user.id },
      });

      // Get user's assignments for context
      const assignments = await db.assignment.findMany({
        where: {
          userId: user.id,
          dueDate: { gte: startDate, lte: endDate },
        },
      });

      // Use Grok AI to parse the description and generate schedule
      // Check for Vibecode Grok key first
      const grokApiKey = process.env.EXPO_PUBLIC_VIBECODE_GROK_API_KEY;
      const grokBaseUrl = "https://api.x.ai/v1";

      console.log(`[Schedule] Grok API key available: ${!!grokApiKey}`);

      if (!grokApiKey) {
        console.log("[Schedule] No Grok API key found, using basic schedule generation");
        // Fallback to basic parsing if no API key
        return generateBasicSchedule(c, user.id, description, startDate, endDate);
      }

      const courseContext = courses.length > 0
        ? `Current courses: ${courses.map((c) => c.name).join(", ")}`
        : "No courses imported yet.";

      const assignmentContext = assignments.length > 0
        ? `Upcoming assignments this week: ${assignments.map((a) => `${a.title} (due ${a.dueDate.toLocaleDateString()})`).join(", ")}`
        : "No assignments due this week.";

      const prompt = `You are a smart scheduling assistant. Parse this student's weekly schedule description and create a detailed, realistic study schedule.

Student's Description: "${description}"

Context:
${courseContext}
${assignmentContext}

Based on the description, generate a complete weekly schedule with time blocks. Include:
- Class/lecture times mentioned
- Study sessions for each subject (allocate more time for subjects with upcoming assignments)
- Realistic breaks (15-30 min breaks between long study sessions)
- Personal time, work, or extracurricular activities mentioned
- Any other commitments mentioned

Return ONLY valid JSON in this exact format:
{
  "blocks": [
    {
      "title": "Study Calculus",
      "day": "Monday",
      "startTime": "14:00",
      "endTime": "16:00",
      "type": "study"
    },
    {
      "title": "Break",
      "day": "Monday",
      "startTime": "16:00",
      "endTime": "16:30",
      "type": "break"
    }
  ]
}

Rules:
- Types can be: "study", "class", "break", "personal"
- Use 24-hour time format (HH:mm) for startTime and endTime
- Days must be: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, or Sunday
- Include realistic breaks between long sessions
- Don't schedule study sessions too early (before 7am) or too late (after 11pm) unless specifically mentioned
- Create a balanced schedule that leaves time for meals and rest`;

      const response = await fetch(`${grokBaseUrl}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${grokApiKey}`,
        },
        body: JSON.stringify({
          model: "grok-2-1212",
          messages: [
            { role: "system", content: "You are a helpful scheduling assistant. Always respond with valid JSON only." },
            { role: "user", content: prompt }
          ],
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`[Schedule] Grok API error: ${response.status} - ${errorText}`);
        return generateBasicSchedule(c, user.id, description, startDate, endDate);
      }

      const aiResult = (await response.json()) as any;
      const content = aiResult.choices[0]?.message?.content;

      console.log(`[Schedule] Grok response received, parsing blocks...`);

      let parsedBlocks;
      try {
        // Try to parse the entire content as JSON first
        parsedBlocks = JSON.parse(content);
      } catch {
        // If that fails, try to extract JSON from the content
        try {
          const jsonMatch = content.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            parsedBlocks = JSON.parse(jsonMatch[0]);
          } else {
            console.error("[Schedule] Could not extract JSON from Grok response");
            return generateBasicSchedule(c, user.id, description, startDate, endDate);
          }
        } catch (parseError) {
          console.error("[Schedule] Failed to parse Grok response:", parseError);
          return generateBasicSchedule(c, user.id, description, startDate, endDate);
        }
      }

      if (!parsedBlocks.blocks || !Array.isArray(parsedBlocks.blocks)) {
        console.error("[Schedule] Invalid blocks format from Grok");
        return generateBasicSchedule(c, user.id, description, startDate, endDate);
      }

      console.log(`[Schedule] Parsed ${parsedBlocks.blocks.length} blocks from AI`);


      // Create weekly schedule
      const weeklySchedule = await db.weeklySchedule.create({
        data: {
          userId: user.id,
          weekStartDate: startDate,
          weekEndDate: endDate,
          description,
          aiGenerated: true,
        },
      });

      const dayMap: Record<string, number> = {
        Monday: 0,
        Tuesday: 1,
        Wednesday: 2,
        Thursday: 3,
        Friday: 4,
        Saturday: 5,
        Sunday: 6,
      };

      const createdBlocks = [];

      for (const block of parsedBlocks.blocks || []) {
        const dayOffset = dayMap[block.day] || 0;
        const blockDate = new Date(startDate);
        blockDate.setDate(blockDate.getDate() + dayOffset);

        const [startHour, startMin] = block.startTime.split(":").map(Number);
        const [endHour, endMin] = block.endTime.split(":").map(Number);

        const startTime = new Date(blockDate);
        startTime.setHours(startHour, startMin, 0, 0);

        const endTime = new Date(blockDate);
        endTime.setHours(endHour, endMin, 0, 0);

        const duration = Math.round((endTime.getTime() - startTime.getTime()) / 60000);

        const studyBlock = await db.studyBlock.create({
          data: {
            userId: user.id,
            title: block.title,
            startTime,
            endTime,
            duration,
            type: block.type || "study",
            weeklyScheduleId: weeklySchedule.id,
          },
        });

        createdBlocks.push({
          id: studyBlock.id,
          title: studyBlock.title || "",
          startTime: studyBlock.startTime.toISOString(),
          endTime: studyBlock.endTime.toISOString(),
          duration: studyBlock.duration,
          type: studyBlock.type,
        });
      }

      return c.json({
        scheduleId: weeklySchedule.id,
        studyBlocks: createdBlocks,
      } satisfies GenerateScheduleFromDescriptionResponse);
    } catch (error) {
      console.error("Schedule generation error:", error);
      return c.json({ message: "Failed to generate schedule" }, 500);
    }
  }
);

// Fallback basic schedule generator with simple parsing
async function generateBasicSchedule(
  c: any,
  userId: string,
  description: string,
  startDate: Date,
  endDate: Date
) {
  console.log("[Schedule] Generating basic schedule (no AI)");

  const weeklySchedule = await db.weeklySchedule.create({
    data: {
      userId,
      weekStartDate: startDate,
      weekEndDate: endDate,
      description,
      aiGenerated: false,
    },
  });

  const blocks = [];

  // Try to extract some basic information from the description
  const lowerDesc = description.toLowerCase();
  const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
  const dayMap: Record<string, number> = {
    monday: 0, tuesday: 1, wednesday: 2, thursday: 3,
    friday: 4, saturday: 5, sunday: 6,
    mon: 0, tue: 1, wed: 2, thu: 3, fri: 4, sat: 5, sun: 6
  };

  // Check which days are mentioned for classes
  const classDays = new Set<number>();
  for (const [dayName, dayIndex] of Object.entries(dayMap)) {
    if (lowerDesc.includes(dayName)) {
      classDays.add(dayIndex);
    }
  }

  // If no days mentioned, default to Mon-Fri
  if (classDays.size === 0) {
    for (let i = 0; i < 5; i++) {
      classDays.add(i);
    }
  }

  // Create basic study blocks for mentioned days
  for (const dayOffset of Array.from(classDays)) {
    const blockDate = new Date(startDate);
    blockDate.setDate(blockDate.getDate() + dayOffset);

    // Morning study session (9am-11am)
    const morning = new Date(blockDate);
    morning.setHours(9, 0, 0, 0);
    const morningEnd = new Date(blockDate);
    morningEnd.setHours(11, 0, 0, 0);

    const morningBlock = await db.studyBlock.create({
      data: {
        userId,
        title: "Morning Study Session",
        startTime: morning,
        endTime: morningEnd,
        duration: 120,
        type: "study",
        weeklyScheduleId: weeklySchedule.id,
      },
    });

    blocks.push({
      id: morningBlock.id,
      title: "Morning Study Session",
      startTime: morning.toISOString(),
      endTime: morningEnd.toISOString(),
      duration: 120,
      type: "study",
    });

    // Lunch break (12pm-1pm)
    const lunch = new Date(blockDate);
    lunch.setHours(12, 0, 0, 0);
    const lunchEnd = new Date(blockDate);
    lunchEnd.setHours(13, 0, 0, 0);

    const lunchBlock = await db.studyBlock.create({
      data: {
        userId,
        title: "Lunch Break",
        startTime: lunch,
        endTime: lunchEnd,
        duration: 60,
        type: "break",
        weeklyScheduleId: weeklySchedule.id,
      },
    });

    blocks.push({
      id: lunchBlock.id,
      title: "Lunch Break",
      startTime: lunch.toISOString(),
      endTime: lunchEnd.toISOString(),
      duration: 60,
      type: "break",
    });

    // Afternoon study (2pm-4pm)
    const afternoon = new Date(blockDate);
    afternoon.setHours(14, 0, 0, 0);
    const afternoonEnd = new Date(blockDate);
    afternoonEnd.setHours(16, 0, 0, 0);

    const afternoonBlock = await db.studyBlock.create({
      data: {
        userId,
        title: "Afternoon Study Session",
        startTime: afternoon,
        endTime: afternoonEnd,
        duration: 120,
        type: "study",
        weeklyScheduleId: weeklySchedule.id,
      },
    });

    blocks.push({
      id: afternoonBlock.id,
      title: "Afternoon Study Session",
      startTime: afternoon.toISOString(),
      endTime: afternoonEnd.toISOString(),
      duration: 120,
      type: "study",
    });

    // Evening study (7pm-9pm) - skip if description mentions "work" and "evening"
    const skipEvening = lowerDesc.includes('work') && lowerDesc.includes('evening');
    if (!skipEvening) {
      const evening = new Date(blockDate);
      evening.setHours(19, 0, 0, 0);
      const eveningEnd = new Date(blockDate);
      eveningEnd.setHours(21, 0, 0, 0);

      const eveningBlock = await db.studyBlock.create({
        data: {
          userId,
          title: "Evening Study Session",
          startTime: evening,
          endTime: eveningEnd,
          duration: 120,
          type: "study",
          weeklyScheduleId: weeklySchedule.id,
        },
      });

      blocks.push({
        id: eveningBlock.id,
        title: "Evening Study Session",
        startTime: evening.toISOString(),
        endTime: eveningEnd.toISOString(),
        duration: 120,
        type: "study",
      });
    }
  }

  console.log(`[Schedule] Generated ${blocks.length} basic blocks`);

  return c.json({
    scheduleId: weeklySchedule.id,
    studyBlocks: blocks,
  } satisfies GenerateScheduleFromDescriptionResponse);
}

// ============================================
// GET /api/schedule/current - Get current week's schedule
// ============================================
scheduleRouter.get("/current", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const startDate = getWeekStart(new Date());
  const endDate = getWeekEnd(startDate);

  const schedule = await db.weeklySchedule.findFirst({
    where: {
      userId: user.id,
      weekStartDate: { gte: startDate, lte: endDate },
    },
    include: {
      studyBlocks: {
        include: {
          assignment: {
            select: {
              id: true,
              title: true,
            },
          },
        },
        orderBy: { startTime: "asc" },
      },
    },
  });

  if (!schedule) {
    return c.json({ schedule: null } satisfies GetCurrentScheduleResponse);
  }

  return c.json({
    schedule: {
      id: schedule.id,
      weekStartDate: schedule.weekStartDate.toISOString(),
      weekEndDate: schedule.weekEndDate.toISOString(),
      description: schedule.description,
      aiGenerated: schedule.aiGenerated,
      studyBlocks: schedule.studyBlocks.map((block) => ({
        id: block.id,
        title: block.title,
        startTime: block.startTime.toISOString(),
        endTime: block.endTime.toISOString(),
        duration: block.duration,
        type: block.type,
        completed: block.completed,
        assignmentId: block.assignmentId,
        assignment: block.assignment,
      })),
    },
  } satisfies GetCurrentScheduleResponse);
});

export { scheduleRouter };
