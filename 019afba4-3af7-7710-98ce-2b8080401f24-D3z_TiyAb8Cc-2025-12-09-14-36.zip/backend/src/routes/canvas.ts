import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import {
  connectCanvasRequestSchema,
  type ConnectCanvasResponse,
  type GetCanvasStatusResponse,
  type SyncCanvasResponse,
  type DisconnectCanvasResponse,
} from "@/shared/contracts";
import { type AppType } from "../types";
import { db } from "../db";

const canvasRouter = new Hono<AppType>();

// ============================================
// POST /api/canvas/connect - Connect Canvas account
// ============================================
canvasRouter.post("/connect", zValidator("json", connectCanvasRequestSchema), async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const { canvasUrl, accessToken } = c.req.valid("json");

  console.log(`[Canvas] Attempting to connect for user ${user.id}`);
  console.log(`[Canvas] Canvas URL: ${canvasUrl}`);

  try {
    // Test the Canvas API connection
    const testUrl = `${canvasUrl}/api/v1/users/self`;
    console.log(`[Canvas] Testing connection to: ${testUrl}`);

    const testResponse = await fetch(testUrl, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    console.log(`[Canvas] Test response status: ${testResponse.status}`);

    if (!testResponse.ok) {
      const errorBody = await testResponse.text();
      console.error(`[Canvas] Connection test failed:`, errorBody);

      let errorMessage = "Failed to connect to Canvas. ";

      if (testResponse.status === 401) {
        errorMessage += "Invalid access token. Please check:\n\n1. Your token is correct and hasn't expired\n2. You copied the ENTIRE token from Canvas\n3. The token was generated from the correct Canvas account\n\nTo get a new token:\n• Go to Canvas Settings\n• Click 'Approved Integrations'\n• Generate a new access token\n• Make sure to set 'No Expiration' if possible";
      } else {
        errorMessage += `Please check your URL and access token. (Error ${testResponse.status})`;
      }

      return c.json(
        {
          success: false,
          message: errorMessage,
        } satisfies ConnectCanvasResponse,
        400
      );
    }

    const userData = await testResponse.json();
    console.log(`[Canvas] Successfully connected as user: ${userData.name || userData.id}`);

    // Store the Canvas integration
    await db.canvasIntegration.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        canvasUrl,
        accessToken, // In production, this should be encrypted
        syncEnabled: true,
      },
      update: {
        canvasUrl,
        accessToken,
        syncEnabled: true,
      },
    });

    console.log(`[Canvas] Integration saved successfully`);

    return c.json({
      success: true,
      message: "Canvas connected successfully!",
    } satisfies ConnectCanvasResponse);
  } catch (error) {
    console.error("[Canvas] Connection error:", error);
    return c.json(
      {
        success: false,
        message: `Failed to connect to Canvas: ${error instanceof Error ? error.message : "Unknown error"}`,
      } satisfies ConnectCanvasResponse,
      500
    );
  }
});

// ============================================
// GET /api/canvas/status - Get Canvas connection status
// ============================================
canvasRouter.get("/status", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const integration = await db.canvasIntegration.findUnique({
    where: { userId: user.id },
  });

  if (!integration) {
    return c.json({
      connected: false,
      lastSyncAt: null,
      syncEnabled: false,
    } satisfies GetCanvasStatusResponse);
  }

  return c.json({
    connected: true,
    canvasUrl: integration.canvasUrl,
    lastSyncAt: integration.lastSyncAt?.toISOString() ?? null,
    syncEnabled: integration.syncEnabled,
  } satisfies GetCanvasStatusResponse);
});

// ============================================
// POST /api/canvas/sync - Sync assignments, grades, and schedules from Canvas
// ============================================
canvasRouter.post("/sync", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  console.log(`[Canvas] Starting sync for user ${user.id}`);

  const integration = await db.canvasIntegration.findUnique({
    where: { userId: user.id },
  });

  if (!integration) {
    console.log(`[Canvas] No integration found for user ${user.id}`);
    return c.json({ message: "Canvas not connected" }, 400);
  }

  console.log(`[Canvas] Found integration: ${integration.canvasUrl}`);

  try {
    let assignmentsImported = 0;
    let coursesImported = 0;
    let gradesImported = 0;
    let scheduleBlocksCreated = 0;

    // Fetch courses with enrollments
    console.log(`[Canvas] Fetching courses from ${integration.canvasUrl}`);
    const coursesResponse = await fetch(
      `${integration.canvasUrl}/api/v1/courses?enrollment_state=active&per_page=100&include[]=term&include[]=total_scores&include[]=current_grading_period_scores`,
      {
        headers: {
          Authorization: `Bearer ${integration.accessToken}`,
        },
      }
    );

    console.log(`[Canvas] Courses response status: ${coursesResponse.status}`);

    if (coursesResponse.ok) {
      const canvasCourses = (await coursesResponse.json()) as any[];
      console.log(`[Canvas] Found ${canvasCourses.length} courses`);

      for (const canvasCourse of canvasCourses) {
        console.log(`[Canvas] Processing course: ${canvasCourse.name} (ID: ${canvasCourse.id})`);
        // Extract enrollment data
        const enrollment = canvasCourse.enrollments?.[0];
        const currentScore = enrollment?.computed_current_score;
        const currentGrade = enrollment?.computed_current_grade;

        console.log(`[Canvas] Course enrollment data:`, {
          currentScore,
          currentGrade,
          enrollmentState: enrollment?.enrollment_state,
        });

        // Create or update course
        const course = await db.course.upsert({
          where: { id: `canvas-${canvasCourse.id}` },
          create: {
            id: `canvas-${canvasCourse.id}`,
            userId: user.id,
            name: canvasCourse.name || canvasCourse.course_code,
            courseCode: canvasCourse.course_code,
            canvasCourseId: String(canvasCourse.id),
            currentScore: currentScore || null,
            currentGrade: currentGrade || null,
            enrollmentStatus: "active",
            term: canvasCourse.term?.name || null,
          },
          update: {
            name: canvasCourse.name || canvasCourse.course_code,
            courseCode: canvasCourse.course_code,
            currentScore: currentScore || null,
            currentGrade: currentGrade || null,
            term: canvasCourse.term?.name || null,
          },
        });
        coursesImported++;
        console.log(`[Canvas] Imported/updated course: ${canvasCourse.name}`);

        // Fetch course details including calendar events for schedule
        const courseDetailsResponse = await fetch(
          `${integration.canvasUrl}/api/v1/courses/${canvasCourse.id}?include[]=syllabus_body`,
          {
            headers: {
              Authorization: `Bearer ${integration.accessToken}`,
            },
          }
        );

        if (courseDetailsResponse.ok) {
          const courseDetails = (await courseDetailsResponse.json()) as any;

          // Get calendar events for this course to extract schedule
          const calendarResponse = await fetch(
            `${integration.canvasUrl}/api/v1/calendar_events?type=event&context_codes[]=course_${canvasCourse.id}&start_date=${new Date().toISOString()}&end_date=${new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()}`,
            {
              headers: {
                Authorization: `Bearer ${integration.accessToken}`,
              },
            }
          );

          if (calendarResponse.ok) {
            const calendarEvents = (await calendarResponse.json()) as any[];

            // Create study blocks for class meetings
            for (const event of calendarEvents) {
              if (event.start_at && event.end_at) {
                const startTime = new Date(event.start_at);
                const endTime = new Date(event.end_at);
                const duration = Math.round((endTime.getTime() - startTime.getTime()) / (1000 * 60));

                // Check if block already exists
                const existingBlock = await db.studyBlock.findFirst({
                  where: {
                    userId: user.id,
                    startTime,
                    title: canvasCourse.name,
                    type: "class",
                  },
                });

                if (!existingBlock) {
                  await db.studyBlock.create({
                    data: {
                      userId: user.id,
                      title: canvasCourse.name,
                      startTime,
                      endTime,
                      duration,
                      type: "class",
                      completed: false,
                    },
                  });
                  scheduleBlocksCreated++;
                }
              }
            }
          }
        }

        // Fetch assignments for this course
        console.log(`[Canvas] Fetching assignments for course ${canvasCourse.name}`);
        const assignmentsResponse = await fetch(
          `${integration.canvasUrl}/api/v1/courses/${canvasCourse.id}/assignments?per_page=100&include[]=submission&include[]=score_statistics`,
          {
            headers: {
              Authorization: `Bearer ${integration.accessToken}`,
            },
          }
        );

        if (assignmentsResponse.ok) {
          const canvasAssignments = (await assignmentsResponse.json()) as any[];
          console.log(`[Canvas] Found ${canvasAssignments.length} assignments for course ${canvasCourse.name}`);

          for (const canvasAssignment of canvasAssignments) {
            // Import grades if submission exists
            const submission = canvasAssignment.submission;
            if (submission && submission.score !== null && submission.score !== undefined) {
              console.log(`[Canvas] Processing grade for assignment: ${canvasAssignment.name}, score: ${submission.score}`);
              // Check if grade already exists
              const existingGrade = await db.grade.findFirst({
                where: {
                  userId: user.id,
                  courseId: course.id,
                  canvasAssignmentId: String(canvasAssignment.id),
                },
              });

              if (!existingGrade) {
                const percentage = canvasAssignment.points_possible
                  ? (submission.score / canvasAssignment.points_possible) * 100
                  : null;

                await db.grade.create({
                  data: {
                    userId: user.id,
                    courseId: course.id,
                    assignmentName: canvasAssignment.name,
                    score: submission.score,
                    maxScore: canvasAssignment.points_possible || null,
                    percentage: percentage,
                    letterGrade: submission.grade || null,
                    submittedAt: submission.submitted_at ? new Date(submission.submitted_at) : null,
                    gradedAt: submission.graded_at ? new Date(submission.graded_at) : null,
                    canvasAssignmentId: String(canvasAssignment.id),
                  },
                });
                gradesImported++;
                console.log(`[Canvas] Imported grade for ${canvasAssignment.name}: ${submission.score}/${canvasAssignment.points_possible}`);
              } else {
                console.log(`[Canvas] Grade already exists for ${canvasAssignment.name}`);
              }
            }

            // Import upcoming assignments (not yet submitted or not graded)
            if (canvasAssignment.due_at) {
              const dueDate = new Date(canvasAssignment.due_at);
              const now = new Date();

              // Only import if due in the future or recently due (within 30 days)
              const daysDiff = (dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);

              if (daysDiff > -30) {
                console.log(`[Canvas] Processing assignment: ${canvasAssignment.name}, due: ${canvasAssignment.due_at}`);
                const existing = await db.assignment.findFirst({
                  where: {
                    userId: user.id,
                    title: canvasAssignment.name,
                  },
                });

                if (!existing) {
                  await db.assignment.create({
                    data: {
                      title: canvasAssignment.name,
                      description: canvasAssignment.description || `Assignment for ${canvasCourse.name}`,
                      dueDate: dueDate,
                      priority: daysDiff <= 3 ? "high" : daysDiff <= 7 ? "medium" : "low",
                      userId: user.id,
                      status: submission?.workflow_state === "submitted" || submission?.workflow_state === "graded" ? "completed" : "todo",
                    },
                  });
                  assignmentsImported++;
                  console.log(`[Canvas] Imported assignment: ${canvasAssignment.name}`);
                } else {
                  console.log(`[Canvas] Assignment already exists: ${canvasAssignment.name}`);
                }
              }
            }
          }
        }
      }
    }

    // Update last sync time
    await db.canvasIntegration.update({
      where: { userId: user.id },
      data: { lastSyncAt: new Date() },
    });

    console.log(`[Canvas] Sync complete:`, {
      coursesImported,
      assignmentsImported,
      gradesImported,
      scheduleBlocksCreated,
    });

    return c.json({
      success: true,
      assignmentsImported,
      coursesImported,
      gradesImported,
      scheduleBlocksCreated,
    } satisfies SyncCanvasResponse);
  } catch (error) {
    console.error("[Canvas] Sync error:", error);
    return c.json({ message: "Failed to sync Canvas data" }, 500);
  }
});

// ============================================
// DELETE /api/canvas/disconnect - Disconnect Canvas
// ============================================
canvasRouter.delete("/disconnect", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  await db.canvasIntegration.deleteMany({
    where: { userId: user.id },
  });

  return c.json({ success: true } satisfies DisconnectCanvasResponse);
});

export { canvasRouter };
