import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { db } from "../db";
import type { AppType } from "../types";

const studySessionsRouter = new Hono<AppType>();

// Get all study sessions for the user
studySessionsRouter.get("/", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  try {
    const sessions = await db.studySession.findMany({
      where: { userId: user.id },
      orderBy: { startTime: "desc" },
    });

    return c.json({ sessions });
  } catch (error: any) {
    console.error("[StudySessions] Error fetching sessions:", error);
    return c.json({ message: "Failed to fetch study sessions" }, 500);
  }
});

// Get active study session
studySessionsRouter.get("/active", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  try {
    const activeSession = await db.studySession.findFirst({
      where: {
        userId: user.id,
        status: "active",
      },
    });

    return c.json({ session: activeSession });
  } catch (error: any) {
    console.error("[StudySessions] Error fetching active session:", error);
    return c.json({ message: "Failed to fetch active session" }, 500);
  }
});

// Create a new study session
studySessionsRouter.post(
  "/",
  zValidator(
    "json",
    z.object({
      plannedDuration: z.number().min(1).max(480), // 1 minute to 8 hours
      blockedApps: z.array(z.string()).optional(),
    })
  ),
  async (c) => {
    const user = c.get("user");
    if (!user) {
      return c.json({ message: "Unauthorized" }, 401);
    }

    const { plannedDuration, blockedApps } = c.req.valid("json");

    try {
      // Check if there's already an active session
      const existingSession = await db.studySession.findFirst({
        where: {
          userId: user.id,
          status: "active",
        },
      });

      if (existingSession) {
        return c.json({ message: "You already have an active study session" }, 400);
      }

      // Create new study session
      const session = await db.studySession.create({
        data: {
          userId: user.id,
          startTime: new Date(),
          plannedDuration,
          blockedApps: blockedApps ? JSON.stringify(blockedApps) : null,
          status: "active",
        },
      });

      return c.json({ session }, 201);
    } catch (error: any) {
      console.error("[StudySessions] Error creating session:", error);
      return c.json({ message: "Failed to create study session" }, 500);
    }
  }
);

// Update study session (for breaks, etc.)
studySessionsRouter.patch(
  "/:id",
  zValidator(
    "json",
    z.object({
      breaksUsed: z.number().optional(),
      breakTimeUsed: z.number().optional(),
    })
  ),
  async (c) => {
    const user = c.get("user");
    if (!user) {
      return c.json({ message: "Unauthorized" }, 401);
    }

    const sessionId = c.req.param("id");
    const { breaksUsed, breakTimeUsed } = c.req.valid("json");

    try {
      // Verify session belongs to user
      const session = await db.studySession.findFirst({
        where: {
          id: sessionId,
          userId: user.id,
        },
      });

      if (!session) {
        return c.json({ message: "Study session not found" }, 404);
      }

      // Update session
      const updatedSession = await db.studySession.update({
        where: { id: sessionId },
        data: {
          breaksUsed: breaksUsed ?? session.breaksUsed,
          breakTimeUsed: breakTimeUsed ?? session.breakTimeUsed,
        },
      });

      return c.json({ session: updatedSession });
    } catch (error: any) {
      console.error("[StudySessions] Error updating session:", error);
      return c.json({ message: "Failed to update study session" }, 500);
    }
  }
);

// End study session
studySessionsRouter.post("/:id/end", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const sessionId = c.req.param("id");

  try {
    // Verify session belongs to user
    const session = await db.studySession.findFirst({
      where: {
        id: sessionId,
        userId: user.id,
      },
    });

    if (!session) {
      return c.json({ message: "Study session not found" }, 404);
    }

    // Calculate actual duration
    const endTime = new Date();
    const actualDuration = Math.floor((endTime.getTime() - session.startTime.getTime()) / 60000);

    // Update session
    const updatedSession = await db.studySession.update({
      where: { id: sessionId },
      data: {
        endTime,
        actualDuration,
        status: "completed",
      },
    });

    return c.json({ session: updatedSession });
  } catch (error: any) {
    console.error("[StudySessions] Error ending session:", error);
    return c.json({ message: "Failed to end study session" }, 500);
  }
});

// Cancel study session
studySessionsRouter.post("/:id/cancel", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const sessionId = c.req.param("id");

  try {
    // Verify session belongs to user
    const session = await db.studySession.findFirst({
      where: {
        id: sessionId,
        userId: user.id,
      },
    });

    if (!session) {
      return c.json({ message: "Study session not found" }, 404);
    }

    // Update session
    const updatedSession = await db.studySession.update({
      where: { id: sessionId },
      data: {
        endTime: new Date(),
        status: "cancelled",
      },
    });

    return c.json({ session: updatedSession });
  } catch (error: any) {
    console.error("[StudySessions] Error cancelling session:", error);
    return c.json({ message: "Failed to cancel study session" }, 500);
  }
});

// Get study session statistics
studySessionsRouter.get("/stats", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  try {
    const sessions = await db.studySession.findMany({
      where: {
        userId: user.id,
        status: "completed",
      },
    });

    const totalSessions = sessions.length;
    const totalMinutes = sessions.reduce((sum, s) => sum + (s.actualDuration || 0), 0);
    const totalBreaks = sessions.reduce((sum, s) => sum + s.breaksUsed, 0);
    const averageSessionLength = totalSessions > 0 ? Math.round(totalMinutes / totalSessions) : 0;

    // Get sessions from last 7 days
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const recentSessions = sessions.filter((s) => s.startTime >= sevenDaysAgo);
    const weeklyMinutes = recentSessions.reduce((sum, s) => sum + (s.actualDuration || 0), 0);

    return c.json({
      stats: {
        totalSessions,
        totalMinutes,
        totalHours: Math.round((totalMinutes / 60) * 10) / 10,
        totalBreaks,
        averageSessionLength,
        weeklyMinutes,
        weeklyHours: Math.round((weeklyMinutes / 60) * 10) / 10,
      },
    });
  } catch (error: any) {
    console.error("[StudySessions] Error fetching stats:", error);
    return c.json({ message: "Failed to fetch statistics" }, 500);
  }
});

export { studySessionsRouter };
