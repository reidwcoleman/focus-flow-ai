import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { type AppType } from "../types";
import { db } from "../db";
import { HfInference } from "@huggingface/inference";

const activitiesRouter = new Hono<AppType>();

// Zod schemas for validation
const createActivitySchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  date: z.string(), // ISO date string
  startTime: z.string().optional(),
  endTime: z.string().optional(),
  color: z.string().default("#3A7BFF"),
  allDay: z.boolean().default(false),
});

const updateActivitySchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  date: z.string().optional(),
  startTime: z.string().optional(),
  endTime: z.string().optional(),
  color: z.string().optional(),
  allDay: z.boolean().optional(),
  completed: z.boolean().optional(),
});

// ============================================
// GET /api/activities - Get all activities for user
// ============================================
activitiesRouter.get("/", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const activities = await db.activity.findMany({
    where: { userId: user.id },
    orderBy: { date: "asc" },
  });

  return c.json({ activities });
});

// ============================================
// GET /api/activities/month/:year/:month - Get activities for a specific month
// ============================================
activitiesRouter.get("/month/:year/:month", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const year = parseInt(c.req.param("year"));
  const month = parseInt(c.req.param("month")); // 1-12

  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0, 23, 59, 59, 999);

  const activities = await db.activity.findMany({
    where: {
      userId: user.id,
      date: {
        gte: startDate,
        lte: endDate,
      },
    },
    orderBy: { date: "asc" },
  });

  return c.json({ activities });
});

// ============================================
// POST /api/activities - Create a new activity
// ============================================
activitiesRouter.post("/", zValidator("json", createActivitySchema), async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const body = c.req.valid("json");

  const activity = await db.activity.create({
    data: {
      userId: user.id,
      title: body.title,
      description: body.description,
      date: new Date(body.date),
      startTime: body.startTime,
      endTime: body.endTime,
      color: body.color,
      allDay: body.allDay,
    },
  });

  return c.json({ activity }, 201);
});

// ============================================
// PATCH /api/activities/:id - Update an activity
// ============================================
activitiesRouter.patch("/:id", zValidator("json", updateActivitySchema), async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const id = c.req.param("id");

  // Check if activity exists and belongs to user
  const existing = await db.activity.findFirst({
    where: { id, userId: user.id },
  });

  if (!existing) {
    return c.json({ message: "Activity not found" }, 404);
  }

  const body = c.req.valid("json");

  const activity = await db.activity.update({
    where: { id },
    data: {
      ...(body.title && { title: body.title }),
      ...(body.description !== undefined && { description: body.description }),
      ...(body.date && { date: new Date(body.date) }),
      ...(body.startTime !== undefined && { startTime: body.startTime }),
      ...(body.endTime !== undefined && { endTime: body.endTime }),
      ...(body.color && { color: body.color }),
      ...(body.allDay !== undefined && { allDay: body.allDay }),
      ...(body.completed !== undefined && { completed: body.completed }),
    },
  });

  return c.json({ activity });
});

// ============================================
// DELETE /api/activities/:id - Delete an activity
// ============================================
activitiesRouter.delete("/:id", async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);

  const id = c.req.param("id");

  // Check if activity exists and belongs to user
  const existing = await db.activity.findFirst({
    where: { id, userId: user.id },
  });

  if (!existing) {
    return c.json({ message: "Activity not found" }, 404);
  }

  await db.activity.delete({
    where: { id },
  });

  return c.json({ message: "Activity deleted" });
});

// ============================================
// POST /api/activities/generate-from-description
// AI-powered activity generation from natural language
// ============================================
activitiesRouter.post(
  "/generate-from-description",
  zValidator("json", z.object({ description: z.string().min(1) })),
  async (c) => {
    const user = c.get("user");
    if (!user) return c.json({ message: "Unauthorized" }, 401);

    const { description } = c.req.valid("json");

    try {
      const hfToken = process.env.HUGGINGFACE_API_KEY || "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";

      console.log(`[Activities] Generating activities from description using Hugging Face AI`);

      const hf = new HfInference(hfToken);

      const systemPrompt = `You are a smart calendar assistant that helps students organize their activities. Parse the user's description and create calendar activities in JSON format.

Based on the description, generate calendar activities. For each activity:
- Extract the specific date (if mentioned) or spread activities over the next 7 days
- Extract time if mentioned, otherwise make it all-day
- Create descriptive titles that are clear and actionable
- Assign appropriate colors based on activity type:
  - Study/Work: #3A7BFF (blue)
  - Exercise/Sports: #10B981 (green)
  - Social/Fun: #F59E0B (orange)
  - Class/Meeting: #8B5CF6 (purple)
  - Break/Rest: #EF4444 (red)

IMPORTANT: Return ONLY valid JSON in this exact format (no markdown, no explanations):
{
  "activities": [
    {
      "title": "Study Calculus",
      "description": "Review chapter 5",
      "date": "2025-12-10",
      "startTime": "14:00",
      "endTime": "16:00",
      "color": "#3A7BFF",
      "allDay": false
    }
  ]
}

Rules:
- Date format: YYYY-MM-DD
- Time format: HH:mm (24-hour)
- If no specific date mentioned, use dates over the next 7 days starting from today (2025-12-09)
- If no time mentioned, set allDay to true and omit startTime/endTime
- Create realistic, useful activities based on the description
- Always return valid JSON only`;

      const userPrompt = `User's Description: "${description}"

Generate calendar activities based on this description. Return only valid JSON.`;

      console.log(`[Activities] Calling Hugging Face API...`);

      // Use Qwen2.5-72B-Instruct for better reasoning and JSON output
      const response = await hf.chatCompletion({
        model: "Qwen/Qwen2.5-72B-Instruct",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        max_tokens: 2000,
        temperature: 0.7,
      });

      const content = response.choices[0]?.message?.content;

      if (!content) {
        console.error("[Activities] No content from Hugging Face API");
        throw new Error("AI service returned empty response");
      }

      console.log(`[Activities] Hugging Face response received, parsing activities...`);

      let parsedActivities;
      try {
        // Try to parse the entire response as JSON first
        parsedActivities = JSON.parse(content);
      } catch {
        try {
          // Try to extract JSON from markdown code blocks or other text
          const jsonMatch = content.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            parsedActivities = JSON.parse(jsonMatch[0]);
          } else {
            throw new Error("Could not extract JSON from response");
          }
        } catch (parseError) {
          console.error("[Activities] Failed to parse Hugging Face response:", parseError);
          console.error("[Activities] Raw response:", content);
          throw new Error("AI parsing failed");
        }
      }

      if (!parsedActivities.activities || !Array.isArray(parsedActivities.activities)) {
        console.error("[Activities] Invalid activities format from Hugging Face");
        console.error("[Activities] Parsed data:", parsedActivities);
        throw new Error("Invalid AI response format");
      }

      console.log(`[Activities] Parsed ${parsedActivities.activities.length} activities from AI`);

      const createdActivities = [];

      for (const actData of parsedActivities.activities) {
        const activity = await db.activity.create({
          data: {
            userId: user.id,
            title: actData.title,
            description: actData.description || null,
            date: new Date(actData.date),
            startTime: actData.startTime || null,
            endTime: actData.endTime || null,
            color: actData.color || "#3A7BFF",
            allDay: actData.allDay !== undefined ? actData.allDay : !actData.startTime,
          },
        });

        createdActivities.push(activity);
      }

      console.log(`[Activities] Created ${createdActivities.length} activities in database`);

      return c.json({
        activities: createdActivities,
        count: createdActivities.length,
      });
    } catch (error) {
      console.error("[Activities] Generation error:", error);

      // Fallback: create a single basic activity from the description
      console.log("[Activities] Creating fallback activity due to AI error");
      const activity = await db.activity.create({
        data: {
          userId: user.id,
          title: description.slice(0, 100), // Truncate if too long
          description: "AI-generated activity (fallback mode)",
          date: new Date(),
          color: "#3A7BFF",
          allDay: true,
        },
      });

      return c.json({
        activities: [activity],
        count: 1,
        fallback: true,
      });
    }
  }
);

export { activitiesRouter };
