import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import {
  type GetStudyBlocksResponse,
  generateStudyBlocksRequestSchema,
  type GenerateStudyBlocksResponse,
} from "@/shared/contracts";
import { type AppType } from "../types";
import { db } from "../db";

const studyBlocksRouter = new Hono<AppType>();

// ============================================
// GET /api/study-blocks - Get study blocks for user
// ============================================
studyBlocksRouter.get("/", async (c) => {
  const user = c.get("user");

  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const studyBlocks = await db.studyBlock.findMany({
    where: { userId: user.id },
    include: {
      assignment: {
        select: {
          id: true,
          title: true,
          subject: {
            select: {
              name: true,
              color: true,
            },
          },
        },
      },
    },
    orderBy: { startTime: "asc" },
  });

  return c.json({
    studyBlocks: studyBlocks.map((sb) => ({
      id: sb.id,
      assignmentId: sb.assignmentId,
      assignment: sb.assignment,
      startTime: sb.startTime.toISOString(),
      endTime: sb.endTime.toISOString(),
      duration: sb.duration,
      completed: sb.completed,
      createdAt: sb.createdAt.toISOString(),
    })),
  } satisfies GetStudyBlocksResponse);
});

// ============================================
// POST /api/study-blocks/generate - AI-generated study blocks
// ============================================
studyBlocksRouter.post(
  "/generate",
  zValidator("json", generateStudyBlocksRequestSchema),
  async (c) => {
    const user = c.get("user");

    if (!user) {
      return c.json({ message: "Unauthorized" }, 401);
    }

    const { assignmentId } = c.req.valid("json");

    // Get assignments to generate study blocks for
    const assignments = assignmentId
      ? await db.assignment.findMany({
          where: { id: assignmentId, userId: user.id },
        })
      : await db.assignment.findMany({
          where: {
            userId: user.id,
            status: { in: ["todo", "in_progress"] },
          },
          orderBy: { dueDate: "asc" },
          take: 5, // Generate for next 5 assignments
        });

    if (assignments.length === 0) {
      return c.json({ studyBlocks: [] } satisfies GenerateStudyBlocksResponse);
    }

    // Simple algorithm: distribute study time based on due dates
    const studyBlocks = [];
    const now = new Date();

    for (const assignment of assignments) {
      const daysUntilDue = Math.ceil(
        (assignment.dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
      );

      // Determine study duration based on priority and time until due
      let totalMinutes = 60; // default 1 hour
      if (assignment.priority === "urgent") totalMinutes = 120;
      else if (assignment.priority === "high") totalMinutes = 90;
      else if (assignment.priority === "low") totalMinutes = 45;

      // Split into sessions if more than 60 minutes
      const sessionCount = Math.ceil(totalMinutes / 60);
      const sessionDuration = Math.floor(totalMinutes / sessionCount);

      for (let i = 0; i < sessionCount; i++) {
        // Schedule at 8:30 PM for the next few days
        const sessionDate = new Date(now);
        sessionDate.setDate(sessionDate.getDate() + i);
        sessionDate.setHours(20, 30, 0, 0);

        const endTime = new Date(sessionDate);
        endTime.setMinutes(endTime.getMinutes() + sessionDuration);

        const block = await db.studyBlock.create({
          data: {
            assignmentId: assignment.id,
            userId: user.id,
            startTime: sessionDate,
            endTime: endTime,
            duration: sessionDuration,
          },
        });

        studyBlocks.push({
          id: block.id,
          assignmentId: block.assignmentId,
          startTime: block.startTime.toISOString(),
          endTime: block.endTime.toISOString(),
          duration: block.duration,
        });
      }
    }

    return c.json({ studyBlocks } satisfies GenerateStudyBlocksResponse);
  }
);

export { studyBlocksRouter };
