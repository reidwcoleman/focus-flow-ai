import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import {
  type GetSubjectsResponse,
  createSubjectRequestSchema,
  type CreateSubjectResponse,
  type DeleteSubjectResponse,
} from "@/shared/contracts";
import { type AppType } from "../types";
import { db } from "../db";

const subjectsRouter = new Hono<AppType>();

// ============================================
// GET /api/subjects - Get all subjects for user
// ============================================
subjectsRouter.get("/", async (c) => {
  const user = c.get("user");

  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const subjects = await db.subject.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "asc" },
  });

  return c.json({
    subjects: subjects.map((s) => ({
      ...s,
      createdAt: s.createdAt.toISOString(),
      updatedAt: s.updatedAt.toISOString(),
    })),
  } satisfies GetSubjectsResponse);
});

// ============================================
// POST /api/subjects - Create a new subject
// ============================================
subjectsRouter.post("/", zValidator("json", createSubjectRequestSchema), async (c) => {
  const user = c.get("user");

  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const data = c.req.valid("json");

  const subject = await db.subject.create({
    data: {
      name: data.name,
      color: data.color,
      icon: data.icon,
      userId: user.id,
    },
  });

  return c.json({
    id: subject.id,
    name: subject.name,
    color: subject.color,
    icon: subject.icon,
    createdAt: subject.createdAt.toISOString(),
    updatedAt: subject.updatedAt.toISOString(),
  } satisfies CreateSubjectResponse);
});

// ============================================
// DELETE /api/subjects/:id - Delete a subject
// ============================================
subjectsRouter.delete("/:id", async (c) => {
  const user = c.get("user");

  if (!user) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const id = c.req.param("id");

  const subject = await db.subject.findFirst({
    where: { id, userId: user.id },
  });

  if (!subject) {
    return c.json({ message: "Subject not found" }, 404);
  }

  await db.subject.delete({
    where: { id },
  });

  return c.json({ success: true } satisfies DeleteSubjectResponse);
});

export { subjectsRouter };
