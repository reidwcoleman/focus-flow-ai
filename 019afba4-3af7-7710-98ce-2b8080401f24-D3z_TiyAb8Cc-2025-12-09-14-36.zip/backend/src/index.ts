import { serve } from "@hono/node-server";
import { Hono } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";
import { serveStatic } from "@hono/node-server/serve-static";

import { auth } from "./auth";
import { env } from "./env";
import { uploadRouter } from "./routes/upload";
import { sampleRouter } from "./routes/sample";
import { subjectsRouter } from "./routes/subjects";
import { assignmentsRouter } from "./routes/assignments";
import { studyBlocksRouter } from "./routes/study-blocks";
import { canvasRouter } from "./routes/canvas";
import { scheduleRouter } from "./routes/schedule";
import { coursesRouter } from "./routes/courses";
import { gradesRouter } from "./routes/grades";
import { activitiesRouter } from "./routes/activities";
import { streakRouter } from "./routes/streak";
import { studySessionsRouter } from "./routes/study-sessions";
import { analyticsRouter } from "./routes/analytics";
import { type AppType } from "./types";

// AppType context adds user and session to the context, will be null if the user or session is null
const app = new Hono<AppType>();

console.log("🔧 Initializing Hono application...");
app.use("*", logger());
app.use(
  "/*",
  cors({
    origin: (origin) => origin || "*", // Allow the requesting origin or fallback to *
    credentials: true,
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  }),
);

/** Authentication middleware
 * Extracts session from request headers and attaches user/session to context
 * All routes can access c.get("user") and c.get("session")
 */
app.use("*", async (c, next) => {
  // Try to get session from Better Auth (handles both cookies and Bearer tokens)
  const session = await auth.api.getSession({ headers: c.req.raw.headers });

  // Log authentication attempts for debugging
  if (!session) {
    const authHeader = c.req.header("Authorization");
    console.log(`[Auth] No session found for ${c.req.method} ${c.req.path}`, authHeader ? `(Bearer token present: ${authHeader.substring(0, 20)}...)` : "(no auth header)");
  }

  c.set("user", session?.user ?? null); // type: typeof auth.$Infer.Session.user | null
  c.set("session", session?.session ?? null); // type: typeof auth.$Infer.Session.session | null
  return next();
});

// Better Auth handler
// Handles all authentication endpoints: /api/auth/sign-in, /api/auth/sign-up, etc.
console.log("🔐 Mounting Better Auth handler at /api/auth/*");
app.on(["GET", "POST"], "/api/auth/*", (c) => auth.handler(c.req.raw));

// Serve uploaded images statically
// Files in uploads/ directory are accessible at /uploads/* URLs
console.log("📁 Serving static files from uploads/ directory");
app.use("/uploads/*", serveStatic({ root: "./" }));

// Mount route modules
console.log("📤 Mounting upload routes at /api/upload");
app.route("/api/upload", uploadRouter);

console.log("📝 Mounting sample routes at /api/sample");
app.route("/api/sample", sampleRouter);

console.log("📚 Mounting subjects routes at /api/subjects");
app.route("/api/subjects", subjectsRouter);

console.log("📝 Mounting assignments routes at /api/assignments");
app.route("/api/assignments", assignmentsRouter);

console.log("📅 Mounting study blocks routes at /api/study-blocks");
app.route("/api/study-blocks", studyBlocksRouter);

console.log("🎨 Mounting canvas routes at /api/canvas");
app.route("/api/canvas", canvasRouter);

console.log("📅 Mounting schedule routes at /api/schedule");
app.route("/api/schedule", scheduleRouter);

console.log("📚 Mounting courses routes at /api/courses");
app.route("/api/courses", coursesRouter);

console.log("📊 Mounting grades routes at /api/grades");
app.route("/api/grades", gradesRouter);

console.log("📅 Mounting activities routes at /api/activities");
app.route("/api/activities", activitiesRouter);

console.log("🔥 Mounting streak routes at /api/streak");
app.route("/api/streak", streakRouter);

console.log("🎯 Mounting study sessions routes at /api/study-sessions");
app.route("/api/study-sessions", studySessionsRouter);

console.log("📊 Mounting analytics routes at /api/analytics");
app.route("/api/analytics", analyticsRouter);

// Health check endpoint
// Used by load balancers and monitoring tools to verify service is running
app.get("/health", (c) => {
  console.log("💚 Health check requested");
  return c.json({ status: "ok" });
});

// Start the server
console.log("⚙️  Starting server...");
serve({ fetch: app.fetch, port: Number(env.PORT) }, () => {
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log(`📍 Environment: ${env.NODE_ENV}`);
  console.log(`🚀 Server is running on port ${env.PORT}`);
  console.log(`🔗 Base URL: http://localhost:${env.PORT}`);
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("\n📚 Available endpoints:");
  console.log("  🔐 Auth:         /api/auth/*");
  console.log("  📤 Upload:       POST /api/upload/image");
  console.log("  📚 Subjects:     GET/POST/DELETE /api/subjects");
  console.log("  📝 Assignments:  GET/POST/PATCH/DELETE /api/assignments");
  console.log("  📅 Study Blocks: GET/POST /api/study-blocks");
  console.log("  🎨 Canvas:       GET/POST/DELETE /api/canvas");
  console.log("  📅 Schedule:     GET/POST /api/schedule");
  console.log("  📚 Courses:      GET/POST /api/courses");
  console.log("  📊 Grades:       GET /api/grades");
  console.log("  💚 Health:       GET /health");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
});
